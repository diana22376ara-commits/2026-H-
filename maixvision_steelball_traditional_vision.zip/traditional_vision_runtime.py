"""Maix runtime for model-free vertical steel-ball tracking."""
import time

from maix import app, camera, display, image, pinmap, uart

from traditional_vision_core import (InitAverager, PositionVelocity,
                                     SerialController, distance_cm_from_y, roi_bounds,
                                     select_dark_blob,
                                     speed_cm_s_from_px_s, vertical_roi_bounds)


CAMERA_WIDTH = 240
CAMERA_HEIGHT = 320
ROI_WIDTH = 18
ROI_OFFSET_X = 11
ROI_Y_MARGIN = 0
DARK_BLOB_THRESHOLD = 145
MIN_BLOB_WIDTH = 2
MAX_BLOB_WIDTH = ROI_WIDTH
MIN_BLOB_HEIGHT = 7
MAX_BLOB_HEIGHT = 40
MIN_BLOB_PIXELS = 18
INIT_FRAME_COUNT = 40
INIT_MIN_SAMPLES = 30
HOLD_LAST_FRAMES = 4
SERIAL_TARGET_HZ = 100


def run():
    pinmap.set_pin_function("A16", "UART0_TX")
    pinmap.set_pin_function("A17", "UART0_RX")
    serial = uart.UART("/dev/ttyS0", 115200)
    print("Serial: using /dev/ttyS0 (TX=A16, RX=A17), open={}".format(serial.is_open()))
    cam = None
    disp = None
    try:
        cam = camera.Camera(CAMERA_WIDTH, CAMERA_HEIGHT, image.Format.FMT_GRAYSCALE)
        disp = display.Display()
        left, right = roi_bounds(CAMERA_WIDTH, ROI_WIDTH, ROI_OFFSET_X)
        roi_y_top, roi_y_bottom = vertical_roi_bounds(CAMERA_HEIGHT, ROI_Y_MARGIN)
        serial_controller = SerialController(serial, SERIAL_TARGET_HZ)
        initializer = None
        initial_y = None
        previous_y = None
        last_location_cm = None
        last_speed_cm_s = None
        lost_frames = HOLD_LAST_FRAMES + 1
        velocity = PositionVelocity()

        def begin_init():
            nonlocal initializer, initial_y, previous_y
            nonlocal last_location_cm, last_speed_cm_s, lost_frames
            initializer = InitAverager(INIT_FRAME_COUNT, INIT_MIN_SAMPLES)
            initial_y = None
            previous_y = None
            last_location_cm = None
            last_speed_cm_s = None
            lost_frames = HOLD_LAST_FRAMES + 1
            velocity.reset()
            serial_controller.set_initialized(False)

        while not app.need_exit():
            serial_controller.receive_commands()
            if serial_controller.take_init_request():
                begin_init()
            frame = cam.read()
            now = time.time()
            blobs = frame.find_blobs(
                [[0, DARK_BLOB_THRESHOLD]],
                roi=[left, roi_y_top, right - left, roi_y_bottom - roi_y_top],
                x_stride=1,
                y_stride=1,
                area_threshold=MIN_BLOB_PIXELS,
                pixels_threshold=MIN_BLOB_PIXELS,
                merge=True,
                margin=2,
            )
            candidates = [
                blob for blob in blobs
                if MIN_BLOB_WIDTH <= blob[2] <= MAX_BLOB_WIDTH
                and MIN_BLOB_HEIGHT <= blob[3] <= MAX_BLOB_HEIGHT
            ]
            blob = select_dark_blob(candidates, previous_y)
            if blob is not None:
                detection = {
                    "x": blob[0], "top": blob[1], "width": blob[2],
                    "height": blob[3], "center_y": blob[1] + blob[3] / 2.0,
                }
            else:
                detection = None
            center_y = detection["center_y"] if detection is not None else None
            active = False
            location_cm = None
            speed_cm_s = None

            if initializer is not None:
                result = initializer.add(center_y)
                if initializer.frames_seen >= INIT_FRAME_COUNT:
                    initializer = None
                    if result is None:
                        print("Init failed: insufficient valid ball samples")
                    else:
                        initial_y = result
                        previous_y = result
                        serial_controller.set_initialized(True)
            elif initial_y is not None and center_y is not None:
                previous_y = center_y
                location_cm = distance_cm_from_y(center_y, initial_y, CAMERA_HEIGHT)
                speed_cm_s = speed_cm_s_from_px_s(velocity.update(center_y, now), CAMERA_HEIGHT)
                last_location_cm = location_cm
                last_speed_cm_s = speed_cm_s
                lost_frames = 0
                active = True
            elif initial_y is not None:
                lost_frames += 1
                active = last_location_cm is not None and lost_frames <= HOLD_LAST_FRAMES
                if active:
                    location_cm = last_location_cm
                    speed_cm_s = last_speed_cm_s
                else:
                    velocity.reset()
                    previous_y = initial_y
                    last_location_cm = None
                    last_speed_cm_s = None

            frame.draw_rect(
                left, roi_y_top, right - left, roi_y_bottom - roi_y_top,
                image.COLOR_BLUE, 2,
            )
            if detection is not None:
                frame.draw_rect(
                    detection["x"], detection["top"], detection["width"],
                    detection["height"], image.COLOR_GREEN, 2,
                )
            if initial_y is not None:
                frame.draw_line(0, int(initial_y), CAMERA_WIDTH - 1, int(initial_y), image.COLOR_BLUE, 2)

            if initializer is not None:
                status, color = "INIT {}/{}".format(initializer.frames_seen, INIT_FRAME_COUNT), image.COLOR_BLUE
            elif initial_y is None:
                status, color = "WAIT INIT", image.COLOR_RED
            elif not serial_controller.enabled:
                status, color = "READY START", image.COLOR_BLUE
            elif active:
                status, color = "TRACKING" if detection is not None else "HOLD", image.COLOR_WHITE
            else:
                status, color = "LOST", image.COLOR_RED
            frame.draw_string(10, 10, status, color)
            frame.draw_string(10, 30, "Y:{}px".format(int(center_y)) if center_y is not None else "Y:--", image.COLOR_WHITE)
            frame.draw_string(10, 50, "D:{:.2f}cm".format(location_cm) if location_cm is not None else "D:--", image.COLOR_WHITE)
            frame.draw_string(10, 70, "V:{:.2f}cm/s".format(speed_cm_s) if speed_cm_s is not None else "V:--", image.COLOR_WHITE)
            serial_controller.send_due(now, active, speed_cm_s, location_cm)
            disp.show(frame)
    finally:
        if cam is not None:
            cam.close()
        if disp is not None:
            disp.close()
        serial.close()
