from traditional_vision_runtime import run


run()
