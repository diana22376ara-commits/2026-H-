"""Model-free steel-ball detection for a fixed white-PVC tube scene."""
import math


# The full 320-pixel image height represents the 25 cm physical travel.
MAX_DISTANCE_CM = 12.5


def roi_bounds(frame_width, roi_width=30, offset_x=10):
    if frame_width <= 0 or roi_width <= 0:
        raise ValueError("frame_width and roi_width must be positive")
    width = min(int(frame_width), int(roi_width))
    left = (int(frame_width) - width) // 2 + int(offset_x)
    left = max(0, min(int(frame_width) - width, left))
    return left, left + width


def profile_sample_columns(left, right, sample_width=1):
    """Return centered x coordinates for low-overhead vertical profile sampling."""
    width = right - left
    if width <= 0 or sample_width <= 0:
        raise ValueError("ROI width and sample_width must be positive")
    sample_width = min(width, int(sample_width))
    start = left + width // 2 - sample_width // 2
    start = min(right - sample_width, max(left, start))
    return tuple(range(start, start + sample_width))


def vertical_roi_bounds(frame_height, margin=7):
    if frame_height <= 0 or margin < 0 or frame_height <= margin * 2:
        raise ValueError("frame_height must exceed twice the vertical margin")
    return int(margin), int(frame_height) - int(margin)


def darkest_sample(samples):
    """Keep a dark steel-ball signal when adjacent columns contain glare."""
    if not samples:
        raise ValueError("samples must not be empty")
    return min(samples)


def select_dark_blob(blobs, previous_y=None):
    """Choose the largest first target, then maintain continuity by Y position."""
    if not blobs:
        return None
    if previous_y is not None:
        return min(blobs, key=lambda blob: abs(blob[1] + blob[3] / 2.0 - previous_y))
    return max(blobs, key=lambda blob: blob[2] * blob[3])




def smooth_profile(profile, radius=1):
    if not profile:
        return []
    result = []
    for index in range(len(profile)):
        start = max(0, index - radius)
        end = min(len(profile), index + radius + 1)
        result.append(sum(profile[start:end]) / (end - start))
    return result


def _largest_near(values, center, radius=3):
    start = max(0, center - radius)
    end = min(len(values), center + radius + 1)
    return max(values[start:end]) if start < end else 0.0


def detect_dark_ball(profile, min_diameter_px=8, max_diameter_px=28):
    """Locate a dark steel-ball segment inside a bright, fixed tube profile."""
    if len(profile) < min_diameter_px + 6:
        return None
    smoothed = smooth_profile(profile)
    sorted_values = sorted(smoothed)
    bright_count = max(1, len(sorted_values) // 4)
    background = sum(sorted_values[-bright_count:]) / bright_count
    darkest = sorted_values[0]
    contrast = background - darkest
    if contrast < 20.0:
        return None
    threshold = background - max(16.0, contrast * 0.45)

    gradients = [0.0] * len(smoothed)
    for index in range(2, len(smoothed) - 2):
        gradients[index] = abs(smoothed[index + 2] - smoothed[index - 2])

    candidates = []
    index = 0
    while index < len(smoothed):
        if smoothed[index] >= threshold:
            index += 1
            continue
        top = index
        while index < len(smoothed) and smoothed[index] < threshold:
            index += 1
        bottom = index - 1
        diameter = bottom - top + 1
        if not min_diameter_px <= diameter <= max_diameter_px:
            continue
        mean_value = sum(smoothed[top:bottom + 1]) / diameter
        darkness_score = min(1.0, max(0.0, (background - mean_value) / contrast))
        edge_score = min(
            1.0,
            (_largest_near(gradients, top) + _largest_near(gradients, bottom))
            / max(1.0, contrast),
        )
        confidence = 0.5 * darkness_score + 0.5 * edge_score
        candidates.append({
            "top": top,
            "bottom": bottom,
            "center_y": (top + bottom) / 2.0,
            "confidence": confidence,
            "threshold": threshold,
        })
    if not candidates:
        return None
    return max(candidates, key=lambda candidate: candidate["confidence"])


def distance_cm_from_y(center_y, initial_y, frame_height):
    if frame_height <= 0:
        raise ValueError("frame_height must be positive")
    distance = (initial_y - center_y) * (2.0 * MAX_DISTANCE_CM / frame_height)
    return max(-MAX_DISTANCE_CM, min(MAX_DISTANCE_CM, distance))


def speed_cm_s_from_px_s(speed_px_s, frame_height):
    if frame_height <= 0:
        raise ValueError("frame_height must be positive")
    return -speed_px_s * (2.0 * MAX_DISTANCE_CM / frame_height)


class InitAverager:
    def __init__(self, frame_count=40, min_samples=30):
        self.frame_count = frame_count
        self.min_samples = min_samples
        self.frames_seen = 0
        self.samples = []

    def add(self, center_y):
        self.frames_seen += 1
        if isinstance(center_y, (int, float)) and math.isfinite(center_y):
            self.samples.append(center_y)
        if self.frames_seen < self.frame_count:
            return None
        if len(self.samples) < self.min_samples:
            return None
        return sum(self.samples) / len(self.samples)


class PositionVelocity:
    """Multi-frame vertical speed estimate; down is positive."""
    def __init__(self, history_size=6):
        self.history_size = history_size
        self.history = []

    def reset(self):
        self.history = []

    def update(self, y, now):
        self.history.append((y, now))
        if len(self.history) > self.history_size:
            self.history.pop(0)
        if len(self.history) < 2:
            return 0.0
        old_y, old_time = self.history[0]
        elapsed = now - old_time
        return 0.0 if elapsed <= 0 else (y - old_y) / elapsed


class SerialController:
    def __init__(self, serial, target_hz=100):
        self.serial = serial
        self.target_hz = target_hz
        self.enabled = False
        self.initialized = False
        self.init_requested = False
        self.start_requested = False
        self.buffer = ""
        self.last_send_time = None
        self._target_was_active = False

    def _reset_sender(self):
        self.last_send_time = None
        self._target_was_active = False

    def _handle_command(self, command):
        if command == "Init":
            self.enabled = False
            self.initialized = False
            self.init_requested = True
            self.start_requested = False
            self._reset_sender()
            print("Serial: Init target capture")
        elif command == "Start":
            self.enabled = self.initialized
            self.start_requested = not self.initialized
            self._reset_sender()
            print("Serial: Start sending data" if self.enabled else "Serial: Start queued until Init completes")
        elif command == "Stop":
            self.enabled = False
            self.start_requested = False
            self._reset_sender()
            print("Serial: Stop sending data")

    def receive_commands(self):
        try:
            chunk = self.serial.read()
        except (RuntimeError, OSError) as exc:
            print("Warning: serial read failed: {}".format(exc))
            return
        if not chunk:
            return
        self.buffer += chunk.decode(errors="ignore") if isinstance(chunk, bytes) else str(chunk)
        lines = self.buffer.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        self.buffer = lines.pop()
        for line in lines:
            self._handle_command(line.strip())
        if len(self.buffer) > 32:
            self.buffer = self.buffer[-16:]

    def take_init_request(self):
        requested = self.init_requested
        self.init_requested = False
        return requested

    def set_initialized(self, initialized):
        self.initialized = initialized
        self.enabled = bool(initialized and self.start_requested)
        if initialized:
            self.start_requested = False
        self._reset_sender()

    def send_due(self, now, target_active, speed_cm_s, location_cm):
        valid = all(
            isinstance(value, (int, float)) and math.isfinite(value)
            for value in (speed_cm_s, location_cm)
        )
        if not self.enabled or not target_active or not valid:
            if not target_active:
                self._target_was_active = False
            return
        if (
            not self._target_was_active
            or self.last_send_time is None
            or now - self.last_send_time >= 1.0 / self.target_hz
        ):
            try:
                self.serial.write(
                    "V:{:.2f}cm/s,LOCATION:{:.2f}\r\n".format(
                        speed_cm_s, location_cm
                    ).encode()
                )
            except (RuntimeError, OSError) as exc:
                print("Warning: serial write failed: {}".format(exc))
                return
            self.last_send_time = now
        self._target_was_active = True
