"""Dedicated MaixCAM Pro WebRTC camera streamer with optional recording."""
import time

from maix import app, camera, err, image, webrtc

from webrtc_recording import start_web_page_server, stop_web_page_server


STREAM_WIDTH = 640
STREAM_HEIGHT = 480
STREAM_FPS = 10
STREAM_BITRATE = 800_000
STREAM_GOP = 2
WEB_HTTP_PORT = 8000
WEB_SIGNALING_PORT = 8001


def run():
    stream_cam = None
    web_server = None
    web_server_started = False
    page_server = None
    page_thread = None
    try:
        stream_cam = camera.Camera(
            STREAM_WIDTH,
            STREAM_HEIGHT,
            image.Format.FMT_YVU420SP,
            fps=STREAM_FPS,
        )
        web_server = webrtc.WebRTC(
            port=WEB_HTTP_PORT,
            stream_type=webrtc.WebRTCStreamType.WEBRTC_STREAM_H264,
            rc_type=webrtc.WebRTCRCType.WEBRTC_RC_CBR,
            bitrate=STREAM_BITRATE,
            gop=STREAM_GOP,
            signaling_port=WEB_SIGNALING_PORT,
            http_server=False,
        )
        err.check_raise(
            web_server.bind_camera(stream_cam),
            "Failed to bind the camera to the WebRTC server",
        )
        err.check_raise(web_server.start(), "Failed to start the WebRTC server")
        web_server_started = True
        page_server, page_thread = start_web_page_server(
            WEB_HTTP_PORT, WEB_SIGNALING_PORT, STREAM_BITRATE
        )
        print("Dedicated WebRTC stream started. Open in Chrome or Edge:")
        for url in web_server.get_urls():
            print("  {}".format(url))
        while not app.need_exit():
            time.sleep(0.1)
    finally:
        stop_web_page_server(page_server, page_thread)
        if web_server_started:
            try:
                result = web_server.stop()
                if result != err.Err.ERR_NONE:
                    print("Warning: failed to stop WebRTC: {}".format(err.to_str(result)))
            except Exception as exc:
                print("Warning: failed to stop WebRTC: {}".format(exc))
        if stream_cam is not None:
            try:
                stream_cam.close()
            except Exception as exc:
                print("Warning: failed to close stream camera: {}".format(exc))
