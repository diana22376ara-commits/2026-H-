"""WebRTC browser page and safe recording receiver for MaixCAM Pro."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import re
import secrets
import shutil
import threading


LOCAL_RECORD_DIR = "/root/steelball_recordings"
LOCAL_RECORD_FREE_MARGIN = 100 * 1024 * 1024
MAX_RECORDING_BYTES = 2 * 1024 * 1024 * 1024
MAX_RECORDING_CHUNK_BYTES = 16 * 1024 * 1024
UPLOAD_SOCKET_TIMEOUT_SECONDS = 15
RECORDING_WRITE_LOCK = threading.Lock()


WEB_PAGE = """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MaixCAM 独立图传</title>
<style>
body { margin: 0; padding: 18px; background: #202124; color: #fff; font: 16px Arial, sans-serif; }
main { max-width: 1100px; margin: auto; }
video { width: 100%; max-height: 72vh; background: #000; border-radius: 10px; }
section { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin: 12px 0; }
button, select { padding: 9px 14px; border-radius: 7px; border: 1px solid #777; font-size: 16px; }
button { background: #b42828; color: #fff; } button:disabled { opacity: .5; }
#status { color: #b9d7ff; } #message { min-height: 20px; color: #ddd; }
</style>
</head>
<body>
<main>
  <h2>MaixCAM 独立实时图传</h2>
  <section><span id="status">正在连接视频…</span></section>
  <video id="video" autoplay playsinline muted></video>
  <section>
    <label>保存位置
      <select id="record-target">
        <option value="computer">电脑端</option>
        <option value="maixcam">摄像头本地</option>
      </select>
    </label>
    <button id="record-button" disabled>● 开始录制</button>
    <span id="record-timer">00:00</span>
  </section>
  <div id="message">连接视频后即可录制</div>
</main>
<script>
const signalingPort = __SIGNALING_PORT__;
const recordBitrate = __RECORD_BITRATE__;
const uploadToken = "__UPLOAD_TOKEN__";
const video = document.getElementById("video");
const statusBox = document.getElementById("status");
const target = document.getElementById("record-target");
const button = document.getElementById("record-button");
const timer = document.getElementById("record-timer");
const message = document.getElementById("message");
const clientId = Math.random().toString(36).slice(2, 12);
let socket = null, reconnectTimer = null;
let peer = null, recorder = null, chunks = [], startedAt = 0, timerId = null;
let recordingTarget = "computer", uploadSession = "", uploadStamp = "";
let uploadExtension = "webm", uploadChain = Promise.resolve();

function timestamp() {
  const d = new Date(), p = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function setTimer() {
  const s = Math.floor((performance.now() - startedAt) / 1000), p = n => String(n).padStart(2, "0");
  timer.textContent = `${p(Math.floor(s / 60))}:${p(s % 60)}`;
}
function restoreControls() {
  const live = video.srcObject && video.srcObject.getVideoTracks().some(t => t.readyState === "live");
  button.disabled = !live || !("MediaRecorder" in window) || recorder !== null;
  target.disabled = false;
  button.textContent = "● 开始录制";
}
function createRecorder(stream) {
  const options = ["video/mp4;codecs=avc1.42E01E", "video/webm;codecs=vp8", "video/webm"];
  for (const mimeType of options) {
    if (MediaRecorder.isTypeSupported && !MediaRecorder.isTypeSupported(mimeType)) continue;
    try { return new MediaRecorder(stream, {mimeType, videoBitsPerSecond: recordBitrate}); } catch (_) {}
  }
  return new MediaRecorder(stream, {videoBitsPerSecond: recordBitrate});
}
function downloadRecording(blob, filename) {
  const url = URL.createObjectURL(blob), link = document.createElement("a");
  link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
async function uploadCameraPart(path, blob) {
  const response = await fetch(path, {
    method: "POST",
    headers: {
      "Content-Type": (blob && blob.type) || `video/${uploadExtension}`,
      "X-Upload-Token": uploadToken,
      "X-Recording-Session": uploadSession,
      "X-Recording-Extension": uploadExtension,
      "X-Recording-Timestamp": uploadStamp
    },
    body: blob || new Blob([])
  });
  const result = await response.json();
  if (!response.ok || !result.ok) throw new Error(result.error || `HTTP ${response.status}`);
  return result;
}
function queueCameraChunk(blob) {
  uploadChain = uploadChain.then(() => uploadCameraPart("/api/recordings/chunk", blob));
}
async function finishRecording() {
  clearInterval(timerId); timerId = null;
  const mime = recorder.mimeType || (chunks[0] && chunks[0].type) || "video/webm";
  const extension = mime.toLowerCase().includes("mp4") ? "mp4" : "webm";
  const filename = `${uploadStamp}.${extension}`;
  try {
    if (recordingTarget === "maixcam") {
      await uploadChain;
      const saved = await uploadCameraPart("/api/recordings/finalize");
      message.textContent = `已保存到摄像头：${saved.path}`;
    } else {
      const blob = new Blob(chunks, {type: mime});
      if (!blob.size) throw new Error("没有产生视频数据");
      downloadRecording(blob, filename);
      message.textContent = `已保存到电脑：${filename}`;
    }
  } catch (error) {
    message.textContent = `保存失败：${error.message}`;
  } finally {
    chunks = []; recorder = null; uploadChain = Promise.resolve(); restoreControls();
  }
}
function startRecording() {
  if (!video.srcObject || !("MediaRecorder" in window)) return;
  try {
    recorder = createRecorder(video.srcObject);
    recordingTarget = target.value; uploadStamp = timestamp();
    uploadSession = `${uploadStamp}_${clientId}`; chunks = []; uploadChain = Promise.resolve();
    uploadExtension = recorder.mimeType.toLowerCase().includes("mp4") ? "mp4" : "webm";
    recorder.ondataavailable = e => {
      if (!e.data || !e.data.size) return;
      if (recordingTarget === "maixcam") queueCameraChunk(e.data);
      else chunks.push(e.data);
    };
    recorder.onstop = finishRecording;
    recorder.start(1000); startedAt = performance.now(); timerId = setInterval(setTimer, 500);
    target.disabled = true; button.textContent = "■ 停止录制"; message.textContent = "正在录制…";
  } catch (error) { recorder = null; message.textContent = `无法开始录制：${error.message}`; restoreControls(); }
}
function stopRecording() { if (recorder && recorder.state === "recording") { button.disabled = true; recorder.stop(); } }
function waitIce(connection) {
  if (connection.iceGatheringState === "complete") return Promise.resolve();
  return new Promise(resolve => {
    const done = () => { if (connection.iceGatheringState === "complete") { connection.removeEventListener("icegatheringstatechange", done); resolve(); } };
    connection.addEventListener("icegatheringstatechange", done); setTimeout(() => { connection.removeEventListener("icegatheringstatechange", done); resolve(); }, 3000);
  });
}
async function handleOffer(offer) {
  if (peer) { peer.onconnectionstatechange = null; peer.close(); }
  const connection = new RTCPeerConnection({bundlePolicy: "max-bundle"});
  peer = connection;
  connection.ontrack = event => { video.srcObject = event.streams[0]; video.play(); statusBox.textContent = "已连接"; restoreControls(); };
  connection.onconnectionstatechange = () => {
    if (connection !== peer) return;
    if (["failed", "disconnected", "closed"].includes(connection.connectionState)) {
      stopRecording(); scheduleReconnect();
    }
  };
  await connection.setRemoteDescription({type: offer.type, sdp: offer.sdp});
  await connection.setLocalDescription(await connection.createAnswer()); await waitIce(connection);
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({id: "server", type: connection.localDescription.type, sdp: connection.localDescription.sdp}));
  }
}
function scheduleReconnect() {
  if (reconnectTimer !== null) return;
  statusBox.textContent = "连接断开，正在重连…";
  if (peer) { peer.onconnectionstatechange = null; peer.close(); peer = null; }
  if (socket && socket.readyState < WebSocket.CLOSING) socket.close();
  reconnectTimer = setTimeout(() => { reconnectTimer = null; connectSignaling(); }, 1000);
}
function connectSignaling() {
  if (socket && socket.readyState === WebSocket.OPEN) return;
  statusBox.textContent = "正在连接视频…";
  socket = new WebSocket(`ws://${window.location.hostname}:${signalingPort}/${clientId}`);
  socket.onopen = () => socket.send(JSON.stringify({id: "server", type: "request"}));
  socket.onmessage = async event => {
    if (typeof event.data !== "string") return;
    const data = JSON.parse(event.data);
    if (data.type === "offer") { try { await handleOffer(data); } catch (_) { scheduleReconnect(); } }
  };
  socket.onerror = () => statusBox.textContent = "信令连接失败，正在重连…";
  socket.onclose = scheduleReconnect;
}
connectSignaling();
button.onclick = () => recorder && recorder.state === "recording" ? stopRecording() : startRecording();
</script>
</body></html>"""


def web_page_bytes(signaling_port, bitrate, upload_token):
    return (
        WEB_PAGE.replace("__SIGNALING_PORT__", str(signaling_port))
        .replace("__RECORD_BITRATE__", str(bitrate))
        .replace("__UPLOAD_TOKEN__", upload_token)
        .encode("utf-8")
    )


class WebPageHandler(BaseHTTPRequestHandler):
    page_bytes = b""
    upload_token = ""

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.split("?", 1)[0] in ("/", "/index.html"):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(self.page_bytes)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(self.page_bytes)
        elif self.path.split("?", 1)[0] == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
        else:
            self.send_error(404)

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        if path not in ("/api/recordings/chunk", "/api/recordings/finalize"):
            self.send_json(404, {"ok": False, "error": "接口不存在"})
            return
        if not secrets.compare_digest(
            self.headers.get("X-Upload-Token", ""),
            self.upload_token,
        ):
            self.send_json(403, {"ok": False, "error": "上传令牌无效"})
            return
        self.connection.settimeout(UPLOAD_SOCKET_TIMEOUT_SECONDS)
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            content_length = -1
        if path.endswith("/chunk") and (
            content_length <= 0 or content_length > MAX_RECORDING_CHUNK_BYTES
        ):
            self.send_json(400, {"ok": False, "error": "录像分片大小无效"})
            return
        if path.endswith("/finalize") and content_length != 0:
            self.send_json(400, {"ok": False, "error": "结束请求不能携带录像数据"})
            return
        extension = self.headers.get("X-Recording-Extension", "webm").lower()
        if extension not in ("mp4", "webm"):
            self.send_json(400, {"ok": False, "error": "不支持的录像格式"})
            return
        session = self.headers.get("X-Recording-Session", "")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", session):
            self.send_json(400, {"ok": False, "error": "录像会话无效"})
            return
        stamp = self.headers.get("X-Recording-Timestamp", "")
        if not (
            len(stamp) == 15
            and stamp[8:9] == "_"
            and stamp.replace("_", "").isdigit()
        ):
            self.send_json(400, {"ok": False, "error": "录像时间戳无效"})
            return
        chunk_path = None
        try:
            os.makedirs(LOCAL_RECORD_DIR, exist_ok=True)
            with RECORDING_WRITE_LOCK:
                part_path = os.path.join(
                    LOCAL_RECORD_DIR,
                    "{}.{}.part".format(session, extension),
                )
                if path.endswith("/chunk"):
                    current_size = os.path.getsize(part_path) if os.path.exists(part_path) else 0
                    if current_size + content_length > MAX_RECORDING_BYTES:
                        self.send_json(413, {"ok": False, "error": "录像超过最大容量"})
                        return
                    if (
                        content_length + LOCAL_RECORD_FREE_MARGIN
                        > shutil.disk_usage(LOCAL_RECORD_DIR).free
                    ):
                        self.send_json(507, {"ok": False, "error": "摄像头存储空间不足"})
                        return
                    chunk_path = part_path + ".chunk"
                    remaining = content_length
                    with open(chunk_path, "wb") as output:
                        while remaining:
                            chunk = self.rfile.read(min(1024 * 1024, remaining))
                            if not chunk:
                                raise ConnectionError("录像分片上传中断")
                            output.write(chunk)
                            remaining -= len(chunk)
                        output.flush()
                        os.fsync(output.fileno())
                    with open(part_path, "ab") as output, open(chunk_path, "rb") as source:
                        shutil.copyfileobj(source, output, 1024 * 1024)
                        output.flush()
                        os.fsync(output.fileno())
                    os.remove(chunk_path)
                    chunk_path = None
                    size = os.path.getsize(part_path)
                    self.send_json(200, {"ok": True, "size": size})
                    return

                if not os.path.exists(part_path):
                    self.send_json(404, {"ok": False, "error": "没有可结束的录像"})
                    return
                filename = "{}.{}".format(stamp, extension)
                final_path = os.path.join(LOCAL_RECORD_DIR, filename)
                index = 1
                while os.path.exists(final_path):
                    filename = "{}_{:02d}.{}".format(stamp, index, extension)
                    final_path = os.path.join(LOCAL_RECORD_DIR, filename)
                    index += 1
                os.replace(part_path, final_path)
                size = os.path.getsize(final_path)
            print("Recording saved: {} ({} bytes)".format(final_path, size))
            self.send_json(200, {"ok": True, "path": final_path, "size": size})
        except Exception as exc:
            if chunk_path and os.path.exists(chunk_path):
                try:
                    os.remove(chunk_path)
                except OSError:
                    pass
            self.send_json(500, {"ok": False, "error": str(exc)})

    def log_message(self, format, *args):
        return


class WebPageServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def start_web_page_server(port, signaling_port, bitrate):
    upload_token = secrets.token_hex(16)

    class ConfiguredWebPageHandler(WebPageHandler):
        pass

    ConfiguredWebPageHandler.upload_token = upload_token
    ConfiguredWebPageHandler.page_bytes = web_page_bytes(
        signaling_port,
        bitrate,
        upload_token,
    )
    server = WebPageServer(("", port), ConfiguredWebPageHandler)
    server.upload_token = upload_token
    thread = threading.Thread(target=server.serve_forever, name="steelball-web-page", daemon=True)
    thread.start()
    return server, thread


def stop_web_page_server(server, thread):
    if server is None:
        return
    try:
        server.shutdown()
        server.server_close()
        if thread is not None:
            thread.join(timeout=2)
    except Exception as exc:
        print("Warning: failed to stop recording web page server: {}".format(exc))
