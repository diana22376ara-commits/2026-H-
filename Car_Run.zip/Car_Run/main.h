#ifndef APP_MAIN_H
#define APP_MAIN_H

void Pure_Line_Follow_Run(void);
void Fast_Full_Lap_Run(void);
void Ball_Straight_Run(void);

void Speed_Set(void);
void Speed_Test_Run(void);
void Left_Speed_PID_Tune(void);
void Right_Speed_PID_Tune(void);
void Line_PID_Tune(void);
void Encoder_Motor_Test(void);

void Line_White_Calibrate(void);
void Line_Black_Calibrate(void);
void Line_Sensor_View(void);

#endif
