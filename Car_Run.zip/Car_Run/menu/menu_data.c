#include "menu.h"
#include "main.h"

static void Run_Menu(void);
static void Settings_Menu(void);
static void Sensors_Menu(void);
static void Tune_Menu(void);
static void Line_Sensor_Menu(void);

void Menu_RunMainMenu(void)
{
    static const MenuOption options[] = {
        {"<<<", NULL},
        {"Run", Run_Menu},
        {"Settings", Settings_Menu},
        {"Sensors", Sensors_Menu},
        {"Tune/Test", Tune_Menu},
        {NULL, NULL}
    };
    Menu_RunMenu(options);
}
static void Run_Menu(void)
{
    static const MenuOption options[] = {
        {"<<<", NULL},
        {"Smooth full lap", Pure_Line_Follow_Run},
        {"Fast full lap", Fast_Full_Lap_Run},
        {"Ball straight", Ball_Straight_Run},
        {NULL, NULL}
    };
    Menu_RunMenu(options);
}

static void Settings_Menu(void)
{
    static const MenuOption options[] = {
        {"<<<", NULL},
        {"Speed m/s", Speed_Set},
        {NULL, NULL}
    };
    Menu_RunMenu(options);
}

static void Sensors_Menu(void)
{
    static const MenuOption options[] = {
        {"<<<", NULL},
        {"Line sensor", Line_Sensor_Menu},
        {NULL, NULL}
    };
    Menu_RunMenu(options);
}

static void Tune_Menu(void)
{
    static const MenuOption options[] = {
        {"<<<", NULL},
        {"Speed test", Speed_Test_Run},
        {"L speed PID", Left_Speed_PID_Tune},
        {"R speed PID", Right_Speed_PID_Tune},
        {"Line PID", Line_PID_Tune},
        {"Encoder test", Encoder_Motor_Test},
        {NULL, NULL}
    };
    Menu_RunMenu(options);
}

static void Line_Sensor_Menu(void)
{
    static const MenuOption options[] = {
        {"<<<", NULL},
        {"White calib", Line_White_Calibrate},
        {"Black calib", Line_Black_Calibrate},
        {"View", Line_Sensor_View},
        {NULL, NULL}
    };
    Menu_RunMenu(options);
}
