#include "menu.h"

#include <stdbool.h>
#include "key.h"
#include "oled_software_i2c.h"

#define MENU_VISIBLE_ROWS 4U

static int8_t Menu_RollEvent(void)
{
    if (Key_Up_Get()) return -1;
    if (Key_Down_Get()) return 1;
    return 0;
}

void OLED_Showchar(uint8_t row, uint8_t column, char character)
{
    OLED_ShowChar((uint8_t)((column - 1U) * 8U),
                  (uint8_t)((row - 1U) * 2U),
                  (uint8_t)character, 16);
}

void OLED_Showstr(uint8_t row, uint8_t column, const char *text)
{
    OLED_ShowString((uint8_t)((column - 1U) * 8U),
                    (uint8_t)((row - 1U) * 2U),
                    (uint8_t *)text, 16);
}

void OLED_ShowString_Cur(uint8_t row, uint8_t column, const char *text)
{
    uint8_t x = (uint8_t)((column - 1U) * 8U);
    uint8_t y = (uint8_t)((row - 1U) * 2U);
    while (*text != '\0') {
        OLED_ShowChar(x, y, (uint8_t)*text++, 16);
        x = (uint8_t)(x + 8U);
    }
    OLED_ShowChar(x, y, (uint8_t)'<', 16);
    OLED_ShowChar((uint8_t)(x + 8U), y, (uint8_t)'-', 16);
}

static uint8_t Menu_OptionCount(const MenuOption *options)
{
    uint8_t count = 0;
    while (options[count].label != NULL) count++;
    return count;
}

static void Menu_Render(const MenuOption *options, uint8_t option_count,
                        uint8_t selected, uint8_t first_visible)
{
    OLED_Clear();
    for (uint8_t row = 0; row < MENU_VISIBLE_ROWS; row++) {
        uint8_t index = (uint8_t)(first_visible + row);
        if (index >= option_count) break;
        if (index == selected) {
            OLED_ShowString_Cur((uint8_t)(row + 1U), 1, options[index].label);
        } else {
            OLED_Showstr((uint8_t)(row + 1U), 1, options[index].label);
        }
    }
}

void Menu_RunMenu(const MenuOption *options)
{
    uint8_t option_count = Menu_OptionCount(options);
    if (option_count <= 1U) return;

    uint8_t selected = 1U;
    uint8_t first_visible = 0U;
    Menu_Render(options, option_count, selected, first_visible);

    while (1) {
        if (Key_Back_Get()) return;
        if (Key_Enter_Get()) {
            if (options[selected].action == NULL) return;
            options[selected].action();
            Menu_Render(options, option_count, selected, first_visible);
        }

        int8_t movement = Menu_RollEvent();
        if (movement == 0) continue;
        if (movement < 0) {
            selected = (selected == 0U) ? (uint8_t)(option_count - 1U) :
                       (uint8_t)(selected - 1U);
        } else {
            selected = (uint8_t)((selected + 1U) % option_count);
        }

        if (selected < first_visible) first_visible = selected;
        if (selected >= (uint8_t)(first_visible + MENU_VISIBLE_ROWS)) {
            first_visible = (uint8_t)(selected - MENU_VISIBLE_ROWS + 1U);
        }
        Menu_Render(options, option_count, selected, first_visible);
    }
}
