#ifndef MENU_H
#define MENU_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    const char *label;
    void (*action)(void);
} MenuOption;

void Menu_RunMainMenu(void);
void Menu_RunMenu(const MenuOption *options);

void OLED_Showchar(uint8_t row, uint8_t column, char character);
void OLED_Showstr(uint8_t row, uint8_t column, const char *text);
void OLED_ShowString_Cur(uint8_t row, uint8_t column, const char *text);

#endif
