import unittest
from pathlib import Path


SOURCE = (Path(__file__).parents[1] / "main.c").read_text(encoding="utf-8")


def function_body(name: str) -> str:
    start = SOURCE.index(f"void {name}(void)")
    brace = SOURCE.index("{", start)
    depth = 0
    for index in range(brace, len(SOURCE)):
        if SOURCE[index] == "{":
            depth += 1
        elif SOURCE[index] == "}":
            depth -= 1
            if depth == 0:
                return SOURCE[brace + 1:index]
    raise AssertionError(f"unterminated function: {name}")


class StartupProfileTests(unittest.TestCase):
    def test_heavy_car_modes_start_above_the_low_torque_region(self):
        self.assertIn("#define RUN_START_SPEED_MPS", SOURCE)
        for name in ("Pure_Line_Follow_Run", "Ball_Straight_Run"):
            self.assertIn(
                "float speed_reference_mps = RUN_START_SPEED_MPS;",
                function_body(name),
                name,
            )

    def test_left_drift_correction_is_temporary_and_mode_scoped(self):
        self.assertIn("#define RUN_START_RIGHT_TRIM_DEG", SOURCE)
        self.assertIn("#define RUN_START_TRIM_TICKS", SOURCE)
        for name in ("Pure_Line_Follow_Run", "Ball_Straight_Run"):
            body = function_body(name)
            self.assertIn("Startup_RightTrimDeg(run_ticks)", body, name)
        self.assertNotIn(
            "Startup_RightTrimDeg(run_ticks)",
            function_body("Fast_Full_Lap_Run"),
        )


if __name__ == "__main__":
    unittest.main()
