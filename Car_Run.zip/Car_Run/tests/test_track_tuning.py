import re
import unittest
from pathlib import Path


ROOT = Path(__file__).parents[1]
MAIN = (ROOT / "main.c").read_text(encoding="utf-8")
PID = (ROOT / "System" / "pid.c").read_text(encoding="utf-8")


class TrackTuningTests(unittest.TestCase):
    def test_finish_approach_is_quarter_meter(self):
        match = re.search(
            r"#define\s+PURE_FOLLOW_FINISH_APPROACH_M\s+([0-9.]+)f", MAIN
        )
        self.assertIsNotNone(match)
        self.assertEqual(0.25, float(match.group(1)))

    def test_line_pid_kp_is_0_0090(self):
        block = PID[PID.index("PID_t LinePID"):]
        match = re.search(r"\.Kp\s*=\s*([0-9.]+)f", block)
        self.assertIsNotNone(match)
        self.assertEqual(0.0090, float(match.group(1)))

    def test_fast_lap_has_short_finish_slowdown(self):
        approach = re.search(
            r"#define\s+FAST_LAP_FINISH_APPROACH_M\s+([0-9.]+)f", MAIN
        )
        speed = re.search(
            r"#define\s+FAST_LAP_FINISH_SPEED_MPS\s+([0-9.]+)f", MAIN
        )
        self.assertIsNotNone(approach)
        self.assertIsNotNone(speed)
        self.assertEqual(0.15, float(approach.group(1)))
        self.assertEqual(0.25, float(speed.group(1)))


if __name__ == "__main__":
    unittest.main()
