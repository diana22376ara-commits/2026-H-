import re
import unittest
from pathlib import Path


SOURCE = (Path(__file__).parents[1] / "main.c").read_text(encoding="utf-8")


def function_body(name: str) -> str:
    start = SOURCE.index(f"void {name}(void)")
    brace = SOURCE.index("{", start)
    depth = 0
    for index in range(brace, len(SOURCE)):
        if SOURCE[index] == "{":
            depth += 1
        elif SOURCE[index] == "}":
            depth -= 1
            if depth == 0:
                return SOURCE[brace + 1:index]
    raise AssertionError(f"unterminated function: {name}")


class RunTimerTests(unittest.TestCase):
    def test_every_run_mode_uses_32_bit_elapsed_time(self):
        for name in ("Pure_Line_Follow_Run", "Fast_Full_Lap_Run", "Ball_Straight_Run"):
            body = function_body(name)
            self.assertIn("uint32_t run_ticks = 0U;", body, name)
            self.assertIn("run_ticks += elapsed_ticks;", body, name)

    def test_every_run_mode_only_labels_oled_with_time(self):
        for name in ("Pure_Line_Follow_Run", "Fast_Full_Lap_Run", "Ball_Straight_Run"):
            body = function_body(name)
            labels = re.findall(r'OLED_Showstr\([^,]+,[^,]+,\s*"([^"]*)"', body)
            self.assertTrue(labels, name)
            self.assertTrue(all("Time:" in label for label in labels), (name, labels))

    def test_every_run_mode_displays_seconds_with_one_decimal_place(self):
        for name in ("Pure_Line_Follow_Run", "Fast_Full_Lap_Run", "Ball_Straight_Run"):
            body = function_body(name)
            self.assertIn('"Time: 0.0 s', body, name)
            self.assertIn('"Time:%.1f s', body, name)
            self.assertNotIn('"Time:%.2f s', body, name)


if __name__ == "__main__":
    unittest.main()
