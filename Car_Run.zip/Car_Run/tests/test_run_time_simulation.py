import importlib.util
import unittest
from pathlib import Path


SIM_PATH = Path(__file__).parents[1] / "tools" / "simulate_run_times.py"


class RunTimeSimulationTests(unittest.TestCase):
    def test_ideal_control_replay_meets_time_limits(self):
        spec = importlib.util.spec_from_file_location("run_time_sim", SIM_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result = module.simulate_all()
        self.assertLess(result["fast_full_lap_s"], 20.0)
        self.assertLess(result["pure_line_follow_s"], 30.0)
        self.assertLess(result["ball_straight_s"], 8.0)


if __name__ == "__main__":
    unittest.main()
