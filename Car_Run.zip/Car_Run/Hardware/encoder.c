#include "encoder.h"

#include <stdbool.h>
#include <string.h>
#include "car_para.h"
#include "clock.h"
#include "ti_msp_dl_config.h"
#include "timer.h"

#define PI_F                              3.14159265358979323846f
#define ENCODER_L_TIMER_HZ                500000.0f
#define ENCODER_R_TIMER_HZ                32000000.0f
#define ENCODER_STALE_MS                  80U
#define ENCODER_PERIOD_FILTER_OLD_WEIGHT  3U
#define ENCODER_PERIOD_BLEND_LOW          0.85f
#define ENCODER_PERIOD_BLEND_HIGH         0.60f
#define ENCODER_HIGH_COUNT_THRESHOLD      12
#define ENCODER_B_PINS                    \
    (GPIO_ENCODER_B_L_PIN | GPIO_ENCODER_B_R_PIN)

typedef struct {
    volatile uint32_t last_timer_count;
    volatile uint32_t filtered_period_ticks;
    volatile uint32_t last_edge_ms;
    volatile int8_t direction;
    volatile uint8_t quadrature_state;
    volatile bool a_high;
    volatile bool b_high;
    volatile bool period_valid;
    volatile bool a_synchronized;
} EncoderState;

static volatile int32_t encoder_left_count;
static volatile int32_t encoder_right_count;
static EncoderState encoder_left;
static EncoderState encoder_right;
volatile uint32_t encoder_invalid_transition_count;

/* 正方向序列：00 -> 01 -> 11 -> 10 -> 00。 */
static const int8_t quadrature_delta[16] = {
     0,  1, -1,  0,
    -1,  0,  0,  1,
     1,  0,  0, -1,
     0, -1,  1,  0
};

static float Encoder_DistancePerCount(void)
{
    return (2.0f * PI_F * WHEEL_RADIUS_M) / ENCODER_COUNTS_PER_WHEEL_REV;
}

static bool Encoder_ReadLeftB(void)
{
    return DL_GPIO_readPins(GPIO_ENCODER_PORT, GPIO_ENCODER_B_L_PIN) != 0U;
}

static bool Encoder_ReadRightB(void)
{
    return DL_GPIO_readPins(GPIO_ENCODER_PORT, GPIO_ENCODER_B_R_PIN) != 0U;
}

static uint8_t Encoder_ComposeState(const EncoderState *state)
{
    return (uint8_t)(((uint8_t)state->a_high << 1U) |
                     (uint8_t)state->b_high);
}

static void Encoder_SetCaptureEdge(
    GPTIMER_Regs *timer, DL_TIMER_CAPTURE_EDGE_DETECTION_MODE edge)
{
    DL_Timer_setCaptureCompareCtl(timer, DL_TIMER_CC_MODE_CAPTURE,
        DL_TIMER_CC_ZCOND_NONE | DL_TIMER_CC_ACOND_TIMCLK |
        DL_TIMER_CC_LCOND_NONE | (uint32_t)edge,
        DL_TIMER_CC_0_INDEX);
}

/* Both capture timers count down. Return the elapsed ticks modulo one period. */
static uint32_t Encoder_ElapsedTicks(uint32_t previous, uint32_t current,
                                    uint32_t timer_modulus)
{
    return (previous >= current) ? (previous - current) :
                                   (previous + timer_modulus - current);
}

static uint32_t Encoder_SubtractTicks(uint32_t timer_count, uint32_t ticks,
                                     uint32_t timer_modulus)
{
    return (timer_count >= ticks) ? (timer_count - ticks) :
                                    (timer_count + timer_modulus - ticks);
}

static void Encoder_RecordDelta(EncoderState *state, volatile int32_t *count,
                                int8_t delta, uint32_t timer_count,
                                uint32_t timer_modulus, bool invert_direction)
{
    if (invert_direction) delta = (int8_t)-delta;
    *count += delta;

    uint32_t now_ms = tick_ms;
    uint32_t edge_age_ms = now_ms - state->last_edge_ms;
    bool direction_changed = state->period_valid && state->direction != delta;
    if (state->period_valid && !direction_changed &&
        edge_age_ms <= ENCODER_STALE_MS) {
        uint32_t period_ticks = Encoder_ElapsedTicks(
            state->last_timer_count, timer_count, timer_modulus);
        if (period_ticks > 0U) {
            if (state->filtered_period_ticks == 0U) {
                state->filtered_period_ticks = period_ticks;
            } else {
                state->filtered_period_ticks =
                    (ENCODER_PERIOD_FILTER_OLD_WEIGHT * state->filtered_period_ticks +
                     period_ticks + 2U) /
                    (ENCODER_PERIOD_FILTER_OLD_WEIGHT + 1U);
            }
        }
    } else {
        state->filtered_period_ticks = 0U;
    }
    state->last_timer_count = timer_count;
    state->last_edge_ms = now_ms;
    state->direction = delta;
    state->period_valid = true;
}

static void Encoder_ProcessTransition(EncoderState *state,
                                      volatile int32_t *count,
                                      uint32_t timer_count,
                                      uint32_t timer_modulus,
                                      bool invert_direction)
{
    uint8_t current_state = Encoder_ComposeState(state);
    uint8_t transition =
        (uint8_t)((state->quadrature_state << 2U) | current_state);
    int8_t delta = quadrature_delta[transition];
    state->quadrature_state = current_state;

    if (delta == 0) {
        encoder_invalid_transition_count++;
        state->period_valid = false;
        return;
    }
    Encoder_RecordDelta(state, count, delta, timer_count, timer_modulus,
                        invert_direction);
}

static void Encoder_ProcessAEdge(EncoderState *state, volatile int32_t *count,
                                 bool b_high, uint32_t timer_count,
                                 uint32_t timer_modulus,
                                 GPTIMER_Regs *timer, bool invert_direction)
{
    if (!state->a_synchronized) {
        /* Capture starts on rising edge, so the first A level is known. */
        state->a_high = true;
        state->b_high = b_high;
        state->quadrature_state = Encoder_ComposeState(state);
        state->a_synchronized = true;

        /* Baseline polarity: A rising with B high increments raw count. */
        Encoder_RecordDelta(state, count, b_high ? 1 : -1, timer_count,
                            timer_modulus, invert_direction);
        Encoder_SetCaptureEdge(timer,
            DL_TIMER_CAPTURE_EDGE_DETECTION_MODE_EDGE);
        return;
    }

    /*
     * Reconcile B with the physical pin before applying the A transition.
     * Normally the GPIO ISR has already recorded the B edge. If that IRQ is
     * delayed or lost, the next A edge proves that one B transition occurred
     * between the two A edges. Reconstruct it at the temporal midpoint so the
     * 4x count and the period-based speed estimate both remain correctly
     * scaled. A later GPIO IRQ observes the synchronized level and is ignored.
     */
    if (state->b_high != b_high) {
        uint32_t elapsed_ticks = Encoder_ElapsedTicks(
            state->last_timer_count, timer_count, timer_modulus);
        uint32_t inferred_b_count = Encoder_SubtractTicks(
            state->last_timer_count, (elapsed_ticks + 1U) / 2U,
            timer_modulus);
        state->b_high = b_high;
        Encoder_ProcessTransition(state, count, inferred_b_count,
                                  timer_modulus, invert_direction);
    }

    state->a_high = !state->a_high;
    Encoder_ProcessTransition(state, count, timer_count, timer_modulus,
                              invert_direction);
}

static void Encoder_ProcessBEdge(EncoderState *state, volatile int32_t *count,
                                 bool b_high, uint32_t timer_count,
                                 uint32_t timer_modulus,
                                 bool invert_direction)
{
    if (!state->a_synchronized) {
        state->b_high = b_high;
        return;
    }
    if (state->b_high == b_high) return;

    state->b_high = b_high;
    Encoder_ProcessTransition(state, count, timer_count, timer_modulus,
                              invert_direction);
}

static void Encoder_ResetState(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    encoder_left_count = 0;
    encoder_right_count = 0;
    memset(&encoder_left, 0, sizeof(encoder_left));
    memset(&encoder_right, 0, sizeof(encoder_right));
    encoder_left.b_high = Encoder_ReadLeftB();
    encoder_right.b_high = Encoder_ReadRightB();
    if (!primask) __enable_irq();
}

void Encoder_Init(void)
{
    Encoder_Stop();
    Encoder_SetCaptureEdge(CAPTURE_ENCODER_L_A_INST,
        DL_TIMER_CAPTURE_EDGE_DETECTION_MODE_RISING);
    Encoder_SetCaptureEdge(CAPTURE_ENCODER_R_A_INST,
        DL_TIMER_CAPTURE_EDGE_DETECTION_MODE_RISING);
    Encoder_ResetState();
    NVIC_ClearPendingIRQ(CAPTURE_ENCODER_L_A_INST_INT_IRQN);
    NVIC_ClearPendingIRQ(CAPTURE_ENCODER_R_A_INST_INT_IRQN);
    NVIC_ClearPendingIRQ(GPIO_ENCODER_INT_IRQN);
    NVIC_EnableIRQ(CAPTURE_ENCODER_L_A_INST_INT_IRQN);
    NVIC_EnableIRQ(CAPTURE_ENCODER_R_A_INST_INT_IRQN);
    NVIC_EnableIRQ(GPIO_ENCODER_INT_IRQN);
}

void Encoder_Start(void)
{
    Encoder_Stop();
    Encoder_SetCaptureEdge(CAPTURE_ENCODER_L_A_INST,
        DL_TIMER_CAPTURE_EDGE_DETECTION_MODE_RISING);
    Encoder_SetCaptureEdge(CAPTURE_ENCODER_R_A_INST,
        DL_TIMER_CAPTURE_EDGE_DETECTION_MODE_RISING);
    Encoder_ResetState();
    Control_DiagnosticsReset();
    DL_TimerG_clearInterruptStatus(CAPTURE_ENCODER_L_A_INST,
        DL_TIMERG_INTERRUPT_CC0_UP_EVENT | DL_TIMERG_INTERRUPT_CC0_DN_EVENT);
    DL_TimerG_clearInterruptStatus(CAPTURE_ENCODER_R_A_INST,
        DL_TIMERG_INTERRUPT_CC0_UP_EVENT | DL_TIMERG_INTERRUPT_CC0_DN_EVENT);
    NVIC_ClearPendingIRQ(CAPTURE_ENCODER_L_A_INST_INT_IRQN);
    NVIC_ClearPendingIRQ(CAPTURE_ENCODER_R_A_INST_INT_IRQN);
    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_PORT, ENCODER_B_PINS);
    DL_TimerG_startCounter(CAPTURE_ENCODER_L_A_INST);
    DL_TimerG_startCounter(CAPTURE_ENCODER_R_A_INST);
    DL_GPIO_enableInterrupt(GPIO_ENCODER_PORT, ENCODER_B_PINS);
}

void Encoder_Stop(void)
{
    DL_GPIO_disableInterrupt(GPIO_ENCODER_PORT, ENCODER_B_PINS);
    DL_TimerG_stopCounter(CAPTURE_ENCODER_L_A_INST);
    DL_TimerG_stopCounter(CAPTURE_ENCODER_R_A_INST);
}

void TIMG6_IRQHandler(void)
{
    uint32_t capture = DL_TimerG_getCaptureCompareValue(
        CAPTURE_ENCODER_L_A_INST, DL_TIMER_CC_0_INDEX);
    DL_TimerG_clearInterruptStatus(CAPTURE_ENCODER_L_A_INST,
        DL_TIMERG_INTERRUPT_CC0_UP_EVENT | DL_TIMERG_INTERRUPT_CC0_DN_EVENT);
    Encoder_ProcessAEdge(&encoder_left, &encoder_left_count,
                         Encoder_ReadLeftB(), capture,
                         CAPTURE_ENCODER_L_A_INST_LOAD_VALUE + 1U,
                         CAPTURE_ENCODER_L_A_INST, false);
}

void TIMG12_IRQHandler(void)
{
    uint32_t capture = DL_TimerG_getCaptureCompareValue(
        CAPTURE_ENCODER_R_A_INST, DL_TIMER_CC_0_INDEX);
    DL_TimerG_clearInterruptStatus(CAPTURE_ENCODER_R_A_INST,
        DL_TIMERG_INTERRUPT_CC0_UP_EVENT | DL_TIMERG_INTERRUPT_CC0_DN_EVENT);
    Encoder_ProcessAEdge(&encoder_right, &encoder_right_count,
                         Encoder_ReadRightB(), capture,
                         CAPTURE_ENCODER_R_A_INST_LOAD_VALUE + 1U,
                         CAPTURE_ENCODER_R_A_INST, true);
}

void Encoder_HandleGpioInterrupt(void)
{
    uint32_t pending = DL_GPIO_getEnabledInterruptStatus(
        GPIO_ENCODER_PORT, ENCODER_B_PINS);
    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_PORT, pending);

    if ((pending & GPIO_ENCODER_B_L_PIN) != 0U) {
        Encoder_ProcessBEdge(&encoder_left, &encoder_left_count,
                             Encoder_ReadLeftB(),
                             DL_Timer_getTimerCount(CAPTURE_ENCODER_L_A_INST),
                             CAPTURE_ENCODER_L_A_INST_LOAD_VALUE + 1U, false);
    }
    if ((pending & GPIO_ENCODER_B_R_PIN) != 0U) {
        Encoder_ProcessBEdge(&encoder_right, &encoder_right_count,
                             Encoder_ReadRightB(),
                             DL_Timer_getTimerCount(CAPTURE_ENCODER_R_A_INST),
                             CAPTURE_ENCODER_R_A_INST_LOAD_VALUE + 1U, true);
    }
}

static float Encoder_PeriodSpeed(const EncoderState *state, float timer_hz,
                                 float distance_per_count, uint32_t now_ms)
{
    if (!state->period_valid || state->filtered_period_ticks == 0U ||
        (uint32_t)(now_ms - state->last_edge_ms) > ENCODER_STALE_MS) {
        return 0.0f;
    }
    return distance_per_count * timer_hz /
           (float)state->filtered_period_ticks * state->direction;
}

static float Encoder_FuseSpeed(int32_t count, float count_speed,
                               float period_speed)
{
    if (period_speed == 0.0f) return count_speed;
    if (count == 0) return period_speed;
    if ((count_speed > 0.0f) != (period_speed > 0.0f)) return count_speed;

    int32_t magnitude = count >= 0 ? count : -count;
    float period_weight = (magnitude >= ENCODER_HIGH_COUNT_THRESHOLD) ?
                          ENCODER_PERIOD_BLEND_HIGH : ENCODER_PERIOD_BLEND_LOW;
    return (1.0f - period_weight) * count_speed + period_weight * period_speed;
}

void Encoder_GetVelocity(float sample_time_s, float *left_mps, float *right_mps)
{
    if (sample_time_s <= 0.0f) {
        if (left_mps != NULL) *left_mps = 0.0f;
        if (right_mps != NULL) *right_mps = 0.0f;
        return;
    }

    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    int32_t left_count = encoder_left_count;
    int32_t right_count = encoder_right_count;
    encoder_left_count = 0;
    encoder_right_count = 0;
    EncoderState left_state = encoder_left;
    EncoderState right_state = encoder_right;
    uint32_t now_ms = tick_ms;
    if (!primask) __enable_irq();

    float distance = Encoder_DistancePerCount();
    float left_count_speed = distance * (float)left_count / sample_time_s;
    float right_count_speed = distance * (float)right_count / sample_time_s;
    float left_period_speed = Encoder_PeriodSpeed(
        &left_state, ENCODER_L_TIMER_HZ, distance, now_ms);
    float right_period_speed = Encoder_PeriodSpeed(
        &right_state, ENCODER_R_TIMER_HZ, distance, now_ms);

    float left_speed = Encoder_FuseSpeed(left_count, left_count_speed,
                                         left_period_speed);
    float right_speed = Encoder_FuseSpeed(right_count, right_count_speed,
                                          right_period_speed);
    if ((uint32_t)(now_ms - left_state.last_edge_ms) > ENCODER_STALE_MS)
        left_speed = 0.0f;
    if ((uint32_t)(now_ms - right_state.last_edge_ms) > ENCODER_STALE_MS)
        right_speed = 0.0f;

    if (left_mps != NULL) *left_mps = left_speed;
    if (right_mps != NULL) *right_mps = right_speed;
}
