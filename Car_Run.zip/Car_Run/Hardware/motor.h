#ifndef MOTOR_H
#define MOTOR_H

#include <stdbool.h>
#include "pid.h"

#define MOTOR_MAX_DUTY 80

extern bool car_running;
extern float speed_left_mps;
extern float speed_right_mps;

void motorL_setv(int duty);
void motorR_setv(int duty);
void Car_setv(int duty_left, int duty_right);
void Car_stop(void);

void Motor_SampleSpeed(float sample_time_s);
void Motor_SpeedControl(float target_speed_mps, float sample_time_s);
void Motor_CascadeControl(float angle_error, float base_speed_mps,
                          PID_t *angle_pid, float sample_time_s);

#endif
