#ifndef ENCODER_H
#define ENCODER_H

#include <stdint.h>

void Encoder_Init(void);
void Encoder_Start(void);
void Encoder_Stop(void);
void Encoder_GetVelocity(float sample_time_s, float *left_mps, float *right_mps);
void Encoder_HandleGpioInterrupt(void);

extern volatile uint32_t encoder_invalid_transition_count;

#endif
