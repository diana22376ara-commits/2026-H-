#include "key.h"

enum {
    KEY_BACK_INDEX = 0,
    KEY_ENTER_INDEX,
    KEY_UP_INDEX,
    KEY_DOWN_INDEX
};

volatile KeyState keys[KEY_COUNT];

static bool Key_TakePressedEvent(uint8_t index)
{
    if (!keys[index].pressed_event) return false;
    keys[index].pressed_event = false;
    return true;
}

bool Key_Enter_Get(void) { return Key_TakePressedEvent(KEY_ENTER_INDEX); }
bool Key_Back_Get(void)  { return Key_TakePressedEvent(KEY_BACK_INDEX); }
bool Key_Up_Get(void)    { return Key_TakePressedEvent(KEY_UP_INDEX); }
bool Key_Down_Get(void)  { return Key_TakePressedEvent(KEY_DOWN_INDEX); }

void Key_Reset_All(void)
{
    for (uint8_t i = 0; i < KEY_COUNT; i++) keys[i].pressed_event = false;
}
