#ifndef KEY_H
#define KEY_H

#include <stdbool.h>
#include <stdint.h>

#define KEY_COUNT 4U

typedef struct {
    bool released;
    uint8_t debounce_state;
    bool pressed_event;
    uint16_t held_scan_ticks;
} KeyState;

extern volatile KeyState keys[KEY_COUNT];

bool Key_Enter_Get(void);
bool Key_Back_Get(void);
bool Key_Up_Get(void);
bool Key_Down_Get(void);
void Key_Reset_All(void);

#endif
