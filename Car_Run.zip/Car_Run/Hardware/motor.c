#include "motor.h"

#include <stdint.h>
#include "encoder.h"
#include "ti_msp_dl_config.h"

#define MOTOR_MAX_FORWARD_SPEED_MPS  0.40f
#define MOTOR_MAX_REVERSE_SPEED_MPS -0.20f

bool car_running = false;
float speed_left_mps = 0.0f;
float speed_right_mps = 0.0f;

static int Motor_ClampDuty(int duty)
{
    if (duty > MOTOR_MAX_DUTY) return MOTOR_MAX_DUTY;
    if (duty < -MOTOR_MAX_DUTY) return -MOTOR_MAX_DUTY;
    return duty;
}

static float Motor_ClampTargetSpeed(float speed_mps)
{
    if (speed_mps > MOTOR_MAX_FORWARD_SPEED_MPS)
        return MOTOR_MAX_FORWARD_SPEED_MPS;
    if (speed_mps < MOTOR_MAX_REVERSE_SPEED_MPS)
        return MOTOR_MAX_REVERSE_SPEED_MPS;
    return speed_mps;
}

void motorR_setv(int duty)
{
    duty = -Motor_ClampDuty(duty); /* 右电机安装方向与左侧相反 */
    DL_TimerG_setCaptureCompareValue(PWM_MOTOR_INST,
        (uint32_t)(duty < 0 ? -duty : duty), DL_TIMER_CC_1_INDEX);
    if (duty < 0) {
        DL_GPIO_clearPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_R1_PIN);
        DL_GPIO_setPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_R2_PIN);
    } else {
        DL_GPIO_setPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_R1_PIN);
        DL_GPIO_clearPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_R2_PIN);
    }
}

void motorL_setv(int duty)
{
    duty = Motor_ClampDuty(duty);
    DL_TimerG_setCaptureCompareValue(PWM_MOTOR_INST,
        (uint32_t)(duty < 0 ? -duty : duty), DL_TIMER_CC_0_INDEX);
    if (duty < 0) {
        DL_GPIO_clearPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_L1_PIN);
        DL_GPIO_setPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_L2_PIN);
    } else {
        DL_GPIO_setPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_L1_PIN);
        DL_GPIO_clearPins(GPIO_MOTOR_PORT, GPIO_MOTOR_DIR_L2_PIN);
    }
}

void Car_setv(int duty_left, int duty_right)
{
    motorL_setv(duty_left);
    motorR_setv(duty_right);
}

void Car_stop(void)
{
    PID_Reset(&LeftSpeedPID);
    PID_Reset(&RightSpeedPID);
    PID_Reset(&LinePID);
    motorL_setv(0);
    motorR_setv(0);
    Encoder_Stop();
    car_running = false;
}

void Motor_SampleSpeed(float sample_time_s)
{
    Encoder_GetVelocity(sample_time_s, &speed_left_mps, &speed_right_mps);
}

void Motor_SpeedControl(float target_speed_mps, float sample_time_s)
{
    target_speed_mps = Motor_ClampTargetSpeed(target_speed_mps);
    float left_duty = PID_UpdateIncremental(
        &LeftSpeedPID, target_speed_mps, speed_left_mps, sample_time_s);
    float right_duty = PID_UpdateIncremental(
        &RightSpeedPID, target_speed_mps, speed_right_mps, sample_time_s);
    Car_setv((int16_t)left_duty, (int16_t)right_duty);
}

void Motor_CascadeControl(float angle_error, float base_speed_mps,
                          PID_t *angle_pid, float sample_time_s)
{
    float differential_speed = PID_UpdatePosition(
        angle_pid, angle_error, sample_time_s);
    float differential_magnitude = differential_speed >= 0.0f ?
                                   differential_speed : -differential_speed;

    /* Preserve steering differential by shifting the common speed on saturation. */
    float common_min = MOTOR_MAX_REVERSE_SPEED_MPS + differential_magnitude;
    float common_max = MOTOR_MAX_FORWARD_SPEED_MPS - differential_magnitude;
    float common_speed = base_speed_mps;
    if (common_speed > common_max) common_speed = common_max;
    if (common_speed < common_min) common_speed = common_min;

    float left_target = common_speed + differential_speed;
    float right_target = common_speed - differential_speed;

    float left_duty = PID_UpdateIncremental(
        &LeftSpeedPID, left_target, speed_left_mps, sample_time_s);
    float right_duty = PID_UpdateIncremental(
        &RightSpeedPID, right_target, speed_right_mps, sample_time_s);
    Car_setv((int16_t)left_duty, (int16_t)right_duty);
}
