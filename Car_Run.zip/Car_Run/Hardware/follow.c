#include "follow.h"

#include "std_adc.h"
#include "ti_msp_dl_config.h"

#define FOLLOW_SAMPLES_PER_CHANNEL      4U
#define FOLLOW_MUX_SETTLE_CYCLES        64U
#define FOLLOW_MIN_TOTAL_STRENGTH       0.60f
#define FOLLOW_MIN_PEAK_DARKNESS        0.35f
#define FOLLOW_DIGITAL_DARK_THRESHOLD   0.50f

/* atan(sensor lateral position / 0.169 m), with 12 mm sensor pitch. */
static const float sensor_angle_deg[FOLLOW_SENSOR_COUNT] = {
    -13.9564f, -10.0660f, -6.0796f, -2.0333f,
      2.0333f,   6.0796f, 10.0660f, 13.9564f
};

static uint16_t calibrated_white[FOLLOW_SENSOR_COUNT];
static uint16_t calibrated_black[FOLLOW_SENSOR_COUNT];

static void Follow_SelectChannel(uint8_t channel)
{
    if ((channel & 0x01U) != 0U)
        DL_GPIO_setPins(GPIO_STD_PORT, GPIO_STD_AD0_PIN);
    else
        DL_GPIO_clearPins(GPIO_STD_PORT, GPIO_STD_AD0_PIN);

    if ((channel & 0x02U) != 0U)
        DL_GPIO_setPins(GPIO_STD_PORT, GPIO_STD_AD1_PIN);
    else
        DL_GPIO_clearPins(GPIO_STD_PORT, GPIO_STD_AD1_PIN);

    if ((channel & 0x04U) != 0U)
        DL_GPIO_setPins(GPIO_STD_PORT, GPIO_STD_AD2_PIN);
    else
        DL_GPIO_clearPins(GPIO_STD_PORT, GPIO_STD_AD2_PIN);
}

void Follow_Init(const uint16_t white[FOLLOW_SENSOR_COUNT],
                 const uint16_t black[FOLLOW_SENSOR_COUNT])
{
    for (uint8_t i = 0; i < FOLLOW_SENSOR_COUNT; i++) {
        if (white[i] >= black[i]) {
            calibrated_white[i] = white[i];
            calibrated_black[i] = black[i];
        } else {
            calibrated_white[i] = black[i];
            calibrated_black[i] = white[i];
        }
    }
}

void Follow_ReadRaw(uint16_t values[FOLLOW_SENSOR_COUNT])
{
    for (uint8_t channel = 0; channel < FOLLOW_SENSOR_COUNT; channel++) {
        Follow_SelectChannel(channel);
        delay_cycles(FOLLOW_MUX_SETTLE_CYCLES);
        (void)adc_getValue(); /* 丢弃复用器切换后的首个结果 */

        uint32_t sum = 0;
        for (uint8_t sample = 0; sample < FOLLOW_SAMPLES_PER_CHANNEL; sample++) {
            sum += adc_getValue();
        }
        values[channel] = (uint16_t)(sum / FOLLOW_SAMPLES_PER_CHANNEL);
    }
}

Follow_Result_t Follow_GetResult(void)
{
    uint16_t analog[FOLLOW_SENSOR_COUNT];
    Follow_Result_t result = {0.0f, 0.0f, 0U, false};
    float weighted_sum = 0.0f;
    float max_darkness = 0.0f;

    Follow_ReadRaw(analog);
    for (uint8_t i = 0; i < FOLLOW_SENSOR_COUNT; i++) {
        float span = (float)calibrated_white[i] - (float)calibrated_black[i];
        if (span < 1.0f) continue;

        float darkness = ((float)calibrated_white[i] - (float)analog[i]) / span;
        if (darkness < 0.0f) darkness = 0.0f;
        if (darkness > 1.0f) darkness = 1.0f;

        result.strength += darkness;
        weighted_sum += darkness * sensor_angle_deg[i];
        if (darkness > max_darkness) max_darkness = darkness;
        if (darkness >= FOLLOW_DIGITAL_DARK_THRESHOLD) {
            result.digital |= (uint8_t)(1U << i);
        }
    }

    result.line_detected = result.strength >= FOLLOW_MIN_TOTAL_STRENGTH &&
                           max_darkness >= FOLLOW_MIN_PEAK_DARKNESS;
    if (result.line_detected) result.angle_deg = weighted_sum / result.strength;
    return result;
}
