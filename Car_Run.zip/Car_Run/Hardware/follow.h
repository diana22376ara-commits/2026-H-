#ifndef FOLLOW_H
#define FOLLOW_H

#include <stdbool.h>
#include <stdint.h>

#define FOLLOW_SENSOR_COUNT 8U

typedef struct {
    float angle_deg;
    float strength;
    uint8_t digital;       /* bit=1表示该通道检测到黑线 */
    bool line_detected;
} Follow_Result_t;

void Follow_Init(const uint16_t white[FOLLOW_SENSOR_COUNT],
                 const uint16_t black[FOLLOW_SENSOR_COUNT]);
void Follow_ReadRaw(uint16_t values[FOLLOW_SENSOR_COUNT]);
Follow_Result_t Follow_GetResult(void);

#endif
