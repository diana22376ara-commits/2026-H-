#ifndef __CAR_PARA_H
#define __CAR_PARA_H

/* 编码器/车轮机械参数，速度单位统一为m/s。 */
#define CHASSIS_LENGTH_M                  0.320f
#define CHASSIS_WIDTH_M                   0.220f
#define DRIVE_WHEEL_TRACK_M               0.172f
#define WHEEL_RADIUS_M                    0.0333f
#define LINE_SENSOR_TO_AXLE_M             0.169f
#define LINE_SENSOR_PITCH_M               0.012f
#define LINE_SENSOR_ARRAY_HALF_WIDTH_M    (3.5f * LINE_SENSOR_PITCH_M)
#define MOTOR_GEAR_RATIO                  28.0f
#define ENCODER_A_PULSES_PER_MOTOR_REV    13.0f
#define ENCODER_QUADRATURE_EDGES          4.0f
#define ENCODER_COUNTS_PER_WHEEL_REV      \
    (MOTOR_GEAR_RATIO * ENCODER_A_PULSES_PER_MOTOR_REV * \
     ENCODER_QUADRATURE_EDGES)

#endif
