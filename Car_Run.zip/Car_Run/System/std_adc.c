#include "std_adc.h"
#include <stdbool.h>
#include "clock.h"
#include "ti_msp_dl_config.h"

static volatile bool ADC_flag = false;
volatile uint32_t adc_timeout_count = 0;
static uint16_t adc_last_value = 0;

void adc_Init(void){
    //中断使能
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
}

uint16_t adc_getValue(void){
    ADC_flag = false;
    //开始转换
    DL_ADC12_startConversion(ADC12_0_INST);
    //等待数据处理完成
    uint32_t start_ms = tick_ms;
    while (ADC_flag == false) {
        if ((uint32_t)(tick_ms - start_ms) >= 2U) {
            adc_timeout_count++;
            DL_ADC12_enableConversions(ADC12_0_INST);
            return adc_last_value;
        }
    }
    //得到转换结果
    uint16_t gAdcResult = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
    adc_last_value = gAdcResult;
    DL_ADC12_enableConversions(ADC12_0_INST);
    return gAdcResult;
}

//处理完数据时会进入该中断
void ADC12_0_INST_IRQHandler(void)
{
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            ADC_flag = true;
            break;
        default:
            break;
    }
}
