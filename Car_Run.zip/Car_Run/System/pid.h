#ifndef PID_H
#define PID_H

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float Out;
    float OutMax;
    float OutMin;
    float Error0;
    float ErrorInt;
    float Derivative;
    float DFilterTau;
} PID_t;

extern PID_t LeftSpeedPID;
extern PID_t RightSpeedPID;
extern PID_t LinePID;

void PID_Reset(PID_t *pid);
float PID_UpdatePosition(PID_t *pid, float error, float sample_time_s);
float PID_UpdateIncremental(PID_t *pid, float target, float actual,
                            float sample_time_s);

#endif
