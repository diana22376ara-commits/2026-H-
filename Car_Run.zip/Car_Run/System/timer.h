#ifndef CONTROL_TIMER_H
#define CONTROL_TIMER_H

#include <stdint.h>

#define CONTROL_TICK_S 0.01f

extern volatile uint32_t control_overrun_count;
extern volatile uint8_t control_max_pending_ticks;

void Timer_Init(void);
uint8_t Control_TickTake(void);
void Control_TickReset(void);
void Control_DiagnosticsReset(void);

#endif
