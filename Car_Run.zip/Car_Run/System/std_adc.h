#ifndef STD_ADC_H
#define STD_ADC_H

#include <stdint.h>

void adc_Init(void);
uint16_t adc_getValue(void);
extern volatile uint32_t adc_timeout_count;

#endif
