#include "timer.h"

#include <stdbool.h>
#include <stdint.h>
#include "key.h"
#include "ti_msp_dl_config.h"

#define KEY_SCAN_PERIOD_TICKS       10U
#define KEY_SHORT_PRESS_MAX_SCANS   10U

static volatile uint8_t control_ticks_pending;
volatile uint32_t control_overrun_count;
volatile uint8_t control_max_pending_ticks;

void Timer_Init(void)
{
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
    DL_TimerA_startCounter(TIMER_0_INST);
}

uint8_t Control_TickTake(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    uint8_t ticks = control_ticks_pending;
    control_ticks_pending = 0;
    if (ticks > control_max_pending_ticks) control_max_pending_ticks = ticks;
    if (ticks > 1U) control_overrun_count += (uint32_t)(ticks - 1U);
    if (!primask) __enable_irq();
    return ticks;
}

void Control_TickReset(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    control_ticks_pending = 0;
    if (!primask) __enable_irq();
}

void Control_DiagnosticsReset(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    control_ticks_pending = 0U;
    control_overrun_count = 0U;
    control_max_pending_ticks = 0U;
    if (!primask) __enable_irq();
}

static void Key_Scan(void)
{
    uint32_t pins = DL_GPIO_readPins(
        GPIO_BUTTON_PORT,
        GPIO_BUTTON_BUTTON1_PIN | GPIO_BUTTON_BUTTON2_PIN |
        GPIO_BUTTON_BUTTON3_PIN | GPIO_BUTTON_BUTTON4_PIN);
    const uint32_t masks[KEY_COUNT] = {
        GPIO_BUTTON_BUTTON1_PIN, GPIO_BUTTON_BUTTON2_PIN,
        GPIO_BUTTON_BUTTON3_PIN, GPIO_BUTTON_BUTTON4_PIN
    };

    for (uint8_t i = 0; i < KEY_COUNT; i++) {
        keys[i].released = (pins & masks[i]) != 0U;
        switch (keys[i].debounce_state) {
            case 0:
                if (!keys[i].released) {
                    keys[i].debounce_state = 1;
                    keys[i].held_scan_ticks = 0;
                }
                break;
            case 1:
                keys[i].debounce_state = keys[i].released ? 0U : 2U;
                break;
            default:
                if (keys[i].held_scan_ticks < UINT16_MAX)
                    keys[i].held_scan_ticks++;
                if (keys[i].released) {
                    if (keys[i].held_scan_ticks <= KEY_SHORT_PRESS_MAX_SCANS)
                        keys[i].pressed_event = true;
                    keys[i].debounce_state = 0;
                }
                break;
        }
    }
}

void TIMER_0_INST_IRQHandler(void)
{
    static uint8_t key_scan_divider;
    if (DL_TimerA_getPendingInterrupt(TIMER_0_INST) != DL_TIMER_IIDX_ZERO) return;

    if (control_ticks_pending < UINT8_MAX) control_ticks_pending++;
    else control_overrun_count++;

    key_scan_divider++;
    if (key_scan_divider >= KEY_SCAN_PERIOD_TICKS) {
        key_scan_divider = 0;
        Key_Scan();
    }
}
