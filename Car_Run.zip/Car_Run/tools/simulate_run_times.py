"""10 ms replay of the three Run-mode speed plans.

The firmware contains no PWM-to-wheel-speed plant model.  This replay therefore
assumes the closed speed PID tracks each commanded wheel speed without lag.  It
reproduces the configured geometry, jerk/acceleration-limited profiles, finish
slowdown, and stop-stability checks; it is a controller-level estimate, not a
claim of exact physical vehicle time.
"""

import math


DT_S = 0.01
STRAIGHT_M = 1.50
CURVE_RADIUS_M = 0.50
WHEEL_TRACK_M = 0.172

DEFAULT_CAR_SPEED_MPS = 0.29
RUN_START_SPEED_MPS = 0.10
PURE_CURVE_SPEED_MPS = 0.24
PURE_FINISH_CRAWL_MPS = 0.06
PURE_FINISH_APPROACH_M = 0.25
PURE_STOP_REF_MPS = 0.005
PURE_STOP_ACTUAL_MPS = 0.020

LINE_KP = 0.0090
LINE_OUT_MAX_MPS = 0.06
FAST_SPEED_MPS = 0.40
FAST_FINISH_APPROACH_M = 0.15
FAST_FINISH_SPEED_MPS = 0.25
BALL_DISTANCE_M = 1.457


def _clamp(value, minimum, maximum):
    return max(minimum, min(maximum, value))


def _update_profile(target, speed, acceleration, omega, max_accel, max_jerk):
    desired_accel = omega * omega * (target - speed) - 2.0 * omega * acceleration
    desired_accel = _clamp(desired_accel, -max_accel, max_accel)
    accel_step = _clamp(
        desired_accel - acceleration, -max_jerk * DT_S, max_jerk * DT_S
    )
    acceleration += accel_step
    speed += acceleration * DT_S
    if speed < 0.0:
        return 0.0, 0.0
    return speed, acceleration


def _simulate_pure():
    inner_radius = CURVE_RADIUS_M - 0.5 * WHEEL_TRACK_M
    inner_half_curve_m = math.pi * inner_radius
    right_lap_m = 2.0 * STRAIGHT_M + 2.0 * inner_half_curve_m
    inner_wheel_ratio = inner_radius / CURVE_RADIUS_M

    speed = RUN_START_SPEED_MPS
    acceleration = 0.0
    right_distance = 0.0
    launch_ticks = 0
    braking = False
    brake_ticks = 0
    stable_samples = 0

    for tick in range(10_000):
        if not braking:
            on_curve = (
                STRAIGHT_M <= right_distance < STRAIGHT_M + inner_half_curve_m
                or 2.0 * STRAIGHT_M + inner_half_curve_m
                <= right_distance
                < right_lap_m
            )
            target = PURE_CURVE_SPEED_MPS if on_curve else DEFAULT_CAR_SPEED_MPS
            remaining = right_lap_m - right_distance
            if remaining < PURE_FINISH_APPROACH_M:
                finish_blend = _clamp(
                    remaining / PURE_FINISH_APPROACH_M, 0.0, 1.0
                )
                finish_limit = PURE_FINISH_CRAWL_MPS + (
                    PURE_CURVE_SPEED_MPS - PURE_FINISH_CRAWL_MPS
                ) * finish_blend
                target = min(target, finish_limit)

            launch_blend = min(1.0, launch_ticks / 400.0)
            max_accel = 0.04 + (0.10 - 0.04) * launch_blend
            max_jerk = 0.05 + (0.30 - 0.05) * launch_blend
            launch_ticks = min(400, launch_ticks + 1)
            speed, acceleration = _update_profile(
                target, speed, acceleration, 3.0, max_accel, max_jerk
            )
            right_speed = speed * inner_wheel_ratio if on_curve else speed
            right_distance += right_speed * DT_S
            braking = right_distance >= right_lap_m
        else:
            speed, acceleration = _update_profile(
                0.0, speed, acceleration, 6.0, 0.10, 0.30
            )
            brake_ticks += 1
            if speed <= PURE_STOP_REF_MPS and speed <= PURE_STOP_ACTUAL_MPS:
                stable_samples += 1
            else:
                stable_samples = 0
            if stable_samples >= 5 or brake_ticks >= 400:
                return (tick + 1) * DT_S
    raise RuntimeError("Pure_Line_Follow_Run replay did not stop")


def _simulate_fast():
    inner_radius = CURVE_RADIUS_M - 0.5 * WHEEL_TRACK_M
    outer_radius = CURVE_RADIUS_M + 0.5 * WHEEL_TRACK_M
    inner_half_curve_m = math.pi * inner_radius
    right_lap_m = 2.0 * STRAIGHT_M + 2.0 * inner_half_curve_m
    inner_wheel_ratio = inner_radius / CURVE_RADIUS_M
    curve_center_limit_mps = FAST_SPEED_MPS * CURVE_RADIUS_M / outer_radius
    right_distance = 0.0

    for tick in range(2_000):
        remaining = right_lap_m - right_distance
        target = FAST_SPEED_MPS
        if remaining < FAST_FINISH_APPROACH_M:
            finish_blend = _clamp(
                remaining / FAST_FINISH_APPROACH_M, 0.0, 1.0
            )
            target = FAST_FINISH_SPEED_MPS + (
                FAST_SPEED_MPS - FAST_FINISH_SPEED_MPS
            ) * finish_blend

        on_curve = (
            STRAIGHT_M <= right_distance < STRAIGHT_M + inner_half_curve_m
            or 2.0 * STRAIGHT_M + inner_half_curve_m
            <= right_distance
            < right_lap_m
        )
        if on_curve:
            center_speed = min(target, curve_center_limit_mps)
            right_speed = center_speed * inner_wheel_ratio
        else:
            right_speed = target
        right_distance += right_speed * DT_S
        if right_distance >= right_lap_m:
            return (tick + 1) * DT_S + 3.0 * DT_S
    raise RuntimeError("Fast_Full_Lap_Run replay did not finish")


def _simulate_ball():
    speed = RUN_START_SPEED_MPS
    acceleration = 0.0
    distance = 0.0
    stable_samples = 0

    for tick in range(800):
        remaining = max(0.0, BALL_DISTANCE_M - distance)
        target = min(0.38, math.sqrt(2.0 * 0.10 * remaining))
        speed, acceleration = _update_profile(
            target, speed, acceleration, 5.0, 0.18, 0.55
        )
        distance += speed * DT_S
        if (
            distance > 1.0
            and speed <= PURE_STOP_REF_MPS
            and speed <= PURE_STOP_ACTUAL_MPS
        ):
            stable_samples += 1
        else:
            stable_samples = 0
        if stable_samples >= 5:
            return (tick + 1) * DT_S
    return 8.0


def simulate_all():
    curve_differential_mps = (
        PURE_CURVE_SPEED_MPS * WHEEL_TRACK_M / (2.0 * CURVE_RADIUS_M)
    )
    if curve_differential_mps > LINE_OUT_MAX_MPS:
        raise RuntimeError("Line PID output limit cannot supply curve differential")

    return {
        "fast_full_lap_s": _simulate_fast(),
        "pure_line_follow_s": _simulate_pure(),
        "ball_straight_s": _simulate_ball(),
        "pure_required_curve_error_deg": curve_differential_mps / LINE_KP,
    }


if __name__ == "__main__":
    for name, value in simulate_all().items():
        print(f"{name}: {value:.3f}")
