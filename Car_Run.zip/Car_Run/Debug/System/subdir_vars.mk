################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../System/pid.c \
../System/std_adc.c \
../System/timer.c 

C_DEPS += \
./System/pid.d \
./System/std_adc.d \
./System/timer.d 

OBJS += \
./System/pid.o \
./System/std_adc.o \
./System/timer.o 

OBJS__QUOTED += \
"System\pid.o" \
"System\std_adc.o" \
"System\timer.o" 

C_DEPS__QUOTED += \
"System\pid.d" \
"System\std_adc.d" \
"System\timer.d" 

C_SRCS__QUOTED += \
"../System/pid.c" \
"../System/std_adc.c" \
"../System/timer.c" 


