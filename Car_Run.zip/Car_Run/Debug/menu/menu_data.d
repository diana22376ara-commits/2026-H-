# FIXED

menu/menu_data.o: ../menu/menu_data.c ../menu/menu.h \
 D:/Best/mpu6050-oled-software-i2c-normal/main.h
../menu/menu.h:
D:/Best/mpu6050-oled-software-i2c-normal/main.h:
