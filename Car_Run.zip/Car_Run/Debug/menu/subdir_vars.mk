################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../menu/menu.c \
../menu/menu_data.c 

C_DEPS += \
./menu/menu.d \
./menu/menu_data.d 

OBJS += \
./menu/menu.o \
./menu/menu_data.o 

OBJS__QUOTED += \
"menu\menu.o" \
"menu\menu_data.o" 

C_DEPS__QUOTED += \
"menu\menu.d" \
"menu\menu_data.d" 

C_SRCS__QUOTED += \
"../menu/menu.c" \
"../menu/menu_data.c" 


