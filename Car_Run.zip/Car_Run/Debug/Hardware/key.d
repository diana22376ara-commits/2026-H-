# FIXED

Hardware/key.o: ../Hardware/key.c ../Hardware/key.h
../Hardware/key.h:
