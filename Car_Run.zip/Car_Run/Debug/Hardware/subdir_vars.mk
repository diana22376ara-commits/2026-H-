################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/encoder.c \
../Hardware/follow.c \
../Hardware/key.c \
../Hardware/motor.c 

C_DEPS += \
./Hardware/encoder.d \
./Hardware/follow.d \
./Hardware/key.d \
./Hardware/motor.d 

OBJS += \
./Hardware/encoder.o \
./Hardware/follow.o \
./Hardware/key.o \
./Hardware/motor.o 

OBJS__QUOTED += \
"Hardware\encoder.o" \
"Hardware\follow.o" \
"Hardware\key.o" \
"Hardware\motor.o" 

C_DEPS__QUOTED += \
"Hardware\encoder.d" \
"Hardware\follow.d" \
"Hardware\key.d" \
"Hardware\motor.d" 

C_SRCS__QUOTED += \
"../Hardware/encoder.c" \
"../Hardware/follow.c" \
"../Hardware/key.c" \
"../Hardware/motor.c" 


