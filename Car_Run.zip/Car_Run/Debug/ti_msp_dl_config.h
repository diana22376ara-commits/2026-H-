/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMG0
#define PWM_MOTOR_INST_IRQHandler                               TIMG0_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMG0_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                          2000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_MOTOR_C0_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C0_PIN                                     DL_GPIO_PIN_12
#define GPIO_PWM_MOTOR_C0_IOMUX                                  (IOMUX_PINCM34)
#define GPIO_PWM_MOTOR_C0_IOMUX_FUNC                 IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_PWM_MOTOR_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C1_PIN                                     DL_GPIO_PIN_13
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM35)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM35_PF_TIMG0_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX

/* Defines for PWM_SERVO */
#define PWM_SERVO_INST                                                     TIMA0
#define PWM_SERVO_INST_IRQHandler                               TIMA0_IRQHandler
#define PWM_SERVO_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define PWM_SERVO_INST_CLK_FREQ                                           125000
/* GPIO defines for channel 0 */
#define GPIO_PWM_SERVO_C0_PORT                                             GPIOA
#define GPIO_PWM_SERVO_C0_PIN                                      DL_GPIO_PIN_0
#define GPIO_PWM_SERVO_C0_IOMUX                                   (IOMUX_PINCM1)
#define GPIO_PWM_SERVO_C0_IOMUX_FUNC                  IOMUX_PINCM1_PF_TIMA0_CCP0
#define GPIO_PWM_SERVO_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_SERVO_C1_PORT                                             GPIOA
#define GPIO_PWM_SERVO_C1_PIN                                      DL_GPIO_PIN_1
#define GPIO_PWM_SERVO_C1_IOMUX                                   (IOMUX_PINCM2)
#define GPIO_PWM_SERVO_C1_IOMUX_FUNC                  IOMUX_PINCM2_PF_TIMA0_CCP1
#define GPIO_PWM_SERVO_C1_IDX                                DL_TIMER_CC_1_INDEX



/* Defines for CAPTURE_ENCODER_L_A */
#define CAPTURE_ENCODER_L_A_INST                                         (TIMG6)
#define CAPTURE_ENCODER_L_A_INST_IRQHandler                        TIMG6_IRQHandler
#define CAPTURE_ENCODER_L_A_INST_INT_IRQN                        (TIMG6_INT_IRQn)
#define CAPTURE_ENCODER_L_A_INST_LOAD_VALUE                                (49999U)
/* GPIO defines for channel 0 */
#define GPIO_CAPTURE_ENCODER_L_A_C0_PORT                                   GPIOB
#define GPIO_CAPTURE_ENCODER_L_A_C0_PIN                            DL_GPIO_PIN_2
#define GPIO_CAPTURE_ENCODER_L_A_C0_IOMUX                         (IOMUX_PINCM15)
#define GPIO_CAPTURE_ENCODER_L_A_C0_IOMUX_FUNC             IOMUX_PINCM15_PF_TIMG6_CCP0

/* Defines for CAPTURE_ENCODER_R_A */
#define CAPTURE_ENCODER_R_A_INST                                        (TIMG12)
#define CAPTURE_ENCODER_R_A_INST_IRQHandler                       TIMG12_IRQHandler
#define CAPTURE_ENCODER_R_A_INST_INT_IRQN                       (TIMG12_INT_IRQn)
#define CAPTURE_ENCODER_R_A_INST_LOAD_VALUE                              (3199999U)
/* GPIO defines for channel 0 */
#define GPIO_CAPTURE_ENCODER_R_A_C0_PORT                                   GPIOA
#define GPIO_CAPTURE_ENCODER_R_A_C0_PIN                           DL_GPIO_PIN_10
#define GPIO_CAPTURE_ENCODER_R_A_C0_IOMUX                         (IOMUX_PINCM21)
#define GPIO_CAPTURE_ENCODER_R_A_C0_IOMUX_FUNC            IOMUX_PINCM21_PF_TIMG12_CCP0





/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMA1)
#define TIMER_0_INST_IRQHandler                                 TIMA1_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMA1_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                          (1249U)



/* Defines for Camera_UART */
#define Camera_UART_INST                                                   UART3
#define Camera_UART_INST_FREQUENCY                                      32000000
#define Camera_UART_INST_IRQHandler                             UART3_IRQHandler
#define Camera_UART_INST_INT_IRQN                                 UART3_INT_IRQn
#define GPIO_Camera_UART_RX_PORT                                           GPIOB
#define GPIO_Camera_UART_TX_PORT                                           GPIOA
#define GPIO_Camera_UART_RX_PIN                                   DL_GPIO_PIN_13
#define GPIO_Camera_UART_TX_PIN                                   DL_GPIO_PIN_14
#define GPIO_Camera_UART_IOMUX_RX                                (IOMUX_PINCM30)
#define GPIO_Camera_UART_IOMUX_TX                                (IOMUX_PINCM36)
#define GPIO_Camera_UART_IOMUX_RX_FUNC                 IOMUX_PINCM30_PF_UART3_RX
#define GPIO_Camera_UART_IOMUX_TX_FUNC                 IOMUX_PINCM36_PF_UART3_TX
#define Camera_UART_BAUD_RATE                                           (115200)
#define Camera_UART_IBRD_32_MHZ_115200_BAUD                                 (17)
#define Camera_UART_FBRD_32_MHZ_115200_BAUD                                 (23)





/* Defines for ADC12_0 */
#define ADC12_0_INST                                                        ADC0
#define ADC12_0_INST_IRQHandler                                  ADC0_IRQHandler
#define ADC12_0_INST_INT_IRQN                                    (ADC0_INT_IRQn)
#define ADC12_0_ADCMEM_0                                      DL_ADC12_MEM_IDX_0
#define ADC12_0_ADCMEM_0_REF                     DL_ADC12_REFERENCE_VOLTAGE_VDDA
#define ADC12_0_ADCMEM_0_REF_VOLTAGE_V                                       3.3
#define GPIO_ADC12_0_C0_PORT                                               GPIOA
#define GPIO_ADC12_0_C0_PIN                                       DL_GPIO_PIN_27
#define GPIO_ADC12_0_IOMUX_C0                                    (IOMUX_PINCM60)
#define GPIO_ADC12_0_IOMUX_C0_FUNC                (IOMUX_PINCM60_PF_UNCONNECTED)



/* Port definition for Pin Group GPIO_BUZZER */
#define GPIO_BUZZER_PORT                                                 (GPIOA)

/* Defines for BUZZER: GPIOA.5 with pinCMx 10 on package pin 45 */
#define GPIO_BUZZER_BUZZER_PIN                                   (DL_GPIO_PIN_5)
#define GPIO_BUZZER_BUZZER_IOMUX                                 (IOMUX_PINCM10)
/* Port definition for Pin Group GPIO_ENCODER */
#define GPIO_ENCODER_PORT                                                (GPIOA)

/* Defines for B_L: GPIOA.22 with pinCMx 47 on package pin 18 */
// pins affected by this interrupt request:["B_L","B_R"]
#define GPIO_ENCODER_INT_IRQN                                   (GPIOA_INT_IRQn)
#define GPIO_ENCODER_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_ENCODER_B_L_IIDX                               (DL_GPIO_IIDX_DIO22)
#define GPIO_ENCODER_B_L_PIN                                    (DL_GPIO_PIN_22)
#define GPIO_ENCODER_B_L_IOMUX                                   (IOMUX_PINCM47)
/* Defines for B_R: GPIOA.11 with pinCMx 22 on package pin 57 */
#define GPIO_ENCODER_B_R_IIDX                               (DL_GPIO_IIDX_DIO11)
#define GPIO_ENCODER_B_R_PIN                                    (DL_GPIO_PIN_11)
#define GPIO_ENCODER_B_R_IOMUX                                   (IOMUX_PINCM22)
/* Port definition for Pin Group GPIO_MOTOR */
#define GPIO_MOTOR_PORT                                                  (GPIOB)

/* Defines for DIR_L1: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_MOTOR_DIR_L1_PIN                                   (DL_GPIO_PIN_18)
#define GPIO_MOTOR_DIR_L1_IOMUX                                  (IOMUX_PINCM44)
/* Defines for DIR_R1: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_MOTOR_DIR_R1_PIN                                   (DL_GPIO_PIN_17)
#define GPIO_MOTOR_DIR_R1_IOMUX                                  (IOMUX_PINCM43)
/* Defines for DIR_L2: GPIOB.16 with pinCMx 33 on package pin 4 */
#define GPIO_MOTOR_DIR_L2_PIN                                   (DL_GPIO_PIN_16)
#define GPIO_MOTOR_DIR_L2_IOMUX                                  (IOMUX_PINCM33)
/* Defines for DIR_R2: GPIOB.14 with pinCMx 31 on package pin 2 */
#define GPIO_MOTOR_DIR_R2_PIN                                   (DL_GPIO_PIN_14)
#define GPIO_MOTOR_DIR_R2_IOMUX                                  (IOMUX_PINCM31)
/* Port definition for Pin Group GPIO_STD */
#define GPIO_STD_PORT                                                    (GPIOA)

/* Defines for AD0: GPIOA.2 with pinCMx 7 on package pin 42 */
#define GPIO_STD_AD0_PIN                                         (DL_GPIO_PIN_2)
#define GPIO_STD_AD0_IOMUX                                        (IOMUX_PINCM7)
/* Defines for AD1: GPIOA.3 with pinCMx 8 on package pin 43 */
#define GPIO_STD_AD1_PIN                                         (DL_GPIO_PIN_3)
#define GPIO_STD_AD1_IOMUX                                        (IOMUX_PINCM8)
/* Defines for AD2: GPIOA.4 with pinCMx 9 on package pin 44 */
#define GPIO_STD_AD2_PIN                                         (DL_GPIO_PIN_4)
#define GPIO_STD_AD2_IOMUX                                        (IOMUX_PINCM9)
/* Port definition for Pin Group GPIO_BUTTON */
#define GPIO_BUTTON_PORT                                                 (GPIOB)

/* Defines for BUTTON1: GPIOB.12 with pinCMx 29 on package pin 64 */
#define GPIO_BUTTON_BUTTON1_PIN                                 (DL_GPIO_PIN_12)
#define GPIO_BUTTON_BUTTON1_IOMUX                                (IOMUX_PINCM29)
/* Defines for BUTTON2: GPIOB.11 with pinCMx 28 on package pin 63 */
#define GPIO_BUTTON_BUTTON2_PIN                                 (DL_GPIO_PIN_11)
#define GPIO_BUTTON_BUTTON2_IOMUX                                (IOMUX_PINCM28)
/* Defines for BUTTON3: GPIOB.9 with pinCMx 26 on package pin 61 */
#define GPIO_BUTTON_BUTTON3_PIN                                  (DL_GPIO_PIN_9)
#define GPIO_BUTTON_BUTTON3_IOMUX                                (IOMUX_PINCM26)
/* Defines for BUTTON4: GPIOB.10 with pinCMx 27 on package pin 62 */
#define GPIO_BUTTON_BUTTON4_PIN                                 (DL_GPIO_PIN_10)
#define GPIO_BUTTON_BUTTON4_IOMUX                                (IOMUX_PINCM27)
/* Defines for PIN_SCL: GPIOA.17 with pinCMx 39 on package pin 10 */
#define GPIO_OLED_PIN_SCL_PORT                                           (GPIOA)
#define GPIO_OLED_PIN_SCL_PIN                                   (DL_GPIO_PIN_17)
#define GPIO_OLED_PIN_SCL_IOMUX                                  (IOMUX_PINCM39)
/* Defines for PIN_SDA: GPIOB.15 with pinCMx 32 on package pin 3 */
#define GPIO_OLED_PIN_SDA_PORT                                           (GPIOB)
#define GPIO_OLED_PIN_SDA_PIN                                   (DL_GPIO_PIN_15)
#define GPIO_OLED_PIN_SDA_IOMUX                                  (IOMUX_PINCM32)




/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_PWM_SERVO_init(void);
void SYSCFG_DL_CAPTURE_ENCODER_L_A_init(void);
void SYSCFG_DL_CAPTURE_ENCODER_R_A_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_Camera_UART_init(void);
void SYSCFG_DL_ADC12_0_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
