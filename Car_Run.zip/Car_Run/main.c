#include "main.h"
#include "ti_msp_dl_config.h"

#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "clock.h"
#include "car_para.h"
#include "encoder.h"
#include "follow.h"
#include "key.h"
#include "menu.h"
#include "motor.h"
#include "oled_software_i2c.h"
#include "pid.h"
#include "std_adc.h"
#include "timer.h"

#define DEFAULT_CAR_SPEED_MPS           0.29f
#define MIN_CAR_SPEED_MPS               0.05f
#define MAX_CAR_SPEED_MPS               0.40f
#define SPEED_STEP_MPS                  0.01f
#define DISPLAY_REFRESH_TICKS           10U
#define RUN_START_SPEED_MPS             0.10f
#define RUN_START_RIGHT_TRIM_DEG        0.80f
#define RUN_START_TRIM_TICKS            50U /* 0.50 s */
#define PURE_FOLLOW_LOST_SPEED_MPS      0.10f
#define PURE_FOLLOW_START_MIN_TICKS     25U /* 0.25 s */
#define PURE_FOLLOW_START_TIMEOUT_TICKS 300U /* 3.00 s */
#define PURE_FOLLOW_START_CLEAR_TICKS   3U
#define PURE_FOLLOW_STOP_CONFIRM_TICKS  3U
#define PURE_FOLLOW_STOP_STABLE_SAMPLES 5U
#define PURE_FOLLOW_BRAKE_TIMEOUT_TICKS 400U /* 4.00 s */

#define PURE_TRACK_OVERALL_LENGTH_M     2.50f
#define PURE_TRACK_CURVE_RADIUS_M       0.50f
#define PURE_TRACK_STRAIGHT_LENGTH_M    \
    (PURE_TRACK_OVERALL_LENGTH_M - 2.0f * PURE_TRACK_CURVE_RADIUS_M)
#define PURE_TRACK_RIGHT_LAP_M          \
    (2.0f * PURE_TRACK_STRAIGHT_LENGTH_M + 2.0f * 3.1415926f * \
     (PURE_TRACK_CURVE_RADIUS_M - 0.5f * DRIVE_WHEEL_TRACK_M))

#define PURE_FOLLOW_CURVE_SPEED_MPS     0.24f
#define PURE_FOLLOW_FINISH_CRAWL_MPS    0.06f
#define PURE_FOLLOW_FINISH_APPROACH_M   0.25f
#define PURE_FOLLOW_CURVE_BLEND_START_DEG 2.0f
#define PURE_FOLLOW_CURVE_BLEND_FULL_DEG  8.0f
#define PURE_FOLLOW_MAX_ACCEL_MPS2      0.10f
#define PURE_FOLLOW_MAX_JERK_MPS3       0.30f
#define PURE_FOLLOW_LAUNCH_ACCEL_MPS2   0.04f
#define PURE_FOLLOW_LAUNCH_JERK_MPS3    0.05f
#define PURE_FOLLOW_LAUNCH_BLEND_TICKS  400U /* 4.00 s */
#define PURE_FOLLOW_PROFILE_OMEGA       3.0f
#define PURE_FOLLOW_BRAKE_OMEGA         6.0f
#define PURE_FOLLOW_STOP_REF_MPS        0.005f
#define PURE_FOLLOW_STOP_ACTUAL_MPS     0.020f

#define FAST_LAP_SPEED_MPS              0.40f
#define FAST_LAP_LOST_SPEED_MPS         0.18f
#define FAST_LAP_FINISH_APPROACH_M      0.15f
#define FAST_LAP_FINISH_SPEED_MPS       0.25f
#define FAST_LAP_TIMEOUT_TICKS          2000U /* 20.00 s */

#define BALL_STRAIGHT_SPEED_MPS         0.38f
#define BALL_STRAIGHT_PROFILE_DISTANCE_M 1.457f
#define BALL_STRAIGHT_BRAKE_DECEL_MPS2  0.10f
#define BALL_STRAIGHT_MAX_ACCEL_MPS2    0.18f
#define BALL_STRAIGHT_MAX_JERK_MPS3     0.55f
#define BALL_STRAIGHT_PROFILE_OMEGA     5.0f
#define BALL_STRAIGHT_TIMEOUT_TICKS     800U /* 8.00 s */

static uint16_t line_raw[FOLLOW_SENSOR_COUNT];
static uint16_t line_white[FOLLOW_SENSOR_COUNT] = {
	2442, 2791, 2388, 2588, 1985, 2659, 2408, 2469
};
static uint16_t line_black[FOLLOW_SENSOR_COUNT] = {
	269, 546, 217, 275, 101, 199, 100, 310
};
static float car_speed_mps = DEFAULT_CAR_SPEED_MPS;
static char display_text[32];

int main(void)
 {
    SYSCFG_DL_init();
    SysTick_Init();

    OLED_Init();

    //初始化电机
    DL_TimerG_startCounter(PWM_MOTOR_INST);
    
	//定时器初始化
    Timer_Init();
    
    //灰度初始化
    adc_Init();	//灰度adc初始化
	Follow_Init(line_white, line_black);
    
	//编码器初始化
	Encoder_Init();

	//PID
	PID_Reset(&LeftSpeedPID);
	PID_Reset(&RightSpeedPID);
	PID_Reset(&LinePID);

    while (1)
    {
        Menu_RunMainMenu();
    }
}


/*************************以下函数由菜单选择运行******************************/


/* 灰度标定：UP切换查看/采样，ENTER保存当前采样。 */
static void Line_Calibration_Run(uint16_t reference[FOLLOW_SENSOR_COUNT])
{
	bool capture_mode = false;
	OLED_Clear();
	Key_Reset_All();

	while (1) {
		if (Key_Back_Get()) return;
		if (Key_Up_Get()) {
			capture_mode = !capture_mode;
			OLED_Clear();
		}
		if (capture_mode) Follow_ReadRaw(line_raw);
		if (capture_mode && Key_Enter_Get()) {
			for (uint8_t i = 0; i < FOLLOW_SENSOR_COUNT; i++) {
				reference[i] = line_raw[i];
			}
			Follow_Init(line_white, line_black);
			capture_mode = false;
		}

		const uint16_t *shown = capture_mode ? line_raw : reference;
		for (uint8_t row = 0; row < 4U; row++) {
			snprintf(display_text, sizeof(display_text), "%4u-%4u%c",
			         shown[row * 2U], shown[row * 2U + 1U],
			         row == 0U && capture_mode ? '*' : ' ');
			OLED_Showstr((uint8_t)(row + 1U), 1, display_text);
		}
	}
}

void Line_White_Calibrate(void)
{
	Line_Calibration_Run(line_white);
}

void Line_Black_Calibrate(void)
{
	Line_Calibration_Run(line_black);
}

void Line_Sensor_View(void)
{
	uint8_t display_ticks = DISPLAY_REFRESH_TICKS;
	OLED_Clear();
	OLED_Showstr(1, 1, "Line sensor     ");
	Key_Reset_All();
	Control_TickReset();

	while (1) {
		if (Key_Back_Get() || Key_Enter_Get()) return;
		uint8_t elapsed_ticks = Control_TickTake();
		if (elapsed_ticks == 0U) continue;
		display_ticks = (uint8_t)(display_ticks + elapsed_ticks);
		if (display_ticks < DISPLAY_REFRESH_TICKS) continue;
		display_ticks = 0;

		Follow_Result_t line = Follow_GetResult();
		snprintf(display_text, sizeof(display_text), "B:%02X %s",
		         line.digital, line.line_detected ? "LINE" : "LOST");
		OLED_Showstr(2, 1, display_text);
		snprintf(display_text, sizeof(display_text), "A:%5.1f deg", line.angle_deg);
		OLED_Showstr(3, 1, display_text);
		snprintf(display_text, sizeof(display_text), "Q:%4.2f", line.strength);
		OLED_Showstr(4, 1, display_text);
	}
}

static void Speed_PID_Tune(PID_t *pid, const char *label)
{
	const float step_kp = 1.0f;
	const float step_ki = 10.0f;
	uint8_t selected = 0;
	OLED_Clear();
	Key_Reset_All();

	while (1) {
		if (Key_Back_Get()) return;
		if (Key_Enter_Get()) selected ^= 1U;
		if (Key_Up_Get()) {
			if (selected == 0U) pid->Kp += step_kp;
			else pid->Ki += step_ki;
		}
		if (Key_Down_Get()) {
			if (selected == 0U) pid->Kp -= step_kp;
			else pid->Ki -= step_ki;
		}
		if (pid->Kp < 0.0f) pid->Kp = 0.0f;
		if (pid->Ki < 0.0f) pid->Ki = 0.0f;

		snprintf(display_text, sizeof(display_text), "%s speed PID", label);
		OLED_Showstr(1, 1, display_text);
		snprintf(display_text, sizeof(display_text), "P:%6.1f %c", pid->Kp,
		         selected == 0U ? '*' : ' ');
		OLED_Showstr(2, 1, display_text);
		snprintf(display_text, sizeof(display_text), "I:%6.1f %c", pid->Ki,
		         selected == 1U ? '*' : ' ');
		OLED_Showstr(3, 1, display_text);
	}
}

void Left_Speed_PID_Tune(void)
{
	Speed_PID_Tune(&LeftSpeedPID, "Left");
}

void Right_Speed_PID_Tune(void)
{
	Speed_PID_Tune(&RightSpeedPID, "Right");
}

/* 循迹方向PD调参。 */
void Line_PID_Tune(void)
{
	OLED_Clear();
	uint8_t sel = 0;  // 0=Kp, 1=Kd
	const float stepKp = 0.0005f;
	const float stepKd = 0.00002f;

	Key_Reset_All();
	while (1)
	{
		if (Key_Back_Get()) return;

		if (Key_Enter_Get())
		{
			sel = 1 - sel;
		}

		if (Key_Up_Get())
		{
			if (sel == 0) LinePID.Kp += stepKp;
			else          LinePID.Kd += stepKd;
		}
		if (Key_Down_Get())
		{
			if (sel == 0) LinePID.Kp -= stepKp;
			else          LinePID.Kd -= stepKd;
		}

		// 下限保护
		if (LinePID.Kp < 0) LinePID.Kp = 0;
		if (LinePID.Kd < 0) LinePID.Kd = 0;

		if (sel == 0)
		{
			snprintf(display_text, sizeof(display_text), "Line P:%.4f*", LinePID.Kp);
			OLED_Showstr(2, 1, display_text);
			snprintf(display_text, sizeof(display_text), "Line D:%.5f ", LinePID.Kd);
			OLED_Showstr(3, 1, display_text);
		}
		else
		{
			snprintf(display_text, sizeof(display_text), "Line P:%.4f ", LinePID.Kp);
			OLED_Showstr(2, 1, display_text);
			snprintf(display_text, sizeof(display_text), "Line D:%.5f*", LinePID.Kd);
			OLED_Showstr(3, 1, display_text);
		}
	}
}


/*速度调参设置*/
void Speed_Set(void)
{
	while(1){
		if (Key_Up_Get())
		{
			car_speed_mps += SPEED_STEP_MPS;
		}
		if (Key_Down_Get())
		{
			car_speed_mps -= SPEED_STEP_MPS;
		}
		if (car_speed_mps < MIN_CAR_SPEED_MPS) car_speed_mps = MIN_CAR_SPEED_MPS;
		if (car_speed_mps > MAX_CAR_SPEED_MPS) car_speed_mps = MAX_CAR_SPEED_MPS;
		if (Key_Enter_Get() || Key_Back_Get())
		{
			return;
		}
		//标记
		snprintf(display_text, sizeof(display_text), "Speed:%.2f m/s", car_speed_mps);
		OLED_Showstr(2,1,display_text);
	}
}

/*速度调参启动小车*/
void Speed_Test_Run(void)
{
	uint16_t display_ticks = DISPLAY_REFRESH_TICKS;
	uint8_t display_row = 0U;
	OLED_Clear();
	OLED_Showstr(1, 1, "Speed test m/s ");
	Key_Reset_All();
	Control_TickReset();
	
	while(1)
	{
		//启动
		if (Key_Up_Get())
		{
			car_running = 1;
			PID_Reset(&LeftSpeedPID);
			PID_Reset(&RightSpeedPID);
			PID_Reset(&LinePID);
			Encoder_Start();
			OLED_Showchar(3,16,'+');	//指示
		}
		//停止
		if (Key_Down_Get())
		{
			Car_stop();
			OLED_Showchar(3,16,' ');
		}
		if (Key_Enter_Get() || Key_Back_Get())
		{
			Car_stop();
			return;
		}
		
		/*编码器&PID运算 0.01s采样一次*/
		uint8_t elapsed_ticks = Control_TickTake();
		if (elapsed_ticks > 0U && car_running)
		{
			float control_dt = (float)elapsed_ticks * CONTROL_TICK_S;
			/***速度采样与PID运算***/
			Motor_SampleSpeed(control_dt);
			Motor_SpeedControl(car_speed_mps, control_dt);

			display_ticks = (uint16_t)(display_ticks + elapsed_ticks);
			if (display_ticks >= DISPLAY_REFRESH_TICKS) {
				display_ticks = 0U;
				if (display_row == 0U) {
					snprintf(display_text, sizeof(display_text), "T:%.2f m/s     ", car_speed_mps);
					OLED_Showstr(2, 1, display_text);
				} else if (display_row == 1U) {
					snprintf(display_text, sizeof(display_text), "L:%.3f m/s     ", speed_left_mps);
					OLED_Showstr(3, 1, display_text);
				} else {
					snprintf(display_text, sizeof(display_text), "R:%.3f m/s     ", speed_right_mps);
					OLED_Showstr(4, 1, display_text);
				}
				display_row = (uint8_t)((display_row + 1U) % 3U);
			}
		}
		//串口发送
		
	}
}

/*圈数设置*/

static float AbsF(float value)
{
	return (value >= 0.0f) ? value : -value;
}

static float ClampF(float value, float minimum, float maximum)
{
	if (value < minimum) return minimum;
	if (value > maximum) return maximum;
	return value;
}

static float Startup_RightTrimDeg(uint32_t run_ticks)
{
	if (run_ticks >= RUN_START_TRIM_TICKS) return 0.0f;
	return RUN_START_RIGHT_TRIM_DEG *
	       (float)(RUN_START_TRIM_TICKS - run_ticks) /
	       (float)RUN_START_TRIM_TICKS;
}

static uint8_t SaturatingAddU8(uint8_t value, uint8_t increment)
{
	return (increment > (uint8_t)(UINT8_MAX - value)) ? UINT8_MAX :
	       (uint8_t)(value + increment);
}

static void Control_ResetAllPid(void)
{
	PID_Reset(&LeftSpeedPID);
	PID_Reset(&RightSpeedPID);
	PID_Reset(&LinePID);
}

/* A centred 5 cm transverse marker covers at least four adjacent 12 mm sensors. */
static bool Pure_LineStopMarkerDetected(uint8_t digital)
{
	uint8_t four_adjacent = digital;
	four_adjacent &= (uint8_t)(digital >> 1U);
	four_adjacent &= (uint8_t)(digital >> 2U);
	four_adjacent &= (uint8_t)(digital >> 3U);
	return four_adjacent != 0U;
}

static float Pure_LineTrackSpeedLimit(const Follow_Result_t *line,
                                      float right_distance_m)
{
	if (!line->line_detected) return PURE_FOLLOW_LOST_SPEED_MPS;

	float straight_speed = car_speed_mps;
	float curve_speed = (straight_speed < PURE_FOLLOW_CURVE_SPEED_MPS) ?
	                    straight_speed : PURE_FOLLOW_CURVE_SPEED_MPS;
	float curve_blend = (AbsF(line->angle_deg) -
	                     PURE_FOLLOW_CURVE_BLEND_START_DEG) /
	                    (PURE_FOLLOW_CURVE_BLEND_FULL_DEG -
	                     PURE_FOLLOW_CURVE_BLEND_START_DEG);
	curve_blend = ClampF(curve_blend, 0.0f, 1.0f);
	float speed_limit = straight_speed -
	                    curve_blend * (straight_speed - curve_speed);

	float remaining_right_m = PURE_TRACK_RIGHT_LAP_M - right_distance_m;
	if (remaining_right_m < PURE_FOLLOW_FINISH_APPROACH_M) {
		float finish_blend = ClampF(
			remaining_right_m / PURE_FOLLOW_FINISH_APPROACH_M, 0.0f, 1.0f);
		float finish_limit = PURE_FOLLOW_FINISH_CRAWL_MPS +
			(curve_speed - PURE_FOLLOW_FINISH_CRAWL_MPS) * finish_blend;
		if (speed_limit > finish_limit) speed_limit = finish_limit;
	}
	return speed_limit;
}

static float Pure_LineUpdateSpeedProfile(float target_speed_mps,
                                         float speed_mps,
                                         float *acceleration_mps2,
                                         float response_omega,
                                         float max_acceleration_mps2,
                                         float max_jerk_mps3,
                                         float sample_time_s)
{
	float desired_acceleration =
		response_omega * response_omega * (target_speed_mps - speed_mps) -
		2.0f * response_omega * *acceleration_mps2;
	desired_acceleration = ClampF(desired_acceleration,
	                              -max_acceleration_mps2,
	                               max_acceleration_mps2);

	float max_acceleration_step = max_jerk_mps3 * sample_time_s;
	float acceleration_step = ClampF(desired_acceleration - *acceleration_mps2,
	                                 -max_acceleration_step,
	                                  max_acceleration_step);
	*acceleration_mps2 += acceleration_step;
	speed_mps += *acceleration_mps2 * sample_time_s;

	if (speed_mps < 0.0f) {
		speed_mps = 0.0f;
		*acceleration_mps2 = 0.0f;
	}
	return speed_mps;
}

void Pure_Line_Follow_Run(void)
{
	typedef enum {
		PURE_STARTING,
		PURE_TRACKING,
		PURE_BRAKING,
		PURE_STOPPED
	} PureLineState;

	uint32_t run_ticks = 0U;
	uint16_t display_ticks = DISPLAY_REFRESH_TICKS;
	uint16_t start_ticks = 0U;
	uint16_t launch_blend_ticks = 0U;
	uint16_t brake_ticks = 0U;
	uint8_t start_clear_ticks = 0U;
	uint8_t stop_confirm_ticks = 0U;
	uint8_t stop_stable_samples = 0U;
	float speed_reference_mps = RUN_START_SPEED_MPS;
	float acceleration_reference_mps2 = 0.0f;
	float right_distance_m = 0.0f;
	float last_line_angle_deg = 0.0f;
	PureLineState state = PURE_STARTING;

	OLED_Clear();
	OLED_Showstr(2, 1, "Time: 0.0 s     ");
	Key_Reset_All();
	Car_stop();
	Control_ResetAllPid();
	Encoder_Start();
	car_running = true;
	Control_TickReset();

	while (1) {
		if (Key_Back_Get() || Key_Enter_Get()) {
			Car_stop();
			Key_Reset_All();
			return;
		}

		uint8_t elapsed_ticks = Control_TickTake();
		if (elapsed_ticks == 0U) continue;
		float control_dt = (float)elapsed_ticks * CONTROL_TICK_S;
		if (state == PURE_STOPPED) continue;
		run_ticks += elapsed_ticks;

		Motor_SampleSpeed(control_dt);
		if (speed_right_mps > 0.0f && speed_right_mps < 0.50f) {
			right_distance_m += speed_right_mps * control_dt;
		}
		Follow_Result_t line = Follow_GetResult();
		bool stop_marker = Pure_LineStopMarkerDetected(line.digital);
		if (line.line_detected) last_line_angle_deg = line.angle_deg;

		if (state == PURE_STARTING) {
			start_ticks = (uint16_t)(start_ticks + elapsed_ticks);
			if (!stop_marker && line.line_detected) {
				start_clear_ticks = SaturatingAddU8(start_clear_ticks, 1U);
			} else {
				start_clear_ticks = 0U;
			}
			if (start_ticks >= PURE_FOLLOW_START_MIN_TICKS &&
			    start_clear_ticks >= PURE_FOLLOW_START_CLEAR_TICKS) {
				stop_confirm_ticks = 0U;
				state = PURE_TRACKING;
			} else if (start_ticks >= PURE_FOLLOW_START_TIMEOUT_TICKS) {
				brake_ticks = 0U;
				stop_stable_samples = 0U;
				state = PURE_BRAKING;
				PID_Reset(&LinePID);
			}
		} else if (state == PURE_TRACKING) {
			if (stop_marker) {
				stop_confirm_ticks = SaturatingAddU8(stop_confirm_ticks, 1U);
			} else {
				stop_confirm_ticks = 0U;
			}

			if (stop_confirm_ticks >= PURE_FOLLOW_STOP_CONFIRM_TICKS) {
				brake_ticks = 0U;
				stop_stable_samples = 0U;
				state = PURE_BRAKING;
				PID_Reset(&LinePID);
			}
		}

		float target_speed_mps = (state == PURE_BRAKING) ? 0.0f :
			Pure_LineTrackSpeedLimit(&line, right_distance_m);
		float response_omega = (state == PURE_BRAKING) ?
			PURE_FOLLOW_BRAKE_OMEGA : PURE_FOLLOW_PROFILE_OMEGA;
		float profile_max_acceleration_mps2 = PURE_FOLLOW_MAX_ACCEL_MPS2;
		float profile_max_jerk_mps3 = PURE_FOLLOW_MAX_JERK_MPS3;
		if (state != PURE_BRAKING &&
		    launch_blend_ticks < PURE_FOLLOW_LAUNCH_BLEND_TICKS) {
			float launch_blend = (float)launch_blend_ticks /
			                     (float)PURE_FOLLOW_LAUNCH_BLEND_TICKS;
			profile_max_acceleration_mps2 = PURE_FOLLOW_LAUNCH_ACCEL_MPS2 +
				(PURE_FOLLOW_MAX_ACCEL_MPS2 -
				 PURE_FOLLOW_LAUNCH_ACCEL_MPS2) * launch_blend;
			profile_max_jerk_mps3 = PURE_FOLLOW_LAUNCH_JERK_MPS3 +
				(PURE_FOLLOW_MAX_JERK_MPS3 -
				 PURE_FOLLOW_LAUNCH_JERK_MPS3) * launch_blend;

			uint16_t remaining_blend_ticks =
				(uint16_t)(PURE_FOLLOW_LAUNCH_BLEND_TICKS -
				           launch_blend_ticks);
			launch_blend_ticks = (elapsed_ticks >= remaining_blend_ticks) ?
				PURE_FOLLOW_LAUNCH_BLEND_TICKS :
				(uint16_t)(launch_blend_ticks + elapsed_ticks);
		}
		speed_reference_mps = Pure_LineUpdateSpeedProfile(
			target_speed_mps, speed_reference_mps,
			&acceleration_reference_mps2, response_omega,
			profile_max_acceleration_mps2, profile_max_jerk_mps3,
			control_dt);

		if (state == PURE_BRAKING) {
			brake_ticks = (uint16_t)(brake_ticks + elapsed_ticks);
			Motor_SpeedControl(speed_reference_mps, control_dt);
			if (speed_reference_mps <= PURE_FOLLOW_STOP_REF_MPS &&
			    AbsF(speed_right_mps) <= PURE_FOLLOW_STOP_ACTUAL_MPS) {
				stop_stable_samples = SaturatingAddU8(stop_stable_samples, 1U);
			} else {
				stop_stable_samples = 0U;
			}
			if (stop_stable_samples >= PURE_FOLLOW_STOP_STABLE_SAMPLES ||
			    brake_ticks >= PURE_FOLLOW_BRAKE_TIMEOUT_TICKS) {
				Car_stop();
				state = PURE_STOPPED;
				snprintf(display_text, sizeof(display_text),
				         "Time:%.1f s     ",
				         (float)run_ticks * CONTROL_TICK_S);
				OLED_Showstr(2, 1, display_text);
				continue;
			}
		} else {
			float steering_angle_deg = last_line_angle_deg +
			                           Startup_RightTrimDeg(run_ticks);
			Motor_CascadeControl(steering_angle_deg, speed_reference_mps,
			                     &LinePID, control_dt);
		}

		display_ticks = (uint16_t)(display_ticks + elapsed_ticks);
		if (display_ticks >= DISPLAY_REFRESH_TICKS) {
			display_ticks = 0U;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
		}
	}
}

void Fast_Full_Lap_Run(void)
{
	uint32_t run_ticks = 0U;
	uint16_t display_ticks = DISPLAY_REFRESH_TICKS;
	uint8_t start_clear_samples = 0U;
	uint8_t stop_confirm_samples = 0U;
	float right_distance_m = 0.0f;
	float last_line_angle_deg = 0.0f;
	bool finish_armed = false;
	bool stopped = false;

	OLED_Clear();
	OLED_Showstr(2, 1, "Time: 0.0 s     ");
	Key_Reset_All();
	Car_stop();
	Control_ResetAllPid();
	Encoder_Start();
	car_running = true;
	Control_TickReset();

	while (1) {
		if (Key_Back_Get() || Key_Enter_Get()) {
			Car_stop();
			Key_Reset_All();
			return;
		}

		uint8_t elapsed_ticks = Control_TickTake();
		if (elapsed_ticks == 0U) continue;
		if (stopped) continue;
		run_ticks += elapsed_ticks;
		float control_dt = (float)elapsed_ticks * CONTROL_TICK_S;

		Motor_SampleSpeed(control_dt);
		if (speed_right_mps > 0.0f && speed_right_mps < 0.50f)
			right_distance_m += speed_right_mps * control_dt;
		Follow_Result_t line = Follow_GetResult();
		bool stop_marker = Pure_LineStopMarkerDetected(line.digital);
		if (line.line_detected) last_line_angle_deg = line.angle_deg;

		if (!finish_armed) {
			if (!stop_marker && line.line_detected) {
				start_clear_samples = SaturatingAddU8(start_clear_samples, 1U);
			} else {
				start_clear_samples = 0U;
			}
			if (start_clear_samples >= PURE_FOLLOW_START_CLEAR_TICKS)
				finish_armed = true;
		} else {
			if (stop_marker) {
				stop_confirm_samples = SaturatingAddU8(stop_confirm_samples, 1U);
			} else {
				stop_confirm_samples = 0U;
			}
		}

		if (finish_armed &&
		    stop_confirm_samples >= PURE_FOLLOW_STOP_CONFIRM_TICKS) {
			Car_stop();
			stopped = true;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
			continue;
		}

		if (run_ticks >= FAST_LAP_TIMEOUT_TICKS) {
			Car_stop();
			stopped = true;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
			continue;
		}

		float target_speed_mps = line.line_detected ?
			FAST_LAP_SPEED_MPS : FAST_LAP_LOST_SPEED_MPS;
		if (finish_armed) {
			float remaining_right_m = PURE_TRACK_RIGHT_LAP_M - right_distance_m;
			if (remaining_right_m < FAST_LAP_FINISH_APPROACH_M) {
				float finish_blend = ClampF(
					remaining_right_m / FAST_LAP_FINISH_APPROACH_M,
					0.0f, 1.0f);
				float finish_limit = FAST_LAP_FINISH_SPEED_MPS +
					(FAST_LAP_SPEED_MPS - FAST_LAP_FINISH_SPEED_MPS) *
					finish_blend;
				if (target_speed_mps > finish_limit)
					target_speed_mps = finish_limit;
			}
		}
		Motor_CascadeControl(last_line_angle_deg, target_speed_mps,
		                     &LinePID, control_dt);

		display_ticks = (uint16_t)(display_ticks + elapsed_ticks);
		if (display_ticks >= DISPLAY_REFRESH_TICKS) {
			display_ticks = 0U;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
		}
	}
}

void Ball_Straight_Run(void)
{
	uint32_t run_ticks = 0U;
	uint16_t display_ticks = DISPLAY_REFRESH_TICKS;
	uint8_t stop_stable_samples = 0U;
	float speed_reference_mps = RUN_START_SPEED_MPS;
	float acceleration_reference_mps2 = 0.0f;
	float right_distance_m = 0.0f;
	float last_line_angle_deg = 0.0f;
	bool stopped = false;

	OLED_Clear();
	OLED_Showstr(2, 1, "Time: 0.0 s     ");
	Key_Reset_All();
	Car_stop();
	Control_ResetAllPid();
	Encoder_Start();
	car_running = true;
	Control_TickReset();

	while (1) {
		if (Key_Back_Get() || Key_Enter_Get()) {
			Car_stop();
			Key_Reset_All();
			return;
		}

		uint8_t elapsed_ticks = Control_TickTake();
		if (elapsed_ticks == 0U) continue;
		if (stopped) continue;
		run_ticks += elapsed_ticks;
		float control_dt = (float)elapsed_ticks * CONTROL_TICK_S;

		Motor_SampleSpeed(control_dt);
		if (speed_right_mps > 0.0f && speed_right_mps < 0.50f)
			right_distance_m += speed_right_mps * control_dt;
		Follow_Result_t line = Follow_GetResult();
		if (line.line_detected) last_line_angle_deg = line.angle_deg;

		float remaining_m = BALL_STRAIGHT_PROFILE_DISTANCE_M - right_distance_m;
		if (remaining_m < 0.0f) remaining_m = 0.0f;
		float target_speed_mps = sqrtf(
			2.0f * BALL_STRAIGHT_BRAKE_DECEL_MPS2 * remaining_m);
		if (target_speed_mps > BALL_STRAIGHT_SPEED_MPS)
			target_speed_mps = BALL_STRAIGHT_SPEED_MPS;
		if (!line.line_detected && target_speed_mps > PURE_FOLLOW_LOST_SPEED_MPS)
			target_speed_mps = PURE_FOLLOW_LOST_SPEED_MPS;

		speed_reference_mps = Pure_LineUpdateSpeedProfile(
			target_speed_mps, speed_reference_mps,
			&acceleration_reference_mps2, BALL_STRAIGHT_PROFILE_OMEGA,
			BALL_STRAIGHT_MAX_ACCEL_MPS2, BALL_STRAIGHT_MAX_JERK_MPS3,
			control_dt);

		if (speed_reference_mps <= 0.08f) {
			Motor_SpeedControl(speed_reference_mps, control_dt);
		} else {
			float steering_angle_deg = last_line_angle_deg +
			                           Startup_RightTrimDeg(run_ticks);
			Motor_CascadeControl(steering_angle_deg, speed_reference_mps,
			                     &LinePID, control_dt);
		}

		if (right_distance_m > 1.0f &&
		    speed_reference_mps <= PURE_FOLLOW_STOP_REF_MPS &&
		    AbsF(speed_right_mps) <= PURE_FOLLOW_STOP_ACTUAL_MPS) {
			stop_stable_samples = SaturatingAddU8(stop_stable_samples, 1U);
		} else {
			stop_stable_samples = 0U;
		}

		if (stop_stable_samples >= PURE_FOLLOW_STOP_STABLE_SAMPLES) {
			Car_stop();
			stopped = true;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
			continue;
		}

		if (run_ticks >= BALL_STRAIGHT_TIMEOUT_TICKS) {
			Car_stop();
			stopped = true;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
			continue;
		}

		display_ticks = (uint16_t)(display_ticks + elapsed_ticks);
		if (display_ticks >= DISPLAY_REFRESH_TICKS) {
			display_ticks = 0U;
			snprintf(display_text, sizeof(display_text), "Time:%.1f s     ",
			         (float)run_ticks * CONTROL_TICK_S);
			OLED_Showstr(2, 1, display_text);
		}
	}
}



/* 逆时针航向为负：丢线确认 -> 轮轴前移至角点 -> 制动 -> 航向-90°。 */

/* 半圆循迹：稳定丢线后保持末端切线航向，重新识线后恢复循迹。 */
/* 电机/编码器诊断：固定PWM开环输出，速度统一显示为m/s。 */
void Encoder_Motor_Test(void)
{
	OLED_Clear();
	OLED_Showstr(1, 1, "Encoder m/s    ");

	Key_Reset_All();

	int16_t duty = 20;   // 默认占空比
	bool running = 0;
	uint16_t display_ticks = DISPLAY_REFRESH_TICKS;
	uint8_t display_row = 0U;
	Control_TickReset();

	while (1)
	{
		// 退出
		if (Key_Back_Get())
		{
			Car_stop();
			Key_Reset_All();
			return;
		}

		// 启动/停止
		if (Key_Enter_Get())
		{
			if (running)
			{
				Car_stop();
				running = 0;
			}
			else
			{
				car_running = 1;
				Encoder_Start();
				PID_Reset(&LeftSpeedPID);
				PID_Reset(&RightSpeedPID);
				running = 1;
			}
		}

		// 调节占空比
		if (Key_Up_Get())
		{
			duty += 5;
			if (duty > MOTOR_MAX_DUTY) duty = MOTOR_MAX_DUTY;
		}
		if (Key_Down_Get())
		{
			duty -= 5;
			if (duty < -MOTOR_MAX_DUTY) duty = -MOTOR_MAX_DUTY;
		}

		/* 编码器保持100Hz采样，OLED仅10Hz刷新。 */
		uint8_t elapsed_ticks = Control_TickTake();
		if (elapsed_ticks > 0U)
		{
			if (running)
			{
				Encoder_GetVelocity((float)elapsed_ticks * CONTROL_TICK_S,
				                    &speed_left_mps, &speed_right_mps);

				// 固定PWM开环输出（不经PID）
				motorL_setv(duty);
				motorR_setv(duty);
			}

			display_ticks = (uint16_t)(display_ticks + elapsed_ticks);
			if (display_ticks >= DISPLAY_REFRESH_TICKS) {
				display_ticks = 0U;
				if (display_row == 0U) {
					snprintf(display_text, sizeof(display_text), "D%d I%lu/O%lu M%u", duty,
					         (unsigned long)encoder_invalid_transition_count,
					         (unsigned long)control_overrun_count,
					         control_max_pending_ticks);
					OLED_Showstr(2, 1, display_text);
				} else if (display_row == 1U) {
					snprintf(display_text, sizeof(display_text), "L:%.3f m/s     ", speed_left_mps);
					OLED_Showstr(3, 1, display_text);
				} else {
					snprintf(display_text, sizeof(display_text), "R:%.3f m/s     ", speed_right_mps);
					OLED_Showstr(4, 1, display_text);
				}
				display_row = (uint8_t)((display_row + 1U) % 3U);
			}
		}
	}
}
