#ifndef SYSTEM_CLOCK_H
#define SYSTEM_CLOCK_H

#include <stdint.h>

extern volatile uint32_t tick_ms;

void mspm0_delay_ms(uint32_t milliseconds);
int mspm0_get_clock_ms(unsigned long *count);
void SysTick_Init(void);

#endif
