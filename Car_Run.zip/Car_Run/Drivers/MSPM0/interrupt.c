#include "ti_msp_dl_config.h"
#include "clock.h"
#include "encoder.h"

volatile uint32_t unexpected_group1_interrupt;
volatile uint32_t fault_id;
volatile uint32_t fault_detail;
volatile uint32_t fault_icsr;
volatile uint32_t fault_hfsr;

void SysTick_Handler(void)
{
    tick_ms++;
}

void GROUP1_IRQHandler(void)
{
    uint32_t source = DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1);
    if (source == GPIO_ENCODER_INT_IIDX) {
        Encoder_HandleGpioInterrupt();
    } else {
        unexpected_group1_interrupt = source;
    }
}

/* 保留故障快照，便于烧录后通过调试器定位不可恢复异常。 */
void NMI_Handler(void)
{
    fault_id = 1U;
    fault_detail = *(volatile uint32_t *)0x40801050U;
    while (1) {}
}

void HardFault_Handler(void)
{
    fault_id = 2U;
    fault_icsr = *(volatile uint32_t *)0xE000ED04U;
    fault_hfsr = *(volatile uint32_t *)0xE000ED2CU;
    while (1) {}
}
