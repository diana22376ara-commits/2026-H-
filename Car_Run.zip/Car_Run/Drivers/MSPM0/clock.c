#include "clock.h"

#include <stddef.h>
#include "ti_msp_dl_config.h"

volatile uint32_t tick_ms;

void mspm0_delay_ms(uint32_t milliseconds)
{
    uint32_t start_ms = tick_ms;
    while ((uint32_t)(tick_ms - start_ms) < milliseconds) {}
}

int mspm0_get_clock_ms(unsigned long *count)
{
    if (count == NULL) return 1;
    *count = tick_ms;
    return 0;
}

/* 覆盖SysConfig弱定义，SysTick统一在SysTick_Init中配置。 */
void SYSCFG_DL_SYSTICK_init(void)
{
}

void SysTick_Init(void)
{
    DL_SYSTICK_config(CPUCLK_FREQ / 1000U);
    NVIC_SetPriority(SysTick_IRQn, 0);
    DL_SYSTICK_enable();
}
