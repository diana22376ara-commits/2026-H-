################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Drivers/OLED_Software_I2C/%.o: ../Drivers/OLED_Software_I2C/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"C:/Users/LENOVO/Desktop/CCS/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/Drivers/OLED_Software_I2C" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/Drivers/MPU6050" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/Hardware" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/menu" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/System" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/Debug" -I"C:/TI/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_10_00_04/source" -I"D:/TI/CCS/mpu6050-oled-software-i2c-normal/Drivers/MSPM0" -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"Drivers/OLED_Software_I2C/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


