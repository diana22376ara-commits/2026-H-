#include "pid.h"

#include <stdbool.h>

#define PID_DEFAULT_SAMPLE_TIME_S 0.01f

/* Preserve the baseline loop gain after correcting wheel radius 32.1 -> 33.3 mm. */
PID_t LeftSpeedPID = {
    .Kp = 58.0f, .Ki = 386.0f, .Kd = 0.0f,
    .OutMax = 80.0f, .OutMin = -80.0f
};

PID_t RightSpeedPID = {
    .Kp = 58.0f, .Ki = 386.0f, .Kd = 0.0f,
    .OutMax = 80.0f, .OutMin = -80.0f
};

/* 0.5 m curve at 0.40 m/s outer-wheel limit needs 0.0587 m/s differential. */
PID_t LinePID = {
    .Kp = 0.0120f, .Ki = 0.0f, .Kd = 0.00015f,
    .OutMax = 0.06f, .OutMin = -0.06f,
    .DFilterTau = 0.04f
};

static float PID_Clamp(float value, float minimum, float maximum)
{
    if (value > maximum) return maximum;
    if (value < minimum) return minimum;
    return value;
}

void PID_Reset(PID_t *pid)
{
    pid->Out = 0.0f;
    pid->Error0 = 0.0f;
    pid->ErrorInt = 0.0f;
    pid->Derivative = 0.0f;
}

float PID_UpdatePosition(PID_t *pid, float error, float sample_time_s)
{
    if (sample_time_s <= 0.0f) sample_time_s = PID_DEFAULT_SAMPLE_TIME_S;

    float raw_derivative = (error - pid->Error0) / sample_time_s;
    float alpha = sample_time_s / (pid->DFilterTau + sample_time_s);
    if (alpha > 1.0f) alpha = 1.0f;
    pid->Derivative += alpha * (raw_derivative - pid->Derivative);

    float candidate_integral = pid->ErrorInt + error * sample_time_s;
    float unconstrained = pid->Kp * error + pid->Ki * candidate_integral +
                          pid->Kd * pid->Derivative;
    pid->Out = PID_Clamp(unconstrained, pid->OutMin, pid->OutMax);
    if (pid->Ki != 0.0f && pid->Out == unconstrained)
        pid->ErrorInt = candidate_integral;

    pid->Error0 = error;
    return pid->Out;
}

float PID_UpdateIncremental(PID_t *pid, float target, float actual,
                            float sample_time_s)
{
    if (sample_time_s <= 0.0f) sample_time_s = PID_DEFAULT_SAMPLE_TIME_S;

    float error = target - actual;
    float delta_out = pid->Kp * (error - pid->Error0) +
                      pid->Ki * error * sample_time_s;
    bool drives_high_saturation = pid->Out >= pid->OutMax && delta_out > 0.0f;
    bool drives_low_saturation = pid->Out <= pid->OutMin && delta_out < 0.0f;
    if (!drives_high_saturation && !drives_low_saturation)
        pid->Out += delta_out;

    pid->Out = PID_Clamp(pid->Out, pid->OutMin, pid->OutMax);
    pid->Error0 = error;
    return pid->Out;
}
