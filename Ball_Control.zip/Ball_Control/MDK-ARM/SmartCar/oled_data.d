smartcar\oled_data.o: ..\Core\Src\OLED_Data.c
smartcar\oled_data.o: ../Core/Inc/OLED_Data.h
smartcar\oled_data.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
