# 设计依据与复核记录

## 资料范围

本工程按 STM32F103C8T6（STM32F103x8，中容量器件）设计，核对了以下资料：

1. ST DS5319 Rev 20：LQFP48 引脚、主功能与复用功能、电源和 I/O 电气限制。
2. ST RM0008 Rev 21：RCC、GPIO/AFIO、TIM2 PWM/中断、USART1 和 NVIC。
3. ST ES096 Rev 15：STM32F103x8/xB 已知限制。USART 接收使用 RXNE 逐字节中断，不依赖存在限制条件的 Receive-to-Idle；TIM2 使用固定 CCR 的边沿对齐 PWM1。
4. WHEELTEC 本地《步进电机驱动.pdf》及同目录 STM32F103RCT6/D36A 配套例程：D36A 端子、拨码方向和板卡 EN 实际连接方式。
5. 杭州中科微 ATD5984-S402-V1.3：逻辑电平、STEP/DIR 时序、nSLEEP 唤醒时间、细分真值表和 VBB/电流边界。

## 时钟树

| 项目 | 设置 | 结果/约束 |
|---|---|---|
| HSE | 8 MHz 晶振 | 数据手册允许 4-16 MHz |
| PLL | HSE ×9 | SYSCLK 72 MHz，不超过芯片上限 |
| AHB | /1 | HCLK 72 MHz |
| APB1 | /2 | PCLK1 36 MHz，不超过 APB1 上限 |
| TIM2 | APB1 预分频不为 1，定时器时钟 ×2 | TIM2CLK 72 MHz |
| TIM2 PSC | 71 | 1 MHz 计数，即 1 us/tick |
| APB2 | /1 | PCLK2 72 MHz，USART1 使用该时钟 |
| Flash | 2 wait states | 72 MHz 配置 |

## 引脚复用核对

- TIM2 Partial Remap 1 将 TIM2_CH1 从 PA0 映射到 PA15，用作 D36A ST1，与参考云台 Pitch STEP 相同。
- PB10/PB11 为普通推挽 GPIO，用作 D36A DIR1/EN1，与参考云台 Pitch 通道相同。
- PA9/PA10 默认复用为 USART1_TX/RX，未设置 USART1_REMAP。
- PB8/PB9、PB13/PB14/PB15 和 PA1 均作为普通 GPIO，不与本工程外设冲突；PA1 虽可复用为 TIM2_CH2 或 ADC12_IN1，但本工程只启用 TIM2_CH1 且未启用 ADC。
- 因 PA15 默认是 JTDI，AFIO 配置为 `SWJ_NOJTAG`：关闭 JTAG-DP、保留 PA13/PA14 的 SWD；没有完全关闭 SWJ。当前 HAL 的 TIM2 remap 宏也会写 `MAPR.SWJ_CFG`，所以代码在 `TIM2_PARTIAL_1` 之后再次明确执行 `SWJ_NOJTAG`，避免重映射覆盖调试口状态。
- PC13 只驱动低速状态 LED。

0 cm、−5 cm和Camera基准点校准都使用D36A单脉冲相对运动，默认3200 pulse/rev下为0.1125°/pulse。0 cm建议值为−160脉冲；−5 cm和Camera页面分别保存独立绝对脉冲位置，保存后通过单向脉冲运动自动返回0 cm。三值均只保存在RAM。Balance使用0 cm，Balance Ref使用Camera基准点，两者调用同一个BallBalance状态机并共用全局参数；−5 cm值只用于Preset第四段公式和完成后的机械锁定位置。

## D36A 接口语义复核

配套 PDF 文字把 EN1 写成高电平失能，但配套源代码在 `ATD5984_Init()` 中把同一板卡端子作为 SLEEP，并在输出 PWM 前置高。ATD5984 数据手册规定 `nSLEEP=0` 休眠、`nSLEEP=1` 工作，且从休眠恢复后必须等待 1 ms 才能送 STEP。因此工程按板卡配套例程和芯片定义实现：

- PB11 高：D36A 通道 1 唤醒并使能；底层等待 1 ms。
- PB11 低：D36A 通道 1 休眠；只用于上电初始化窗口、运动超时、状态机故障和处理器异常。
- PA15 的 STEP 上升沿有效。
- PB10 的 DIR 必须在 STEP 上升沿前稳定至少 200 ns。
- STEP 高、低电平宽度均至少 1 us。

ATD5984 逻辑高门限为 2.8 V，STM32F103 的 3.3 V 推挽输出可直接连接；不再使用 DM430 所需的开集电极接口。因为 D36A 没有 DM430 控制端光耦，MCU GND 与 D36A GND 必须连接。

## D36A 脉冲时序

驱动同时提供 STEP 频率和机械 RPM 两种表示。换算关系为 `RPM = STEP_Hz × 60 / pulse_per_rev`；摄像头控制默认3200 pulse/rev、1500 Hz，对应28.125 RPM。RPM设置接口最终仍换算成受100~20000 Hz边界约束的硬件脉冲频率，且电机运行期间拒绝修改。

软件频率限制为 100-20000 Hz。最高 20 kHz 时周期为 50 us，50% PWM 的高、低电平各 25 us，相对于芯片 1 us 最小要求有 25 倍裕量。

换向时 TIM2 先关闭 ST 输出，PB10 改变方向后由 1 MHz 计数器等待 1 us，再启动下一方向的首个 STEP 上升沿；相对于 200 ns 建立时间有 5 倍裕量。RM0008 规定自动重装载值为 0 时计数器被阻塞，因此 1 us 建立阶段使用 `ARR=1、CNT=1`，在下一个计数时钟产生更新事件，绝不写入 `ARR=0`。脉冲在 PWM 下降沿比较中断计数，最后一次下降沿后立即关闭通道，不会多输出窄脉冲。

Cycle Test默认100脉冲、1500 Hz的往返动作时序为：

```text
EN1 拉高并等待 1 ms（只在由休眠进入运行时发生）
DIR 建立 1 us
正向100脉冲：约66.667 ms
反向 DIR 建立 1 us
反向100脉冲：约66.667 ms
动作总长：约133.335 ms（不含首次唤醒）
```

摄像头按100 Hz发送时，每帧间隔10 ms。典型边界行`V:-123.456cm/s,LOCATION:-123.456\r\n`为34字节，按8N1计算占`34 × 10 × 100 = 34000 bit/s`，约为115200 baud的29.51%。64字节行缓冲足够；32项环形队列有效容量31帧，可缓存约310 ms数据。PID电机默认1500 Hz、每块10脉冲，单块约6.667 ms，小于一个摄像头周期；若目标尚未到达，块完成后按最新目标继续，不执行过时的长动作。

## 位置控制叠加速度阻尼模型与初值

摄像头Location和V统一采用向下为正的坐标：Location正数表示钢球在目标下方、负数表示上方；V正数表示向下运动、负数表示向上运动。位置误差定义为`e=-Location`。组合帧速度先按`v_f=v_f+alpha_v*(V-v_f)`进行一阶低通，再用于`x_pred=x_hat+v_f*dt`位置预测和反向速度阻尼；默认`alpha_v=0.25`，100 Hz采样下等效截止频率约4.58 Hz、低频平均滞后约30 ms。位置以`x_hat=x_pred+alpha_x*(Location-x_pred)`平滑。旧Location单字段帧仍兼容：此时才使用`v_hat=v_hat+beta*r/dt`估速。位置原始差分超过300 cm/s或摄像头速度超出±300 cm/s时重置控制器，防止错帧产生倾角冲击。

本版按参考方案把速度作为直接阻尼量叠加到位置输出：`position_angle=Kx*(-x)+Ki*Ip`、`damping_angle=-Kv*v_f`、`beam_angle=sat(position_angle+damping_angle,±AngleMax)`。位置增益不再被速度环Kp二次缩放，速度制动力也不再受目标速度限幅影响，两者可独立整定。实测当前摆臂机构的D36A逻辑方向与轨道倾角方向相反，闭环执行器使用`motor_angle=-beam_angle`，但手动校准、Cycle Test和Preset动作不经过该映射。默认`Kx=0.35 deg/cm`、`Ki=0`、`Kv=0.30 deg/(cm/s)`、`AngleMax=0.6°`。理想纯滚动小角度模型每1°约产生12.23 cm/s²加速度，因而线性闭环特征式为`s²+12.23*Kv*s+12.23*Kx=0`，默认自然频率约2.07 rad/s、阻尼比约0.89；最大倾角对应约7.34 cm/s²，目标倾角每秒最多变化15°。位置0.40/0.70 cm、速度0.30/0.70 cm/s分别构成进入/退出滞回稳定带，稳定带中清除位置驱动但保留速度阻尼。验证显式要求小球高速接近目标时速度阻尼必须压过位置输出并立即反向制动。

Velocity Test使用独立的`BALANCE_CONTROL_VELOCITY_ZERO`模式调用同一速度低通、阻尼增益、倾角限幅和短脉冲执行器，但把位置输出及积分强制为0，仅执行`beam_angle=-Kv*v_f`。因此该页能单独检查速度符号、滤波延迟和阻尼制动，不能用来保持小球的空间位置。

实测轨道左侧转动中心到右侧连杆销中心为251 mm；水平高度66.6 mm，+100脉冲后55.7 mm，−100脉冲后77.3 mm。用`theta=asin((h-h0)/251)`得到正向100脉冲对应轨道−2.4889°，反向100脉冲对应+2.4432°，因此分别采用40.18和40.93 pulse/轨道度。目标电机位置按角度符号选择方向标定值后计算，并以短块追踪；Balance的reference为Cal0，Balance Ref为Cal Camera。Preset不调用闭环角度映射，四步结束后按Cal−5位置锁轴。两点标定仅是零点附近的局部线性化，更换曲柄孔位或连杆后必须重新测量；若后续需要大角度行程，应升级为分段查表。

## 细分映射

D36A 拨码开关通过反相方式驱动 ATD5984 的 MS1-MS3：实体开关拨向 `ON` 时对应芯片输入低。配套教程说明 SW1-SW3 全部拨向风扇时为 16 细分，与 ATD5984 的 `MS3:MS1=111` 相符。

默认固定使用 3200 pulse/rev，对应 SW1/SW2/SW3 全 OFF。底层仍保留其他换算表，但菜单中的 Microstep 页面改为只读，运行期间不会切换软件细分或为此解除保持力矩。

## 中断优先级

| 中断 | 抢占优先级 | 用途 |
|---|---:|---|
| TIM2 | 0 | 脉冲计数、1 us DIR 建立状态转换 |
| USART1 | 1 | 摄像头逐字节接收；协议为100 Hz Location浮点文本 |
| SysTick | HAL 默认低优先级 | 1 ms时基、样本时间戳、数据超时和D36A唤醒 |

TIM2 ISR 不调用 HAL_Delay、浮点运算、OLED 或串口函数。1 ms 唤醒延时只在主循环上下文的 `D36A_Enable(1)` 中执行。

## 菜单与 OLED 刷新

菜单采用原云台工程的 `Option_Class`、`Menu_RunMenu()` 和 `menu_data.c` 分层结构。每个菜单用 `".."` 作为结束项，OLED 固定显示四行；Key3/Key4 改变选项后同步调整首行索引，因此包含Balance Ref在内的七个主菜单项都能完整滚动显示。每次重绘严格执行一次 `OLED_Clear()`、完整写入四行缓冲、一次 `OLED_Update()`，功能页面以 150 ms 周期刷新，避免在高速空循环中反复刷新总线。

菜单本身按参考工程使用阻塞式页面函数，但每个菜单和功能页循环都会调用 `Menu_Service()`。按键 1 ms 调度、`BallBalance_Task()`、`PresetRun_Task()` 和状态 LED 因此不会被菜单阻塞；没有恢复参考工程中每圈调用 `Car_Init()` 的行为。菜单深度计数只在顶层功能回调返回时调用`Menu_OnMainPageReturn()`，停止相关运行状态并同步移动到0 cm；子菜单内部返回上一级不会错误触发回零。

Key4的PA1与TIM2_CH1、USART1和OLED PB8/PB9均无复用冲突。按键扫描每5 ms读取一次，候选状态必须连续4次一致才更新稳定状态，并且只在完成一次已消抖的释放时产生一个事件；未消费事件不会被后续抖动覆盖。这样可阻止Key4接触抖动造成连续反向滚动和高频整屏I²C刷新。

## 安全边界

- 参数校验分别要求 `Max Angle * Positive/Negative PulsesPerDeg <= 5000`，避免单项合法的调参值组合成过大的相对行程命令。
- 参数校验同时要求单个`Move Chunk`在当前`Pulse Freq`下不超过10 ms；用户停止PID时先完成当前短块再发送Stop，因此停止延迟有界且D36A绝对脉冲坐标不会因中途Abort丢失。
- GPIO 初始化前先把 EN1 预置为低，完成 GPIO/TIM2 初始化后 `D36A_Init()` 立即拉高 EN1并等待1 ms，从此在健康状态持续锁轴。
- 正常 Stop 和所有功能页退出只停止脉冲，保持 EN1 为高；FAULT、运动超时和 Error_Handler 才拉低 EN1。
- HardFault、MemManage、BusFault、UsageFault 入口直接关闭 TIM2 输出并通过 GPIO BRR 拉低 EN1，不依赖 HAL 或主循环。
- 单次动作正反脉冲数来自同一个 `command_pulses`，上层在动作中途不能改变回程幅度。
- 每条 D36A 命令按 `脉冲数 × 单程数 / 频率 + 100 ms` 设置软件截止时间；超时后强制关闭 TIM2 和 EN、清除 BUSY 并产生 ERROR 事件，防止菜单永久卡在运动状态。
- 位置控制开始只发送一次Start，PID运行期间持续接收Location，不在每个电机块前后重复Stop/Start；Stop仅在用户停止、离开页面或FAULT时发送。
- 串口中断只进行ASCII定点解析和入队，不执行软浮点PID。帧头同时接受`Location`和实测的`LOCATION`，支持ASCII冒号和UTF-8全角冒号，数值单位统一转换为0.001 cm。
- 每个样本更新最新倾角目标；执行器只拥有当前短脉冲块，块完成后重新读取目标，避免100 Hz数据排队成多个过时动作。
- 超过100 ms无有效帧进入LOST，清空速度估计和两级积分，目标回到当前校准基准；摄像头仍保持推流，新帧到来后先ACQUIRE再ACTIVE。
- ACQUIRE、ACTIVE和LOST都保持D36A使能；无运动脉冲时绕组持续通电锁轴。真实串口启动或D36A运动错误才进入FAULT并解除使能。
- Preset在每个Step后的INTERVAL状态显式维持D36A使能；所有健康的非行动状态以及顶层菜单回零完成后都保持EN1为高。
- D36A 单通道芯片能力约 ±1.6 A，驱动大电流42电机或高速换向时必须检查失步和温升。
- 开环步进无法检测堵转、曲柄/销轴松动、四杆机构回差或电机丢步；实际设备仍需要机械限位。若要保证绝对回零，应增加原点开关。

## Preset Run 参数隔离

Preset Run的 `pulse_group[STEP1]` 保存P1基础脉冲，`pulse_group[STEP23]`由Step2/3共享；四个 `PresetRunStepConfig_t` 分别保存Frequency和Interval。另存有 `target_offset_pulses=Cal−5−Cal0` 及有效标志。Step4不保存独立值，`PresetRun_GetStepPulses(3)`按 `P4=P1−target_offset` 计算并执行10–1600边界检查。

固定阶段方向为`+1、−1、+1、−1`。因P2=P3，最终相对0 cm位置为`P1−P4=target_offset`，即精确落在保存的−5 cm电机位置。每次MOTION_DONE后才开始本步Interval；Step4 Interval结束后进入COMPLETE，恢复运行前的脉冲频率并显式保持D36A使能锁轴。Preset入口、运行、完成和退出调用链中均不存在`BallBalance_*`或`CameraLink_*`调用，不发送Start、Stop或Init；其他摄像头功能必须在自身退出流程中停止推流。缺少任一校准点或P4越界时拒绝启动；进入Preset前和退出Preset后移动到Cal0，COMPLETE期间保持Cal−5。

## 两个摄像头平衡入口

`Balance_Control()`将机构移动到Cal0后进入公共平衡页面；`Balance_Reference_Control()`将机构移动到Cal Camera后进入同一公共页面。两个入口均调用`BallBalance_Start()`，读写同一个`BalanceConfig_t`，位置增益、速度低通/阻尼、位置观测、限幅和执行器参数完全一致。第三方基准点无效时Balance Ref拒绝启动并提示先校准；退出任一顶层功能后统一回到Cal0。

## Pure Stream 串口隔离

CameraLink 明确区分 STOPPED、POSITION、PURE_INIT 三种模式。只有 `CameraLink_SendPureInit()` 包含并发送 `Init\r\n`；该接口仅由 Pure Stream 菜单页的 Key3 分支调用。进入页面不发送 Init，每个 Key3 释放事件发送一次。PURE_INIT 模式下 USART1 接收中断只重新挂接单字节接收并清空行长度，不组帧、不累计位置行统计、不写入事件队列。Key1 先把模式切为 STOPPED，再发送 `Stop\r\n` 并原子清空残留队列和行缓存。
