#ifndef __MENU_H
#define __MENU_H

#include "main.h"
#include "Key.h"
#include <stdint.h>

struct Option_Class
{
  char *String;
  void (*func)(void);
  float *Variable;
  uint8_t StrLen;
};

enum CursorStyle
{
  reverse,
  mouse,
  frame
};

struct MenuProperty
{
  float Cursor_Actual_X;
  float Cursor_Actual_Y;
  int8_t Layout_Margin;
};

extern struct MenuProperty Menu_Global;

void OLED_Showstr(uint8_t y, uint8_t x, char *text);
void OLED_ShowString_Cur(uint8_t y, uint8_t x, char *text);
int8_t Menu_RollEvent(void);
int8_t Menu_PreviousEvent(void);
int8_t Menu_EnterEvent(void);
int8_t Menu_BackEvent(void);
KeyCode_t Menu_GetKeyEvent(void);

void Menu_RunMenu(struct Option_Class *Option_List);
void Menu_RunMainMenu(void);
void Menu_Service(void);
void Menu_Init(void);
void Menu_Task(void);

void Balance_Control(void);
void Balance_Reference_Control(void);
void Preset_Menu(void);
void Preset_Run_Control(void);
void Tune_Menu(void);
void Tune_Position_Menu(void);
void Tune_Velocity_Menu(void);
void Tune_Estimator_Menu(void);
void Tune_Actuator_Menu(void);
void Motor_Menu(void);
void Motor_Cycle_Test(void);
void Motor_Calibrate(void);
void Motor_CalibrateMinus5(void);
void Motor_CalibrateCamera(void);
void Menu_OnMainPageReturn(void);
void Pure_Stream_Control(void);

#endif
