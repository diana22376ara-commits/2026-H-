#include "menu.h"
#include "OLED.h"
#include "ball_balance.h"
#include "camera_link.h"
#include "d36a.h"
#include "preset_run.h"

#define MENU_PAGE_REFRESH_MS             150UL
#define MENU_CALIBRATION_JOG_PULSES        1UL
#define MENU_CALIBRATION_DEFAULT_PULSES  (-160L)

#define TUNE_POSITION_GAIN_MIN             0.0f
#define TUNE_POSITION_GAIN_MAX            20.0f
#define TUNE_POSITION_KP_STEP              0.05f
#define TUNE_POSITION_KI_STEP              0.01f
#define TUNE_DAMPING_GAIN_MIN               0.0f
#define TUNE_DAMPING_GAIN_MAX              10.0f
#define TUNE_DAMPING_GAIN_STEP              0.05f
#define TUNE_VELOCITY_FILTER_MIN            0.05f
#define TUNE_VELOCITY_FILTER_MAX            1.00f
#define TUNE_VELOCITY_FILTER_STEP           0.05f
#define TUNE_OBSERVER_ALPHA_MIN            0.05f
#define TUNE_OBSERVER_ALPHA_MAX            0.95f
#define TUNE_OBSERVER_ALPHA_STEP           0.05f
#define TUNE_OBSERVER_BETA_MIN             0.005f
#define TUNE_OBSERVER_BETA_MAX             0.50f
#define TUNE_OBSERVER_BETA_STEP            0.01f
#define TUNE_MAX_ANGLE_MIN                 0.1f
#define TUNE_MAX_ANGLE_MAX                10.0f
#define TUNE_MAX_ANGLE_STEP                0.1f
#define TUNE_PULSES_PER_DEGREE_MIN        10.0f
#define TUNE_PULSES_PER_DEGREE_MAX       200.0f
#define TUNE_PULSES_PER_DEGREE_STEP        1.0f
#define TUNE_TIMEOUT_MIN                  30UL
#define TUNE_TIMEOUT_MAX                1000UL
#define TUNE_TIMEOUT_STEP                 10UL
#define TUNE_FREQ_MIN                    100UL
#define TUNE_FREQ_MAX                  20000UL
#define TUNE_FREQ_STEP                    50UL
#define TUNE_CHUNK_MIN                     1UL
#define TUNE_CHUNK_MAX                   200UL
#define TUNE_CHUNK_STEP                    1UL
#define TUNE_TEST_PULSES_MIN              10UL
#define TUNE_TEST_PULSES_MAX             800UL
#define TUNE_TEST_PULSES_STEP             10UL

#define PRESET_KICK_MIN                   10UL
#define PRESET_KICK_MAX                 1600UL
#define PRESET_KICK_STEP                  10UL
#define PRESET_FREQ_MIN                  100UL
#define PRESET_FREQ_MAX                10000UL
#define PRESET_FREQ_STEP                  50UL
#define PRESET_INTERVAL_MIN              200UL
#define PRESET_INTERVAL_MAX             3000UL
#define PRESET_INTERVAL_STEP              50UL

typedef enum
{
  TUNE_ITEM_POSITION_KP = 0,
  TUNE_ITEM_POSITION_KI,
  TUNE_ITEM_VELOCITY_DAMPING_GAIN,
  TUNE_ITEM_VELOCITY_FILTER_ALPHA,
  TUNE_ITEM_OBSERVER_ALPHA,
  TUNE_ITEM_OBSERVER_BETA,
  TUNE_ITEM_SAMPLE_TIMEOUT,
  TUNE_ITEM_MAX_ANGLE,
  TUNE_ITEM_POSITIVE_PULSES_PER_DEGREE,
  TUNE_ITEM_NEGATIVE_PULSES_PER_DEGREE,
  TUNE_ITEM_FREQUENCY,
  TUNE_ITEM_CHUNK_PULSES,
  TUNE_ITEM_TEST_PULSES
} TuneItem_t;

typedef enum
{
  PRESET_ITEM_PULSES = 0,
  PRESET_ITEM_FREQUENCY,
  PRESET_ITEM_INTERVAL
} PresetItem_t;

typedef enum
{
  CALIBRATION_MOVE_NONE = 0,
  CALIBRATION_MOVE_TO_PRESET
} CalibrationMove_t;

static uint8_t calibration_zero_valid;
static uint8_t calibration_minus5_valid;
static uint8_t calibration_camera_valid;
static int32_t calibration_zero_pulses = MENU_CALIBRATION_DEFAULT_PULSES;
static int32_t calibration_minus5_pulses = MENU_CALIBRATION_DEFAULT_PULSES;
static int32_t calibration_camera_pulses = MENU_CALIBRATION_DEFAULT_PULSES;
static CalibrationMove_t calibration_move;
static int32_t calibration_move_target;
static uint8_t calibration_move_failed;
static uint8_t *calibration_active_valid;
static uint8_t preset_menu_step;
static TuneItem_t tune_menu_item;

static void Preset_Step1_Menu(void);
static void Preset_Step2_Menu(void);
static void Preset_Step3_Menu(void);
static void Preset_Step4_Menu(void);
static void Preset_Pulses_Control(void);
static void Preset_Frequency_Control(void);
static void Preset_Interval_Control(void);
static uint8_t Calibration_MoveToAndWait(int32_t target, char *title);
static void Calibration_UpdatePresetOffset(void);
static uint8_t Preset_StartFromZero(void);
static void Tune_PositionKp_Control(void);
static void Tune_PositionKi_Control(void);
static void Tune_VelocityDamping_Control(void);
static void Tune_VelocityFilter_Control(void);
static void Tune_VelocityZeroTest(void);
static void Tune_ObserverAlpha_Control(void);
static void Tune_ObserverBeta_Control(void);
static void Tune_Timeout_Control(void);
static void Tune_MaxAngle_Control(void);
static void Tune_PositivePulsesPerDegree_Control(void);
static void Tune_NegativePulsesPerDegree_Control(void);
static void Tune_Frequency_Control(void);
static void Tune_Chunk_Control(void);
static void Tune_TestPulses_Control(void);

static uint8_t Preset_PulseGroupForStep(uint8_t step_index)
{
  return ((step_index == 0U) || (step_index == 3U)) ?
         PRESET_RUN_PULSE_GROUP_STEP1 : PRESET_RUN_PULSE_GROUP_STEP23;
}

static uint8_t Menu_RefreshDue(uint32_t *deadline)
{
  uint32_t now = HAL_GetTick();

  if ((*deadline == 0UL) || ((int32_t)(now - *deadline) >= 0))
  {
    *deadline = now + MENU_PAGE_REFRESH_MS;
    return 1U;
  }
  return 0U;
}

static char *Menu_WriteUnsigned(char *output, uint32_t value,
                                uint8_t minimum_digits)
{
  char digits[10];
  uint8_t count = 0U;

  do
  {
    digits[count++] = (char)('0' + (value % 10UL));
    value /= 10UL;
  } while ((value != 0UL) && (count < sizeof(digits)));

  while (minimum_digits > count)
  {
    *output++ = '0';
    --minimum_digits;
  }
  while (count > 0U)
  {
    *output++ = digits[--count];
  }
  return output;
}

static void Menu_FormatFixed(char *text, float value, uint8_t decimals)
{
  uint32_t scale = (decimals == 3U) ? 1000UL :
                   ((decimals == 2U) ? 100UL : 10UL);
  int32_t scaled = (value >= 0.0f) ?
                   (int32_t)(value * (float)scale + 0.5f) :
                   (int32_t)(value * (float)scale - 0.5f);
  uint32_t magnitude = (scaled >= 0) ? (uint32_t)scaled :
                       (uint32_t)(-scaled);
  uint32_t whole = magnitude / scale;
  uint32_t fraction = magnitude % scale;
  char *output = text;

  *output++ = (scaled < 0) ? '-' : '+';
  output = Menu_WriteUnsigned(output, whole, 1U);
  *output++ = '.';
  output = Menu_WriteUnsigned(output, fraction, decimals);
  *output = '\0';
}

static const char *Balance_StateName(BalanceState_t state)
{
  switch (state)
  {
    case BALANCE_STATE_STOPPED: return "STOP";
    case BALANCE_STATE_ACQUIRE: return "ACQUIRE";
    case BALANCE_STATE_ACTIVE:  return "ACTIVE";
    case BALANCE_STATE_LOST:    return "LOST";
    case BALANCE_STATE_FAULT:   return "FAULT";
    default:                    return "?";
  }
}

static const char *Preset_StateName(PresetRunState_t state)
{
  switch (state)
  {
    case PRESET_RUN_STATE_IDLE:      return "IDLE";
    case PRESET_RUN_STATE_MOVING:    return "MOVE";
    case PRESET_RUN_STATE_INTERVAL:  return "WAIT";
    case PRESET_RUN_STATE_COMPLETE:  return "DONE";
    case PRESET_RUN_STATE_FAULT:     return "FAULT";
    default:                         return "?";
  }
}

void Menu_RunMainMenu(void)
{
  static struct Option_Class Menu_StartOptionList[] =
  {
    {"<<<"},
    {"Balance", Balance_Control},
    {"Balance Ref", Balance_Reference_Control},
    {"Preset Run", Preset_Menu},
    {"Tune", Tune_Menu},
    {"Motor", Motor_Menu},
    {"Pure Stream", Pure_Stream_Control},
    {".."}
  };

  Menu_RunMenu(Menu_StartOptionList);
}

void Preset_Menu(void)
{
  static struct Option_Class Menu_StartOptionList[] =
  {
    {"<<<"},
    {"Run", Preset_Run_Control},
    {"Step1 +", Preset_Step1_Menu},
    {"Step2 -", Preset_Step2_Menu},
    {"Step3 +", Preset_Step3_Menu},
    {"Step4 -5cm", Preset_Step4_Menu},
    {".."}
  };

  Menu_RunMenu(Menu_StartOptionList);
}

void Menu_OnMainPageReturn(void)
{
  if (BallBalance_IsRunning())
  {
    BallBalance_Stop();
  }
  if (PresetRun_IsRunning())
  {
    PresetRun_Stop();
  }
  if (calibration_zero_valid && !D36A_IsBusy())
  {
    calibration_active_valid = &calibration_zero_valid;
    (void)Calibration_MoveToAndWait(calibration_zero_pulses,
                                    "Main return 0cm");
    calibration_active_valid = 0;
  }
  if (!D36A_IsBusy() &&
      (BallBalance_GetState() != BALANCE_STATE_FAULT) &&
      (PresetRun_GetState() != PRESET_RUN_STATE_FAULT))
  {
    D36A_Enable(1U);
  }
}

static void Preset_StepMenu(uint8_t step_index)
{
  static struct Option_Class Menu_StartOptionList[] =
  {
    {"<<<"},
    {"Pulses", Preset_Pulses_Control},
    {"Frequency", Preset_Frequency_Control},
    {"Interval", Preset_Interval_Control},
    {".."}
  };

  preset_menu_step = step_index;
  Menu_RunMenu(Menu_StartOptionList);
}

static void Preset_Step1_Menu(void) { Preset_StepMenu(0U); }
static void Preset_Step2_Menu(void) { Preset_StepMenu(1U); }
static void Preset_Step3_Menu(void) { Preset_StepMenu(2U); }
static void Preset_Step4_Menu(void) { Preset_StepMenu(3U); }

void Tune_Menu(void)
{
  static struct Option_Class Menu_StartOptionList[] =
  {
    {"<<<"},
    {"Position Ctrl", Tune_Position_Menu},
    {"Speed Damping", Tune_Velocity_Menu},
    {"Estimator", Tune_Estimator_Menu},
    {"Actuator", Tune_Actuator_Menu},
    {".."}
  };

  Menu_RunMenu(Menu_StartOptionList);
}

void Tune_Position_Menu(void)
{
  static struct Option_Class options[] =
  {
    {"<<<"},
    {"Position Kp", Tune_PositionKp_Control},
    {"Position Ki", Tune_PositionKi_Control},
    {".."}
  };
  Menu_RunMenu(options);
}

void Tune_Velocity_Menu(void)
{
  static struct Option_Class options[] =
  {
    {"<<<"},
    {"Damping Gain", Tune_VelocityDamping_Control},
    {"Velocity LPF", Tune_VelocityFilter_Control},
    {"Velocity Test", Tune_VelocityZeroTest},
    {".."}
  };
  Menu_RunMenu(options);
}

void Tune_Estimator_Menu(void)
{
  static struct Option_Class options[] =
  {
    {"<<<"},
    {"Observer Alpha", Tune_ObserverAlpha_Control},
    {"Observer Beta", Tune_ObserverBeta_Control},
    {"Data Timeout", Tune_Timeout_Control},
    {".."}
  };
  Menu_RunMenu(options);
}

void Tune_Actuator_Menu(void)
{
  static struct Option_Class options[] =
  {
    {"<<<"},
    {"Max Angle", Tune_MaxAngle_Control},
    {"P/deg Positive", Tune_PositivePulsesPerDegree_Control},
    {"P/deg Negative", Tune_NegativePulsesPerDegree_Control},
    {"Pulse Freq", Tune_Frequency_Control},
    {"Move Chunk", Tune_Chunk_Control},
    {"Test Pulses", Tune_TestPulses_Control},
    {".."}
  };
  Menu_RunMenu(options);
}

void Motor_Menu(void)
{
  static struct Option_Class Menu_StartOptionList[] =
  {
    {"<<<"},
    {"Cycle Test", Motor_Cycle_Test},
    {"Cal 0cm", Motor_Calibrate},
    {"Cal -5cm", Motor_CalibrateMinus5},
    {"Cal Camera", Motor_CalibrateCamera},
    {".."}
  };

  Menu_RunMenu(Menu_StartOptionList);
  D36A_Abort();
  (void)D36A_TakeEvent();
  D36A_Enable(1U);
}

static void Balance_ControlAtPoint(int32_t *reference_pulses,
                                   uint8_t *reference_valid,
                                   char *title,
                                   uint8_t velocity_zero_test)
{
  uint32_t refresh = 0UL;
  uint8_t reference_ready = 0U;

  BallBalance_Stop();
  PresetRun_Stop();
  if (*reference_valid)
  {
    calibration_active_valid = reference_valid;
    reference_ready = Calibration_MoveToAndWait(*reference_pulses,
                                                 "Move to balance");
    calibration_active_valid = 0;
  }

  while (1)
  {
    KeyCode_t key;
    const BalanceStats_t *stats;
    char location_text[16];
    char velocity_text[16];
    char damping_text[16];
    char angle_text[16];

    Menu_Service();
    key = Menu_GetKeyEvent();
    if (key == KEY_BACK)
    {
      if (BallBalance_IsRunning())
      {
        BallBalance_Stop();
      }
      else if (D36A_IsBusy())
      {
        continue;
      }
      if (velocity_zero_test && *reference_valid &&
          (BallBalance_GetState() != BALANCE_STATE_FAULT))
      {
        calibration_active_valid = reference_valid;
        (void)Calibration_MoveToAndWait(*reference_pulses, "Return 0cm");
        calibration_active_valid = 0;
      }
      return;
    }
    if (key == KEY_CONFIRM)
    {
      if (BallBalance_GetState() == BALANCE_STATE_FAULT)
      {
        BallBalance_ClearFault();
        calibration_active_valid = reference_valid;
        reference_ready = Calibration_MoveToAndWait(*reference_pulses,
                                                     "Recover reference");
        calibration_active_valid = 0;
      }
      else if (BallBalance_IsRunning())
      {
        BallBalance_Stop();
        if (BallBalance_GetState() == BALANCE_STATE_FAULT)
        {
          refresh = 0UL;
          continue;
        }
        calibration_active_valid = reference_valid;
        reference_ready = Calibration_MoveToAndWait(*reference_pulses,
                                                     "Return reference");
        calibration_active_valid = 0;
      }
      else if (D36A_IsBusy())
      {
        continue;
      }
      else if (reference_ready && *reference_valid)
      {
        if (velocity_zero_test)
        {
          (void)BallBalance_StartVelocityZeroTest();
        }
        else
        {
          (void)BallBalance_Start();
        }
      }
      refresh = 0UL;
    }

    if (Menu_RefreshDue(&refresh))
    {
      stats = BallBalance_GetStats();
      Menu_FormatFixed(location_text, stats->location_cm, 2U);
      Menu_FormatFixed(velocity_text, stats->velocity_cm_s, 1U);
      Menu_FormatFixed(damping_text,
                       stats->velocity_damping_output_deg, 1U);
      Menu_FormatFixed(angle_text, stats->angle_command_deg, 1U);
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "%s:%s", title,
                  Balance_StateName(BallBalance_GetState()));
      if (!reference_ready || !*reference_valid)
      {
        OLED_Printf(0, 16, OLED_8X16, "CALIBRATE FIRST");
      }
      else
      {
        OLED_Printf(0, 16, OLED_8X16, "X:%scm", location_text);
      }
      OLED_Printf(0, 32, OLED_8X16, "V:%s D:%s",
                  velocity_text, damping_text);
      OLED_Printf(0, 48, OLED_8X16, "A:%s K2:Run", angle_text);
      OLED_Update();
    }
  }
}

void Balance_Control(void)
{
  Balance_ControlAtPoint(&calibration_zero_pulses,
                         &calibration_zero_valid,
                         "Bal 0", 0U);
}

void Balance_Reference_Control(void)
{
  Balance_ControlAtPoint(&calibration_camera_pulses,
                         &calibration_camera_valid,
                         "Bal Ref", 0U);
}

static void Tune_VelocityZeroTest(void)
{
  Balance_ControlAtPoint(&calibration_zero_pulses,
                         &calibration_zero_valid,
                         "Vel Zero", 1U);
}

static uint8_t Preset_StartFromZero(void)
{
  PresetRun_Stop();
  if (!calibration_zero_valid || !calibration_minus5_valid)
  {
    return 0U;
  }

  calibration_active_valid = &calibration_zero_valid;
  if (!Calibration_MoveToAndWait(calibration_zero_pulses, "Move to 0cm"))
  {
    calibration_active_valid = 0;
    Calibration_UpdatePresetOffset();
    return 0U;
  }
  calibration_active_valid = 0;
  return PresetRun_Start();
}

void Preset_Run_Control(void)
{
  uint32_t refresh = 0UL;
  uint8_t start_failed = 0U;

  /* Selecting Run is the execute action; do not require a third confirm. */
  if (PresetRun_GetState() != PRESET_RUN_STATE_FAULT)
  {
    start_failed = Preset_StartFromZero() ? 0U : 1U;
  }

  while (1)
  {
    KeyCode_t key;

    Menu_Service();

    key = Menu_GetKeyEvent();
    if (key == KEY_BACK)
    {
      if (PresetRun_IsRunning()) { continue; }
      if (D36A_IsBusy())
      {
        continue;
      }
      PresetRun_Stop();
      if (calibration_zero_valid)
      {
        calibration_active_valid = &calibration_zero_valid;
        (void)Calibration_MoveToAndWait(calibration_zero_pulses,
                                        "Return to 0cm");
        calibration_active_valid = 0;
      }
      return;
    }
    if (key == KEY_CONFIRM)
    {
      if (PresetRun_IsRunning()) { continue; }
      if (PresetRun_GetState() == PRESET_RUN_STATE_FAULT)
      {
        PresetRun_ClearFault();
        PresetRun_Stop();
        if (calibration_zero_valid)
        {
          calibration_active_valid = &calibration_zero_valid;
          (void)Calibration_MoveToAndWait(calibration_zero_pulses,
                                          "Return to 0cm");
          calibration_active_valid = 0;
        }
      }
      else if (D36A_IsBusy())
      {
        continue;
      }
      else
      {
        start_failed = Preset_StartFromZero() ? 0U : 1U;
      }
      refresh = 0UL;
    }

    if (Menu_RefreshDue(&refresh))
    {
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "S%lu:%s",
                  (uint32_t)PresetRun_GetCurrentStep() + 1UL,
                  Preset_StateName(PresetRun_GetState()));
      if (start_failed)
      {
        if (!calibration_zero_valid || !calibration_minus5_valid)
        {
          OLED_Printf(0, 16, OLED_8X16, "CAL 0/-5 FIRST");
        }
        else if (PresetRun_GetStepPulses(3U) == 0UL)
        {
          OLED_Printf(0, 16, OLED_8X16, "STEP4 RANGE ERR");
        }
        else
        {
          OLED_Printf(0, 16, OLED_8X16, "START ERROR");
        }
      }
      else
      {
        uint32_t elapsed_ms = PresetRun_GetElapsedMs();
        OLED_Printf(0, 16, OLED_8X16, "Time:%lu.%01lus",
                    elapsed_ms / 1000UL,
                    (elapsed_ms % 1000UL) / 100UL);
      }
      OLED_Printf(0, 32, OLED_8X16, "+-+ ->-5 LOCK");
      OLED_Printf(0, 48, OLED_8X16, "K2:Run K1:Back");
      OLED_Update();
    }
  }
}

static void Preset_Adjust(uint8_t step_index, PresetItem_t item,
                          int8_t direction)
{
  const PresetRunConfig_t *cfg = PresetRun_GetConfig();
  uint32_t value;
  uint8_t group_index;

  if (PresetRun_IsRunning() || (step_index >= PRESET_RUN_STEP_COUNT))
  {
    return;
  }

  if (item == PRESET_ITEM_PULSES)
  {
    group_index = Preset_PulseGroupForStep(step_index);
    value = cfg->pulse_group[group_index];
    if (direction > 0)
    {
      value = (value < PRESET_KICK_MAX) ? value + PRESET_KICK_STEP : PRESET_KICK_MAX;
      if (value > PRESET_KICK_MAX) { value = PRESET_KICK_MAX; }
    }
    else
    {
      value = (value > PRESET_KICK_MIN) ? value - PRESET_KICK_STEP : PRESET_KICK_MIN;
      if (value < PRESET_KICK_MIN) { value = PRESET_KICK_MIN; }
    }
    (void)PresetRun_SetPulseGroup(group_index, value);
  }
  else if (item == PRESET_ITEM_FREQUENCY)
  {
    value = cfg->step[step_index].pulse_hz;
    if (direction > 0)
    {
      value = (value < PRESET_FREQ_MAX) ? value + PRESET_FREQ_STEP : PRESET_FREQ_MAX;
      if (value > PRESET_FREQ_MAX) { value = PRESET_FREQ_MAX; }
    }
    else
    {
      value = (value > PRESET_FREQ_MIN) ? value - PRESET_FREQ_STEP : PRESET_FREQ_MIN;
      if (value < PRESET_FREQ_MIN) { value = PRESET_FREQ_MIN; }
    }
    (void)PresetRun_SetStepFrequency(step_index, value);
  }
  else
  {
    value = cfg->step[step_index].interval_ms;
    if (direction > 0)
    {
      value = (value < PRESET_INTERVAL_MAX) ? value + PRESET_INTERVAL_STEP : PRESET_INTERVAL_MAX;
      if (value > PRESET_INTERVAL_MAX) { value = PRESET_INTERVAL_MAX; }
    }
    else
    {
      value = (value > PRESET_INTERVAL_MIN) ? value - PRESET_INTERVAL_STEP : PRESET_INTERVAL_MIN;
      if (value < PRESET_INTERVAL_MIN) { value = PRESET_INTERVAL_MIN; }
    }
    (void)PresetRun_SetStepInterval(step_index, value);
  }
}

static void Preset_AdjustPage(PresetItem_t item, char *label)
{
  uint32_t refresh = 0UL;

  while (1)
  {
    KeyCode_t key;
    const PresetRunConfig_t *cfg;
    uint32_t value;

    Menu_Service();
    key = Menu_GetKeyEvent();
    if (key == KEY_BACK) { return; }
    if (key == KEY_NEXT)
    {
      Preset_Adjust(preset_menu_step, item, 1);
      refresh = 0UL;
    }
    if (key == KEY_PREVIOUS)
    {
      Preset_Adjust(preset_menu_step, item, -1);
      refresh = 0UL;
    }

    if (Menu_RefreshDue(&refresh))
    {
      cfg = PresetRun_GetConfig();
      value = (item == PRESET_ITEM_PULSES) ?
              PresetRun_GetStepPulses(preset_menu_step) :
              ((item == PRESET_ITEM_FREQUENCY) ?
               cfg->step[preset_menu_step].pulse_hz :
               cfg->step[preset_menu_step].interval_ms);
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "Step%lu %s",
                  (uint32_t)preset_menu_step + 1UL, label);
      if ((item == PRESET_ITEM_PULSES) &&
          (preset_menu_step == 3U) && (value == 0UL))
      {
        OLED_Printf(0, 16, OLED_8X16, "Value:INVALID");
      }
      else
      {
        OLED_Printf(0, 16, OLED_8X16, "Value:%lu", value);
      }
      OLED_Printf(0, 32, OLED_8X16, "K3:+ K4:-");
      if ((item == PRESET_ITEM_PULSES) && (preset_menu_step == 3U))
      {
        OLED_Printf(0, 48, OLED_8X16, "P4=P1-D K1");
      }
      else if ((item == PRESET_ITEM_PULSES) &&
               (Preset_PulseGroupForStep(preset_menu_step) ==
                PRESET_RUN_PULSE_GROUP_STEP23))
      {
        OLED_Printf(0, 48, OLED_8X16, "P2=P3 K1:Back");
      }
      else if (item == PRESET_ITEM_PULSES)
      {
        OLED_Printf(0, 48, OLED_8X16, "P1 Base K1:Back");
      }
      else
      {
        OLED_Printf(0, 48, OLED_8X16, "Independent K1");
      }
      OLED_Update();
    }
  }
}

static void Preset_Pulses_Control(void)
{
  Preset_AdjustPage(PRESET_ITEM_PULSES, "Pulses");
}

static void Preset_Frequency_Control(void)
{
  Preset_AdjustPage(PRESET_ITEM_FREQUENCY, "Freq");
}

static void Preset_Interval_Control(void)
{
  Preset_AdjustPage(PRESET_ITEM_INTERVAL, "Interval");
}

static float Tune_GetValue(const BalanceConfig_t *cfg, TuneItem_t item)
{
  switch (item)
  {
    case TUNE_ITEM_POSITION_KP: return cfg->position_kp;
    case TUNE_ITEM_POSITION_KI: return cfg->position_ki;
    case TUNE_ITEM_VELOCITY_DAMPING_GAIN:
      return cfg->velocity_damping_gain;
    case TUNE_ITEM_VELOCITY_FILTER_ALPHA:
      return cfg->velocity_filter_alpha;
    case TUNE_ITEM_OBSERVER_ALPHA: return cfg->observer_alpha;
    case TUNE_ITEM_OBSERVER_BETA: return cfg->observer_beta;
    case TUNE_ITEM_SAMPLE_TIMEOUT: return (float)cfg->sample_timeout_ms;
    case TUNE_ITEM_MAX_ANGLE: return cfg->max_angle_deg;
    case TUNE_ITEM_POSITIVE_PULSES_PER_DEGREE:
      return cfg->positive_pulses_per_beam_degree;
    case TUNE_ITEM_NEGATIVE_PULSES_PER_DEGREE:
      return cfg->negative_pulses_per_beam_degree;
    case TUNE_ITEM_FREQUENCY: return (float)cfg->pulse_hz;
    case TUNE_ITEM_CHUNK_PULSES: return (float)cfg->actuator_chunk_pulses;
    case TUNE_ITEM_TEST_PULSES: return (float)cfg->test_pulses;
    default: return 0.0f;
  }
}

static void Tune_GetLimits(TuneItem_t item, float *minimum,
                           float *maximum, float *step)
{
  *minimum = 0.0f;
  *maximum = 1.0f;
  *step = 0.01f;
  switch (item)
  {
    case TUNE_ITEM_POSITION_KP:
      *minimum = TUNE_POSITION_GAIN_MIN; *maximum = TUNE_POSITION_GAIN_MAX;
      *step = TUNE_POSITION_KP_STEP; break;
    case TUNE_ITEM_POSITION_KI:
      *minimum = TUNE_POSITION_GAIN_MIN; *maximum = TUNE_POSITION_GAIN_MAX;
      *step = TUNE_POSITION_KI_STEP; break;
    case TUNE_ITEM_VELOCITY_DAMPING_GAIN:
      *minimum = TUNE_DAMPING_GAIN_MIN; *maximum = TUNE_DAMPING_GAIN_MAX;
      *step = TUNE_DAMPING_GAIN_STEP; break;
    case TUNE_ITEM_VELOCITY_FILTER_ALPHA:
      *minimum = TUNE_VELOCITY_FILTER_MIN;
      *maximum = TUNE_VELOCITY_FILTER_MAX;
      *step = TUNE_VELOCITY_FILTER_STEP; break;
    case TUNE_ITEM_OBSERVER_ALPHA:
      *minimum = TUNE_OBSERVER_ALPHA_MIN; *maximum = TUNE_OBSERVER_ALPHA_MAX;
      *step = TUNE_OBSERVER_ALPHA_STEP; break;
    case TUNE_ITEM_OBSERVER_BETA:
      *minimum = TUNE_OBSERVER_BETA_MIN; *maximum = TUNE_OBSERVER_BETA_MAX;
      *step = TUNE_OBSERVER_BETA_STEP; break;
    case TUNE_ITEM_SAMPLE_TIMEOUT:
      *minimum = (float)TUNE_TIMEOUT_MIN; *maximum = (float)TUNE_TIMEOUT_MAX;
      *step = (float)TUNE_TIMEOUT_STEP; break;
    case TUNE_ITEM_MAX_ANGLE:
      *minimum = TUNE_MAX_ANGLE_MIN; *maximum = TUNE_MAX_ANGLE_MAX;
      *step = TUNE_MAX_ANGLE_STEP; break;
    case TUNE_ITEM_POSITIVE_PULSES_PER_DEGREE:
    case TUNE_ITEM_NEGATIVE_PULSES_PER_DEGREE:
      *minimum = TUNE_PULSES_PER_DEGREE_MIN;
      *maximum = TUNE_PULSES_PER_DEGREE_MAX;
      *step = TUNE_PULSES_PER_DEGREE_STEP; break;
    case TUNE_ITEM_FREQUENCY:
      *minimum = (float)TUNE_FREQ_MIN; *maximum = (float)TUNE_FREQ_MAX;
      *step = (float)TUNE_FREQ_STEP; break;
    case TUNE_ITEM_CHUNK_PULSES:
      *minimum = (float)TUNE_CHUNK_MIN; *maximum = (float)TUNE_CHUNK_MAX;
      *step = (float)TUNE_CHUNK_STEP; break;
    case TUNE_ITEM_TEST_PULSES:
      *minimum = (float)TUNE_TEST_PULSES_MIN;
      *maximum = (float)TUNE_TEST_PULSES_MAX;
      *step = (float)TUNE_TEST_PULSES_STEP; break;
    default: break;
  }
}

static void Tune_SetValue(BalanceConfig_t *cfg, TuneItem_t item, float value)
{
  switch (item)
  {
    case TUNE_ITEM_POSITION_KP: cfg->position_kp = value; break;
    case TUNE_ITEM_POSITION_KI: cfg->position_ki = value; break;
    case TUNE_ITEM_VELOCITY_DAMPING_GAIN:
      cfg->velocity_damping_gain = value; break;
    case TUNE_ITEM_VELOCITY_FILTER_ALPHA:
      cfg->velocity_filter_alpha = value; break;
    case TUNE_ITEM_OBSERVER_ALPHA: cfg->observer_alpha = value; break;
    case TUNE_ITEM_OBSERVER_BETA: cfg->observer_beta = value; break;
    case TUNE_ITEM_SAMPLE_TIMEOUT: cfg->sample_timeout_ms = (uint32_t)value; break;
    case TUNE_ITEM_MAX_ANGLE: cfg->max_angle_deg = value; break;
    case TUNE_ITEM_POSITIVE_PULSES_PER_DEGREE:
      cfg->positive_pulses_per_beam_degree = value; break;
    case TUNE_ITEM_NEGATIVE_PULSES_PER_DEGREE:
      cfg->negative_pulses_per_beam_degree = value; break;
    case TUNE_ITEM_FREQUENCY: cfg->pulse_hz = (uint32_t)value; break;
    case TUNE_ITEM_CHUNK_PULSES: cfg->actuator_chunk_pulses = (uint32_t)value; break;
    case TUNE_ITEM_TEST_PULSES: cfg->test_pulses = (uint32_t)value; break;
    default: break;
  }
}

static void Tune_Adjust(TuneItem_t item, int8_t direction)
{
  BalanceConfig_t next = *BallBalance_GetConfig();
  float minimum;
  float maximum;
  float step;
  float value;

  if (BallBalance_IsRunning()) { return; }
  Tune_GetLimits(item, &minimum, &maximum, &step);
  value = Tune_GetValue(&next, item) + ((direction > 0) ? step : -step);
  if (value < minimum) { value = minimum; }
  if (value > maximum) { value = maximum; }
  Tune_SetValue(&next, item, value);
  (void)BallBalance_SetConfig(&next);
}

static uint8_t Tune_ItemIsInteger(TuneItem_t item)
{
  return ((item == TUNE_ITEM_SAMPLE_TIMEOUT) ||
          (item == TUNE_ITEM_FREQUENCY) ||
          (item == TUNE_ITEM_CHUNK_PULSES) ||
          (item == TUNE_ITEM_TEST_PULSES)) ? 1U : 0U;
}

static void Tune_AdjustPage(TuneItem_t item, char *title)
{
  uint32_t refresh = 0UL;

  tune_menu_item = item;
  while (1)
  {
    KeyCode_t key;
    float value;
    char value_text[16];

    Menu_Service();
    key = Menu_GetKeyEvent();
    if (key == KEY_BACK) { return; }
    if (key == KEY_NEXT) { Tune_Adjust(tune_menu_item, 1); refresh = 0UL; }
    if (key == KEY_PREVIOUS) { Tune_Adjust(tune_menu_item, -1); refresh = 0UL; }

    if (Menu_RefreshDue(&refresh))
    {
      value = Tune_GetValue(BallBalance_GetConfig(), tune_menu_item);
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "%s", title);
      if (Tune_ItemIsInteger(tune_menu_item))
      {
        OLED_Printf(0, 16, OLED_8X16, "Value:%lu", (uint32_t)value);
      }
      else
      {
        Menu_FormatFixed(value_text, value, 3U);
        OLED_Printf(0, 16, OLED_8X16, "Value:%s", value_text);
      }
      OLED_Printf(0, 32, OLED_8X16, "K3:+ K4:-");
      OLED_Printf(0, 48, OLED_8X16, "K1:Back");
      OLED_Update();
    }
  }
}

static void Tune_PositionKp_Control(void) { Tune_AdjustPage(TUNE_ITEM_POSITION_KP, "Position Kp"); }
static void Tune_PositionKi_Control(void) { Tune_AdjustPage(TUNE_ITEM_POSITION_KI, "Position Ki"); }
static void Tune_VelocityDamping_Control(void) { Tune_AdjustPage(TUNE_ITEM_VELOCITY_DAMPING_GAIN, "Damping deg/v"); }
static void Tune_VelocityFilter_Control(void) { Tune_AdjustPage(TUNE_ITEM_VELOCITY_FILTER_ALPHA, "Velocity LPF"); }
static void Tune_ObserverAlpha_Control(void) { Tune_AdjustPage(TUNE_ITEM_OBSERVER_ALPHA, "Observer Alpha"); }
static void Tune_ObserverBeta_Control(void) { Tune_AdjustPage(TUNE_ITEM_OBSERVER_BETA, "Observer Beta"); }
static void Tune_Timeout_Control(void) { Tune_AdjustPage(TUNE_ITEM_SAMPLE_TIMEOUT, "Data Timeout ms"); }
static void Tune_MaxAngle_Control(void) { Tune_AdjustPage(TUNE_ITEM_MAX_ANGLE, "Max Angle deg"); }
static void Tune_PositivePulsesPerDegree_Control(void) { Tune_AdjustPage(TUNE_ITEM_POSITIVE_PULSES_PER_DEGREE, "+ Pulses/deg"); }
static void Tune_NegativePulsesPerDegree_Control(void) { Tune_AdjustPage(TUNE_ITEM_NEGATIVE_PULSES_PER_DEGREE, "- Pulses/deg"); }
static void Tune_Frequency_Control(void) { Tune_AdjustPage(TUNE_ITEM_FREQUENCY, "PID Pulse Hz"); }
static void Tune_Chunk_Control(void) { Tune_AdjustPage(TUNE_ITEM_CHUNK_PULSES, "Move Chunk"); }
static void Tune_TestPulses_Control(void) { Tune_AdjustPage(TUNE_ITEM_TEST_PULSES, "Test Pulses"); }

static void Motor_StartCycle(int8_t first_direction)
{
  if (D36A_IsBusy() || BallBalance_IsRunning() || PresetRun_IsRunning())
  {
    return;
  }

  (void)D36A_TakeEvent();
  D36A_Enable(1U);
  (void)D36A_StartImpulse(first_direction,
                          BallBalance_GetConfig()->test_pulses);
}

void Motor_Cycle_Test(void)
{
  uint32_t refresh = 0UL;

  PresetRun_Stop();
  BallBalance_Stop();
  (void)D36A_TakeEvent();
  D36A_Enable(1U);

  while (1)
  {
    KeyCode_t key;
    const BalanceConfig_t *cfg;

    Menu_Service();
    key = Menu_GetKeyEvent();
    if (key == KEY_BACK)
    {
      if (D36A_IsBusy()) { continue; }
      D36A_Abort();
      (void)D36A_TakeEvent();
      D36A_Enable(1U);
      return;
    }
    if (key == KEY_NEXT) { Motor_StartCycle(1); refresh = 0UL; }
    if (key == KEY_PREVIOUS) { Motor_StartCycle(-1); refresh = 0UL; }

    if (Menu_RefreshDue(&refresh))
    {
      cfg = BallBalance_GetConfig();
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "Cycle Test");
      OLED_Printf(0, 16, OLED_8X16, "K3:+- K4:-+");
      OLED_Printf(0, 32, OLED_8X16, "P:%lu F:%lu",
                  cfg->test_pulses, cfg->pulse_hz);
      if (D36A_IsBusy())
      {
        OLED_Printf(0, 48, OLED_8X16, "BUSY S:%lu",
                    (uint32_t)D36A_GetState());
      }
      else
      {
        OLED_Printf(0, 48, OLED_8X16, "READY K1:Back");
      }
      OLED_Update();
    }
  }
}

static void Calibration_StartJog(int8_t direction)
{
  if ((calibration_move != CALIBRATION_MOVE_NONE) || D36A_IsBusy())
  {
    return;
  }

  (void)D36A_TakeEvent();
  D36A_Enable(1U);
  if (D36A_MovePulses(direction, MENU_CALIBRATION_JOG_PULSES))
  {
    if (calibration_active_valid != 0)
    {
      *calibration_active_valid = 0U;
    }
    Calibration_UpdatePresetOffset();
  }
}

static uint8_t Calibration_StartMoveTo(int32_t target,
                                       CalibrationMove_t move)
{
  int32_t current_position;
  int32_t delta;
  uint32_t pulses;
  int8_t direction;

  if ((calibration_move != CALIBRATION_MOVE_NONE) || D36A_IsBusy())
  {
    return 0U;
  }

  current_position = D36A_GetCommandedPositionPulses();
  delta = target - current_position;
  calibration_move_target = target;
  calibration_move = move;
  calibration_move_failed = 0U;
  if (delta == 0)
  {
    return 1U;
  }

  direction = (delta > 0) ? 1 : -1;
  pulses = (delta > 0) ? (uint32_t)delta : (uint32_t)(-delta);
  (void)D36A_TakeEvent();
  D36A_Enable(1U);
  if (!D36A_MovePulses(direction, pulses))
  {
    calibration_move = CALIBRATION_MOVE_NONE;
    calibration_move_failed = 1U;
    return 0U;
  }
  return 1U;
}

static void Calibration_ServiceMove(void)
{
  D36A_Event_t event;

  if ((calibration_move == CALIBRATION_MOVE_NONE) || D36A_IsBusy())
  {
    return;
  }

  event = D36A_TakeEvent();
  if ((D36A_GetCommandedPositionPulses() != calibration_move_target) ||
      ((event != D36A_EVENT_NONE) && (event != D36A_EVENT_MOTION_DONE)))
  {
    calibration_move = CALIBRATION_MOVE_NONE;
    calibration_move_failed = 1U;
    if (calibration_active_valid != 0)
    {
      *calibration_active_valid = 0U;
    }
    Calibration_UpdatePresetOffset();
    return;
  }

  calibration_move = CALIBRATION_MOVE_NONE;
}

static void Calibration_UpdatePresetOffset(void)
{
  int32_t offset = calibration_minus5_pulses - calibration_zero_pulses;
  uint8_t valid = (calibration_zero_valid && calibration_minus5_valid) ?
                  1U : 0U;

  (void)PresetRun_SetTargetOffsetPulses(offset, valid);
}

static uint8_t Calibration_MoveToAndWait(int32_t target, char *title)
{
  uint32_t refresh = 0UL;

  calibration_move = CALIBRATION_MOVE_NONE;
  calibration_move_failed = 0U;
  if (!Calibration_StartMoveTo(target, CALIBRATION_MOVE_TO_PRESET))
  {
    return 0U;
  }

  while ((calibration_move != CALIBRATION_MOVE_NONE) || D36A_IsBusy())
  {
    Menu_Service();
    Calibration_ServiceMove();
    if (Menu_RefreshDue(&refresh))
    {
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "%s", title);
      OLED_Printf(0, 16, OLED_8X16, "Now:%ldp",
                  D36A_GetCommandedPositionPulses());
      OLED_Printf(0, 32, OLED_8X16, "To:%ldp", target);
      OLED_Printf(0, 48, OLED_8X16, "Please wait");
      OLED_Update();
    }
  }

  return (!calibration_move_failed &&
          (D36A_GetCommandedPositionPulses() == target)) ? 1U : 0U;
}

static void Motor_CalibratePoint(int32_t *saved_position,
                                 uint8_t *saved_valid,
                                 char *title,
                                 uint8_t return_to_zero)
{
  uint32_t refresh = 0UL;

  PresetRun_Stop();
  BallBalance_Stop();
  (void)D36A_TakeEvent();
  D36A_Enable(1U);
  calibration_active_valid = saved_valid;
  calibration_move = CALIBRATION_MOVE_NONE;
  calibration_move_failed = 0U;
  (void)Calibration_StartMoveTo(*saved_position,
                                CALIBRATION_MOVE_TO_PRESET);

  while (1)
  {
    KeyCode_t key;
    int32_t position;

    Menu_Service();
    Calibration_ServiceMove();

    key = Menu_GetKeyEvent();
    if (key == KEY_NEXT) { Calibration_StartJog(1); refresh = 0UL; }
    if (key == KEY_PREVIOUS) { Calibration_StartJog(-1); refresh = 0UL; }
    if (((key == KEY_CONFIRM) || (key == KEY_BACK)) && !D36A_IsBusy() &&
        (calibration_move == CALIBRATION_MOVE_NONE))
    {
      *saved_position = D36A_GetCommandedPositionPulses();
      *saved_valid = 1U;
      Calibration_UpdatePresetOffset();
      if (return_to_zero)
      {
        calibration_active_valid = &calibration_zero_valid;
        if (!Calibration_MoveToAndWait(calibration_zero_pulses,
                                       "Return to 0cm"))
        {
          refresh = 0UL;
          continue;
        }
      }
      calibration_active_valid = 0;
      D36A_Enable(1U);
      return;
    }
    if (Menu_RefreshDue(&refresh))
    {
      position = D36A_GetCommandedPositionPulses();
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "%s", title);
      OLED_Printf(0, 16, OLED_8X16, "K3:+1 K4:-1");
      OLED_Printf(0, 32, OLED_8X16, "Value:%ldp", position);
      if (calibration_move == CALIBRATION_MOVE_TO_PRESET)
      {
        OLED_Printf(0, 48, OLED_8X16, "To:%ldp",
                    *saved_position);
      }
      else if (D36A_IsBusy())
      {
        OLED_Printf(0, 48, OLED_8X16, "Busy:%lu Wait",
                    (uint32_t)D36A_GetState());
      }
      else
      {
        OLED_Printf(0, 48, OLED_8X16,
                    calibration_move_failed ? "MOVE ERROR" :
                    "K1/K2:Save");
      }
      OLED_Update();
    }
  }
}

void Motor_Calibrate(void)
{
  Motor_CalibratePoint(&calibration_zero_pulses,
                       &calibration_zero_valid,
                       "Calibrate 0cm", 0U);
}

void Motor_CalibrateMinus5(void)
{
  if (!calibration_minus5_valid)
  {
    calibration_minus5_pulses = calibration_zero_pulses;
  }
  Motor_CalibratePoint(&calibration_minus5_pulses,
                       &calibration_minus5_valid,
                       "Calibrate -5cm", 1U);
}

void Motor_CalibrateCamera(void)
{
  if (!calibration_camera_valid)
  {
    calibration_camera_pulses = calibration_zero_pulses;
  }
  Motor_CalibratePoint(&calibration_camera_pulses,
                       &calibration_camera_valid,
                       "Cal Camera Ref", 1U);
}

void Pure_Stream_Control(void)
{
  uint32_t refresh = 0UL;
  uint32_t send_count = 0UL;
  uint8_t tx_status = 0U;

  PresetRun_Stop();
  BallBalance_Stop();
  CameraLink_DiscardPending();

  while (1)
  {
    KeyCode_t key;

    Menu_Service();
    key = Menu_GetKeyEvent();
    if (key == KEY_BACK)
    {
      (void)CameraLink_StopStream();
      CameraLink_DiscardPending();
      return;
    }
    if (key == KEY_NEXT)
    {
      CameraLink_DiscardPending();
      if (CameraLink_SendPureInit() == HAL_OK)
      {
        ++send_count;
        tx_status = 1U;
      }
      else
      {
        tx_status = 2U;
      }
      refresh = 0UL;
    }

    if (Menu_RefreshDue(&refresh))
    {
      OLED_Clear();
      OLED_Printf(0, 0, OLED_8X16, "Pure Stream");
      OLED_Printf(0, 16, OLED_8X16, "K3:Send Init");
      OLED_Printf(0, 32, OLED_8X16, "Sent:%lu %s", send_count,
                  (tx_status == 0U) ? "READY" :
                  ((tx_status == 1U) ? "OK" : "ERR"));
      OLED_Printf(0, 48, OLED_8X16, "K1:Stop/Back");
      OLED_Update();
    }
  }
}
