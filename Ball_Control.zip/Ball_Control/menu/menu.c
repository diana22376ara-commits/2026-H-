#include "menu.h"
#include "OLED.h"
#include "ball_balance.h"
#include "d36a.h"
#include "preset_run.h"

#define MENU_VISIBLE_ROWS 4U
#define MENU_OPTION_LIMIT 32U

struct MenuProperty Menu_Global = {0.0f, 0.0f, 0};

static KeyCode_t Key_Cache = KEY_NONE;
static uint32_t last_key_tick;
static uint8_t menu_depth;

static int8_t Menu_MatchEvent(KeyCode_t expected)
{
  if (Key_Cache == KEY_NONE)
  {
    Key_Cache = Key_GetNum();
  }
  if (Key_Cache == expected)
  {
    Key_Cache = KEY_NONE;
    return 1;
  }
  return 0;
}

void OLED_Showstr(uint8_t y, uint8_t x, char *text)
{
  OLED_Printf((int16_t)((x - 1U) * 8U),
              (int16_t)((y - 1U) * 16U), OLED_8X16, "%s", text);
}

void OLED_ShowString_Cur(uint8_t y, uint8_t x, char *text)
{
  OLED_Printf((int16_t)((x - 1U) * 8U),
              (int16_t)((y - 1U) * 16U), OLED_8X16, "%s<-", text);
}

int8_t Menu_RollEvent(void)
{
  return Menu_MatchEvent(KEY_NEXT);
}

int8_t Menu_PreviousEvent(void)
{
  return Menu_MatchEvent(KEY_PREVIOUS);
}

int8_t Menu_EnterEvent(void)
{
  return Menu_MatchEvent(KEY_CONFIRM);
}

int8_t Menu_BackEvent(void)
{
  return Menu_MatchEvent(KEY_BACK);
}

KeyCode_t Menu_GetKeyEvent(void)
{
  KeyCode_t key;

  if (Key_Cache != KEY_NONE)
  {
    key = Key_Cache;
    Key_Cache = KEY_NONE;
    return key;
  }
  return Key_GetNum();
}

void Menu_Service(void)
{
  uint32_t now = HAL_GetTick();

  if (now != last_key_tick)
  {
    last_key_tick = now;
    Key_Tick();
  }

  D36A_Task();
  BallBalance_Task();
  PresetRun_Task();

  if (BallBalance_GetState() == BALANCE_STATE_FAULT)
  {
    HAL_GPIO_WritePin(STATUS_LED_GPIO_Port, STATUS_LED_Pin,
                      ((now / 200UL) & 1UL) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  }
  else
  {
    HAL_GPIO_WritePin(STATUS_LED_GPIO_Port, STATUS_LED_Pin,
                      BallBalance_IsRunning() ? GPIO_PIN_RESET : GPIO_PIN_SET);
  }
}

static uint8_t Menu_GetLastOption(struct Option_Class *Option_List)
{
  uint8_t index;

  for (index = 0U; index < MENU_OPTION_LIMIT; ++index)
  {
    if ((Option_List[index].String != 0) &&
        (Option_List[index].String[0] == '.'))
    {
      return (index > 0U) ? (uint8_t)(index - 1U) : 0U;
    }
  }
  return 0U;
}

static void Menu_DrawOptions(struct Option_Class *Option_List,
                             uint8_t selected, uint8_t first,
                             uint8_t last)
{
  uint8_t row;

  OLED_Clear();
  for (row = 0U; row < MENU_VISIBLE_ROWS; ++row)
  {
    uint8_t option = (uint8_t)(first + row);
    if (option > last)
    {
      break;
    }
    if (option == selected)
    {
      OLED_ShowString_Cur((uint8_t)(row + 1U), 1U,
                          Option_List[option].String);
    }
    else
    {
      OLED_Showstr((uint8_t)(row + 1U), 1U, Option_List[option].String);
    }
  }
  OLED_Update();
}

void Menu_RunMenu(struct Option_Class *Option_List)
{
  uint8_t last = Menu_GetLastOption(Option_List);
  uint8_t selected = 1U;
  uint8_t first = 1U;
  uint8_t this_depth;

  if (last == 0U)
  {
    return;
  }

  ++menu_depth;
  this_depth = menu_depth;

  Menu_DrawOptions(Option_List, selected, first, last);
  while (1)
  {
    Menu_Service();

    if (Menu_EnterEvent())
    {
      if (Option_List[selected].func != 0)
      {
        Option_List[selected].func();
        if (this_depth == 1U)
        {
          Menu_OnMainPageReturn();
        }
        Menu_DrawOptions(Option_List, selected, first, last);
      }
      else
      {
        --menu_depth;
        return;
      }
    }
    else if (Menu_BackEvent())
    {
      --menu_depth;
      return;
    }
    else if (Menu_RollEvent())
    {
      selected = (selected >= last) ? 1U : (uint8_t)(selected + 1U);
      if (selected == 1U)
      {
        first = 1U;
      }
      else if (selected >= (uint8_t)(first + MENU_VISIBLE_ROWS))
      {
        first = (uint8_t)(selected - (MENU_VISIBLE_ROWS - 1U));
      }
      Menu_DrawOptions(Option_List, selected, first, last);
    }
    else if (Menu_PreviousEvent())
    {
      selected = (selected <= 1U) ? last : (uint8_t)(selected - 1U);
      if (selected == last)
      {
        first = (last > MENU_VISIBLE_ROWS) ?
                (uint8_t)(last - (MENU_VISIBLE_ROWS - 1U)) : 1U;
      }
      else if (selected < first)
      {
        first = selected;
      }
      Menu_DrawOptions(Option_List, selected, first, last);
    }
  }
}

void Menu_Init(void)
{
  Key_Cache = KEY_NONE;
  menu_depth = 0U;
  last_key_tick = HAL_GetTick();
  OLED_Clear();
  OLED_Update();
}

void Menu_Task(void)
{
  Menu_RunMainMenu();
}
