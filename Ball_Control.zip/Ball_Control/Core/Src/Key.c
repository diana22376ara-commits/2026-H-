#include "Key.h"
#include "main.h"

#define KEY_SCAN_PERIOD_MS       5U
#define KEY_DEBOUNCE_SAMPLES     4U

static KeyCode_t key_number;

KeyCode_t Key_GetNum(void)
{
  KeyCode_t key = key_number;
  key_number = KEY_NONE;
  return key;
}

KeyCode_t Key_GetState(void)
{
  /* BACK has the highest priority if more than one key is held. */
  if (HAL_GPIO_ReadPin(KEY_BACK_GPIO_Port, KEY_BACK_Pin) == GPIO_PIN_RESET)
  {
    return KEY_BACK;
  }
  if (HAL_GPIO_ReadPin(KEY_CONFIRM_GPIO_Port, KEY_CONFIRM_Pin) == GPIO_PIN_RESET)
  {
    return KEY_CONFIRM;
  }
  if (HAL_GPIO_ReadPin(KEY_NEXT_GPIO_Port, KEY_NEXT_Pin) == GPIO_PIN_RESET)
  {
    return KEY_NEXT;
  }
  if (HAL_GPIO_ReadPin(KEY_PREVIOUS_GPIO_Port, KEY_PREVIOUS_Pin) == GPIO_PIN_RESET)
  {
    return KEY_PREVIOUS;
  }
  return KEY_NONE;
}

void Key_Tick(void)
{
  static uint8_t scan_count;
  static uint8_t candidate_count;
  static KeyCode_t candidate_state;
  static KeyCode_t stable_state;
  KeyCode_t raw_state;
  KeyCode_t previous_stable;

  ++scan_count;
  if (scan_count < KEY_SCAN_PERIOD_MS)
  {
    return;
  }
  scan_count = 0U;
  raw_state = Key_GetState();

  if (raw_state != candidate_state)
  {
    candidate_state = raw_state;
    candidate_count = 1U;
    return;
  }
  if (candidate_count < KEY_DEBOUNCE_SAMPLES)
  {
    ++candidate_count;
  }
  if ((candidate_count < KEY_DEBOUNCE_SAMPLES) ||
      (candidate_state == stable_state))
  {
    return;
  }

  previous_stable = stable_state;
  stable_state = candidate_state;
  if ((stable_state == KEY_NONE) && (previous_stable != KEY_NONE) &&
      (key_number == KEY_NONE))
  {
    /* One event per fully debounced press/release cycle. */
    key_number = previous_stable;
  }
}
