#include "tim.h"

TIM_HandleTypeDef htim2;

void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef clock = {0};
  TIM_MasterConfigTypeDef master = {0};
  TIM_OC_InitTypeDef pwm = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 72U - 1U;       /* 72 MHz TIM2 clock -> 1 MHz. */
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 666U - 1U;         /* Safe ~1500 Hz default. */
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }

  clock.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &clock) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }

  master.MasterOutputTrigger = TIM_TRGO_RESET;
  master.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &master) != HAL_OK)
  {
    Error_Handler();
  }

  pwm.OCMode = TIM_OCMODE_PWM1;
  pwm.Pulse = 125U;
  pwm.OCPolarity = TIM_OCPOLARITY_HIGH;
  pwm.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &pwm, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_DISABLE_OCxPRELOAD(&htim2, TIM_CHANNEL_1);
  HAL_TIM_MspPostInit(&htim2);
}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *timer)
{
  if (timer->Instance == TIM2)
  {
    __HAL_RCC_TIM2_CLK_ENABLE();
    HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);
  }
}

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *timer)
{
  GPIO_InitTypeDef gpio = {0};

  if (timer->Instance == TIM2)
  {
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /* TIM2 partial remap 1 routes CH1 to PA15, matching the Pitch example. */
    __HAL_AFIO_REMAP_TIM2_PARTIAL_1();
    /* The HAL remap macro also touches MAPR.SWJ_CFG; restore the required
       JTAG-off/SWD-on selection after writing the TIM2 remap bits. */
    __HAL_AFIO_REMAP_SWJ_NOJTAG();
    gpio.Pin = D36A_ST_Pin;
    gpio.Mode = GPIO_MODE_AF_PP;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(D36A_ST_GPIO_Port, &gpio);
    /* PA13/PA14 remain available for SWD. */
  }
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef *timer)
{
  if (timer->Instance == TIM2)
  {
    __HAL_RCC_TIM2_CLK_DISABLE();
    HAL_GPIO_DeInit(D36A_ST_GPIO_Port, D36A_ST_Pin);
    HAL_NVIC_DisableIRQ(TIM2_IRQn);
  }
}
