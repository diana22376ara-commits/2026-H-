#include "main.h"

void HAL_MspInit(void)
{
  __HAL_RCC_AFIO_CLK_ENABLE();
  __HAL_RCC_PWR_CLK_ENABLE();

  HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

  /* Pitch-compatible STEP uses PA15, so release JTAG pins while retaining
     PA13/PA14 for the two-wire SWD debug/programming interface. */
  __HAL_AFIO_REMAP_SWJ_NOJTAG();
}
