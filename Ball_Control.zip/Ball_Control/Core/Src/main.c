#include "main.h"
#include "gpio.h"
#include "tim.h"
#include "usart.h"
#include "OLED.h"
#include "Key.h"
#include "d36a.h"
#include "camera_link.h"
#include "ball_balance.h"
#include "preset_run.h"
#include "menu.h"

static void SystemClock_Config(void);

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();

  OLED_Init();
  D36A_Init();
  CameraLink_Init();
  BallBalance_Init();
  PresetRun_Init();
  Menu_Init();

  while (1)
  {
    Menu_Task();
  }
}

static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef osc = {0};
  RCC_ClkInitTypeDef clock = {0};

  /* STM32F103C8T6 clock tree:
     HSE 8 MHz -> PLL x9 -> SYSCLK/HCLK 72 MHz.
     APB1 /2 = 36 MHz (TIM2 clock doubles to 72 MHz).
     APB2 /1 = 72 MHz (USART1 clock 72 MHz). */
  osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  osc.HSEState = RCC_HSE_ON;
  osc.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  osc.HSIState = RCC_HSI_ON;
  osc.PLL.PLLState = RCC_PLL_ON;
  osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  osc.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&osc) != HAL_OK)
  {
    Error_Handler();
  }

  clock.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                    RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  clock.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  clock.AHBCLKDivider = RCC_SYSCLK_DIV1;
  clock.APB1CLKDivider = RCC_HCLK_DIV2;
  clock.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&clock, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
  D36A_Abort();
  D36A_Enable(0U);
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(STATUS_LED_GPIO_Port, STATUS_LED_Pin);
    {
      volatile uint32_t delay;
      for (delay = 0U; delay < 300000UL; ++delay) { }
    }
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
  Error_Handler();
}
#endif
