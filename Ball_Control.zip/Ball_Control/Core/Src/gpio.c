#include "gpio.h"

void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef gpio = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /* Put the D36A in sleep before changing pin modes. EN is active high. */
  HAL_GPIO_WritePin(D36A_ST_GPIO_Port, D36A_ST_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(D36A_DIR_GPIO_Port, D36A_DIR_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(D36A_EN_GPIO_Port, D36A_EN_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(STATUS_LED_GPIO_Port, STATUS_LED_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, OLED_SCL_Pin | OLED_SDA_Pin, GPIO_PIN_SET);

  gpio.Pin = D36A_DIR_Pin | D36A_EN_Pin;
  gpio.Mode = GPIO_MODE_OUTPUT_PP;
  gpio.Pull = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &gpio);

  gpio.Pin = STATUS_LED_Pin;
  gpio.Mode = GPIO_MODE_OUTPUT_PP;
  gpio.Pull = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &gpio);

  gpio.Pin = OLED_SCL_Pin | OLED_SDA_Pin;
  gpio.Mode = GPIO_MODE_OUTPUT_OD;
  gpio.Pull = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &gpio);

  gpio.Pin = KEY_BACK_Pin | KEY_CONFIRM_Pin | KEY_NEXT_Pin;
  gpio.Mode = GPIO_MODE_INPUT;
  gpio.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &gpio);

  gpio.Pin = KEY_PREVIOUS_Pin;
  HAL_GPIO_Init(KEY_PREVIOUS_GPIO_Port, &gpio);
}
