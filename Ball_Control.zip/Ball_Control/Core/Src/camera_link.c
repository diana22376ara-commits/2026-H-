#include "camera_link.h"
#include "usart.h"
#include <string.h>

#define CAMERA_LINE_SIZE      64U
/* One slot is reserved to distinguish full from empty: 31 frames usable. */
#define CAMERA_QUEUE_SIZE     32U
#define CAMERA_LOCATION_MAX_MILLI_CM 1000000L

static uint8_t rx_byte;
static char line_buffer[CAMERA_LINE_SIZE];
static volatile uint8_t line_length;
static volatile CameraLocationSample_t event_queue[CAMERA_QUEUE_SIZE];
static volatile uint8_t queue_head;
static volatile uint8_t queue_tail;
static volatile CameraStreamMode_t stream_mode;
static volatile uint32_t invalid_lines;
static volatile uint32_t dropped_events;

static void CameraLink_QueueFromISR(int32_t location_milli_cm,
                                    int32_t velocity_milli_cm_s,
                                    uint8_t has_velocity)
{
  uint8_t next = (uint8_t)((queue_head + 1U) % CAMERA_QUEUE_SIZE);

  if (stream_mode != CAMERA_STREAM_POSITION)
  {
    return;
  }
  if (next == queue_tail)
  {
    ++dropped_events;
    return;
  }
  event_queue[queue_head].location_milli_cm = location_milli_cm;
  event_queue[queue_head].velocity_milli_cm_s = velocity_milli_cm_s;
  event_queue[queue_head].timestamp_ms = HAL_GetTick();
  event_queue[queue_head].has_velocity = has_velocity;
  queue_head = next;
}

static uint8_t CameraLink_ParseFixedMilliCm(const char *text,
                                            uint8_t length,
                                            int32_t *value)
{
  uint8_t index = 0U;
  uint8_t digit_count = 0U;
  uint8_t fraction_count = 0U;
  int8_t sign = 1;
  int32_t whole = 0L;
  int32_t fraction = 0L;

  while ((index < length) && (text[index] == ' ')) { ++index; }
  if ((index < length) && ((text[index] == '+') || (text[index] == '-')))
  {
    if (text[index] == '-') { sign = -1; }
    ++index;
  }
  while ((index < length) && (text[index] >= '0') && (text[index] <= '9'))
  {
    if (whole > 100000L) { return 0U; }
    whole = whole * 10L + (int32_t)(text[index] - '0');
    ++digit_count;
    ++index;
  }
  if ((digit_count == 0U) || (whole > 1000L)) { return 0U; }
  if ((index < length) && (text[index] == '.'))
  {
    ++index;
    while ((index < length) && (text[index] >= '0') && (text[index] <= '9'))
    {
      if (fraction_count < 3U)
      {
        fraction = fraction * 10L + (int32_t)(text[index] - '0');
        ++fraction_count;
      }
      ++index;
    }
  }
  while (fraction_count < 3U)
  {
    fraction *= 10L;
    ++fraction_count;
  }
  while ((index < length) && (text[index] == ' ')) { ++index; }
  if (index != length) { return 0U; }

  whole = whole * 1000L + fraction;
  if (whole > CAMERA_LOCATION_MAX_MILLI_CM) { return 0U; }
  *value = (sign > 0) ? whole : -whole;
  return 1U;
}

static void CameraLink_ParseLineFromISR(void)
{
  uint8_t length = line_length;
  uint8_t value_index = 0U;
  uint8_t value_end;
  uint8_t velocity_length;
  int32_t location_milli_cm;
  int32_t velocity_milli_cm_s;
  char *separator;

  if ((length > 0U) && (line_buffer[length - 1U] == '\r'))
  {
    --length;
  }
  line_buffer[length] = '\0';
  value_end = length;
  if ((value_end > 0U) && (line_buffer[value_end - 1U] == '%'))
  {
    /* Tolerate a literal trailing percent sign as well as printf's %f form. */
    --value_end;
  }

  if ((length >= 18U) && (line_buffer[0] == 'V') &&
      (line_buffer[1] == ':'))
  {
    separator = strstr(&line_buffer[2], "cm/s,LOCATION:");
    if (separator == 0)
    {
      separator = strstr(&line_buffer[2], "cm/s,Location:");
    }
    if (separator != 0)
    {
      velocity_length = (uint8_t)(separator - &line_buffer[2]);
      value_index = (uint8_t)(separator - line_buffer) + 14U;
    }
    if ((separator != 0) && (velocity_length > 0U) &&
        (value_index < value_end) &&
        CameraLink_ParseFixedMilliCm(&line_buffer[2], velocity_length,
                                     &velocity_milli_cm_s) &&
        CameraLink_ParseFixedMilliCm(&line_buffer[value_index],
                                     (uint8_t)(value_end - value_index),
                                     &location_milli_cm))
    {
      CameraLink_QueueFromISR(location_milli_cm, velocity_milli_cm_s, 1U);
    }
    else
    {
      ++invalid_lines;
    }
  }
  else if ((length >= 9U) &&
      ((memcmp(line_buffer, "Location", 8U) == 0) ||
       (memcmp(line_buffer, "LOCATION", 8U) == 0)))
  {
    if (line_buffer[8] == ':')
    {
      value_index = 9U;
    }
    else if ((length >= 11U) &&
             ((uint8_t)line_buffer[8] == 0xEFU) &&
             ((uint8_t)line_buffer[9] == 0xBCU) &&
             ((uint8_t)line_buffer[10] == 0x9AU))
    {
      /* Also accept the UTF-8 full-width colon used in some camera scripts. */
      value_index = 11U;
    }
    if ((value_index != 0U) &&
         CameraLink_ParseFixedMilliCm(&line_buffer[value_index],
                                      (uint8_t)(value_end - value_index),
                                      &location_milli_cm))
    {
      CameraLink_QueueFromISR(location_milli_cm, 0L, 0U);
    }
    else
    {
      ++invalid_lines;
    }
  }
  else if (length != 0U)
  {
    ++invalid_lines;
  }
  line_length = 0U;
}

void CameraLink_Init(void)
{
  line_length = 0U;
  queue_head = 0U;
  queue_tail = 0U;
  stream_mode = CAMERA_STREAM_STOPPED;
  invalid_lines = 0UL;
  dropped_events = 0UL;
  if (HAL_UART_Receive_IT(&huart1, &rx_byte, 1U) != HAL_OK)
  {
    Error_Handler();
  }
}

HAL_StatusTypeDef CameraLink_StartStream(void)
{
  static const uint8_t command[] = "Start\r\n";
  HAL_StatusTypeDef status;

  stream_mode = CAMERA_STREAM_STOPPED;
  CameraLink_DiscardPending();
  status = HAL_UART_Transmit(&huart1, (uint8_t *)command,
                             sizeof(command) - 1U, 20U);
  if (status == HAL_OK)
  {
    stream_mode = CAMERA_STREAM_POSITION;
  }
  return status;
}

HAL_StatusTypeDef CameraLink_SendPureInit(void)
{
  static const uint8_t command[] = "Init\r\n";
  HAL_StatusTypeDef status;

  stream_mode = CAMERA_STREAM_STOPPED;
  CameraLink_DiscardPending();
  status = HAL_UART_Transmit(&huart1, (uint8_t *)command,
                             sizeof(command) - 1U, 20U);
  if (status == HAL_OK)
  {
    stream_mode = CAMERA_STREAM_PURE_INIT;
  }
  return status;
}

HAL_StatusTypeDef CameraLink_StopStream(void)
{
  static const uint8_t command[] = "Stop\r\n";
  HAL_StatusTypeDef status;

  stream_mode = CAMERA_STREAM_STOPPED;
  status = HAL_UART_Transmit(&huart1, (uint8_t *)command,
                             sizeof(command) - 1U, 20U);
  CameraLink_DiscardPending();
  return status;
}

uint8_t CameraLink_IsStreaming(void)
{
  return (stream_mode != CAMERA_STREAM_STOPPED) ? 1U : 0U;
}

uint8_t CameraLink_PopLocation(CameraLocationSample_t *sample)
{
  uint32_t primask;

  if ((sample == 0) || (queue_head == queue_tail))
  {
    return 0U;
  }
  primask = __get_PRIMASK();
  __disable_irq();
  if (queue_head == queue_tail)
  {
    if (primask == 0U) { __enable_irq(); }
    return 0U;
  }
  sample->location_milli_cm = event_queue[queue_tail].location_milli_cm;
  sample->velocity_milli_cm_s =
    event_queue[queue_tail].velocity_milli_cm_s;
  sample->timestamp_ms = event_queue[queue_tail].timestamp_ms;
  sample->has_velocity = event_queue[queue_tail].has_velocity;
  queue_tail = (uint8_t)((queue_tail + 1U) % CAMERA_QUEUE_SIZE);
  if (primask == 0U) { __enable_irq(); }
  return 1U;
}

void CameraLink_DiscardPending(void)
{
  uint32_t primask = __get_PRIMASK();

  __disable_irq();
  queue_tail = queue_head;
  line_length = 0U;
  if (primask == 0U) { __enable_irq(); }
}

uint32_t CameraLink_GetInvalidLineCount(void) { return invalid_lines; }
uint32_t CameraLink_GetDroppedEventCount(void) { return dropped_events; }

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart)
{
  if (uart->Instance != USART1)
  {
    return;
  }
  if (stream_mode != CAMERA_STREAM_POSITION)
  {
    line_length = 0U;
  }
  else if (rx_byte == '\n')
  {
    CameraLink_ParseLineFromISR();
  }
  else if (line_length < (CAMERA_LINE_SIZE - 1U))
  {
    line_buffer[line_length++] = (char)rx_byte;
  }
  else
  {
    line_length = 0U;
    ++invalid_lines;
  }
  (void)HAL_UART_Receive_IT(&huart1, &rx_byte, 1U);
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *uart)
{
  if (uart->Instance == USART1)
  {
    if (stream_mode == CAMERA_STREAM_POSITION) { ++invalid_lines; }
    line_length = 0U;
    __HAL_UART_CLEAR_OREFLAG(&huart1);
    (void)HAL_UART_Receive_IT(&huart1, &rx_byte, 1U);
  }
}
