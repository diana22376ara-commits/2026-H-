#include "ball_balance.h"
#include "d36a.h"

#define BALANCE_POSITION_GAIN_MAX             20.0f
#define BALANCE_VELOCITY_DAMPING_GAIN_MAX     10.0f
#define BALANCE_VELOCITY_FILTER_ALPHA_MIN      0.05f
#define BALANCE_VELOCITY_FILTER_ALPHA_MAX      1.00f
#define BALANCE_OBSERVER_ALPHA_MIN             0.05f
#define BALANCE_OBSERVER_ALPHA_MAX             0.95f
#define BALANCE_OBSERVER_BETA_MIN              0.005f
#define BALANCE_OBSERVER_BETA_MAX              0.50f
#define BALANCE_MAX_ANGLE_MIN                  0.1f
#define BALANCE_MAX_ANGLE_MAX                 10.0f
#define BALANCE_PULSES_PER_DEGREE_MIN          1.0f
#define BALANCE_PULSES_PER_DEGREE_MAX       5000.0f
#define BALANCE_MAX_RELATIVE_PULSES          5000.0f
#define BALANCE_SAMPLE_TIMEOUT_MIN_MS         30UL
#define BALANCE_SAMPLE_TIMEOUT_MAX_MS       1000UL
#define BALANCE_ACTUATOR_CHUNK_MIN             1UL
#define BALANCE_ACTUATOR_CHUNK_MAX           200UL
#define BALANCE_ACTUATOR_CHUNK_MAX_US       10000UL
#define BALANCE_TEST_PULSES_MIN               10UL
#define BALANCE_TEST_PULSES_MAX              800UL
#define BALANCE_SAMPLE_DT_MIN_MS               2UL
#define BALANCE_SAMPLE_DT_MAX_MS             100UL
#define BALANCE_MEASURED_SPEED_LIMIT_CM_S    300.0f
#define BALANCE_HOLD_ENTER_POSITION_CM         0.40f
#define BALANCE_HOLD_EXIT_POSITION_CM          0.70f
#define BALANCE_HOLD_ENTER_VELOCITY_CM_S       0.30f
#define BALANCE_HOLD_EXIT_VELOCITY_CM_S        0.70f
#define BALANCE_MAX_ANGLE_SLEW_DEG_S          15.00f

static BalanceConfig_t config;
static BalanceStats_t stats;
static volatile BalanceState_t state;
static float last_measurement_cm;
static float estimated_location_cm;
static float filtered_velocity_cm_s;
static float position_integral;
static uint32_t last_sample_timestamp_ms;
static uint32_t last_received_tick_ms;
static int32_t reference_motor_pulses;
static int32_t target_motor_pulses;
static uint8_t estimator_valid;
static uint8_t actuator_move_active;
static uint8_t hold_active;
static float previous_angle_command_deg;
static BalanceControlMode_t control_mode;

static float BallBalance_Abs(float value)
{
  return (value >= 0.0f) ? value : -value;
}

static float BallBalance_Clamp(float value, float minimum, float maximum)
{
  if (value < minimum) { return minimum; }
  if (value > maximum) { return maximum; }
  return value;
}

static int32_t BallBalance_RoundToInt(float value)
{
  return (value >= 0.0f) ? (int32_t)(value + 0.5f) :
                           (int32_t)(value - 0.5f);
}

static uint8_t BallBalance_IsActiveState(BalanceState_t candidate)
{
  return ((candidate == BALANCE_STATE_ACQUIRE) ||
          (candidate == BALANCE_STATE_ACTIVE) ||
          (candidate == BALANCE_STATE_LOST)) ? 1U : 0U;
}

static void BallBalance_ResetController(void)
{
  filtered_velocity_cm_s = 0.0f;
  position_integral = 0.0f;
  stats.velocity_cm_s = 0.0f;
  stats.position_output_deg = 0.0f;
  stats.velocity_damping_output_deg = 0.0f;
  stats.angle_command_deg = 0.0f;
  stats.hold_active = 0U;
  hold_active = 0U;
  previous_angle_command_deg = 0.0f;
  target_motor_pulses = reference_motor_pulses;
  stats.target_motor_pulses = target_motor_pulses;
}

static void BallBalance_ResetEstimator(float location_cm,
                                       float velocity_cm_s,
                                       uint32_t timestamp_ms)
{
  BallBalance_ResetController();
  last_measurement_cm = location_cm;
  estimated_location_cm = location_cm;
  filtered_velocity_cm_s = velocity_cm_s;
  last_sample_timestamp_ms = timestamp_ms;
  last_received_tick_ms = timestamp_ms;
  stats.location_cm = location_cm;
  stats.velocity_cm_s = velocity_cm_s;
  estimator_valid = 1U;
  state = BALANCE_STATE_ACQUIRE;
}

static void BallBalance_EnterFault(void)
{
  D36A_Abort();
  actuator_move_active = 0U;
  D36A_Enable(0U);
  (void)CameraLink_StopStream();
  CameraLink_DiscardPending();
  state = BALANCE_STATE_FAULT;
}

static void BallBalance_UpdateControl(float location_cm, float dt_s)
{
  float position_error;
  float position_output;
  float velocity_damping_output;
  float angle_unsaturated;
  float angle_limited;
  float angle_command;
  float motor_angle_command;
  float maximum_angle_change;
  float position_integral_limit;
  int32_t angle_offset_pulses;
  if (control_mode == BALANCE_CONTROL_VELOCITY_ZERO)
  {
    hold_active = 0U;
    position_integral = 0.0f;
  }
  else if (hold_active)
  {
    if ((BallBalance_Abs(location_cm) > BALANCE_HOLD_EXIT_POSITION_CM) ||
        (BallBalance_Abs(filtered_velocity_cm_s) >
         BALANCE_HOLD_EXIT_VELOCITY_CM_S))
    {
      hold_active = 0U;
    }
  }
  else if ((BallBalance_Abs(location_cm) <=
            BALANCE_HOLD_ENTER_POSITION_CM) &&
           (BallBalance_Abs(filtered_velocity_cm_s) <=
            BALANCE_HOLD_ENTER_VELOCITY_CM_S))
  {
    hold_active = 1U;
  }

  /* LOCATION and V are both downward-positive.  Negating LOCATION makes the
     position term point toward the target.  The separately filtered velocity
     is added as direct damping, matching the measured ball trend instead of
     passing both terms through another cascaded PID gain. */
  position_error = -location_cm;
  if (control_mode == BALANCE_CONTROL_VELOCITY_ZERO)
  {
    position_output = 0.0f;
  }
  else if (hold_active)
  {
    /* Keep velocity damping active in the quiet band, but remove position
       drive and integral bias so the beam locks without centre chatter. */
    position_integral = 0.0f;
    position_output = 0.0f;
  }
  else
  {
    position_output =
      config.position_kp * position_error +
      config.position_ki * position_integral;
  }
  velocity_damping_output =
    -config.velocity_damping_gain * filtered_velocity_cm_s;
  angle_unsaturated = position_output + velocity_damping_output;
  angle_limited = BallBalance_Clamp(angle_unsaturated,
                                    -config.max_angle_deg,
                                    config.max_angle_deg);

  maximum_angle_change = BALANCE_MAX_ANGLE_SLEW_DEG_S * dt_s;
  angle_command = BallBalance_Clamp(
    angle_limited,
    previous_angle_command_deg - maximum_angle_change,
    previous_angle_command_deg + maximum_angle_change);
  previous_angle_command_deg = angle_command;

  if ((control_mode == BALANCE_CONTROL_POSITION_DAMPING) && !hold_active &&
      (config.position_ki > 0.0f) &&
      ((angle_command == angle_unsaturated) ||
       ((angle_command < angle_unsaturated) &&
        (position_error < 0.0f)) ||
       ((angle_command > angle_unsaturated) &&
        (position_error > 0.0f))))
  {
    position_integral_limit = config.max_angle_deg / config.position_ki;
    position_integral = BallBalance_Clamp(
      position_integral + position_error * dt_s,
      -position_integral_limit, position_integral_limit);
  }

  /* Bench testing established that the linkage/beam direction is opposite to
     the D36A logical motor direction.  Invert only this closed-loop mapping;
     the PID signs continue to describe the real beam and ball coordinates. */
  motor_angle_command =
    BALL_BALANCE_CLOSED_LOOP_MOTOR_POLARITY * angle_command;
  angle_offset_pulses = BallBalance_RoundToInt(
    motor_angle_command * ((motor_angle_command >= 0.0f) ?
      config.positive_pulses_per_beam_degree :
      config.negative_pulses_per_beam_degree));
  target_motor_pulses = reference_motor_pulses + angle_offset_pulses;
  stats.location_cm = location_cm;
  stats.velocity_cm_s = filtered_velocity_cm_s;
  stats.position_output_deg = position_output;
  stats.velocity_damping_output_deg = velocity_damping_output;
  stats.angle_command_deg = angle_command;
  stats.hold_active = hold_active;
  stats.target_motor_pulses = target_motor_pulses;
  ++stats.control_updates;
}

static void BallBalance_ProcessSample(const CameraLocationSample_t *sample)
{
  uint32_t dt_ms;
  float location_cm;
  float dt_s;
  float raw_velocity_cm_s;
  float predicted_location_cm;
  float position_residual_cm;
  float camera_velocity_cm_s = 0.0f;

  location_cm = (float)sample->location_milli_cm * 0.001f;
  ++stats.received_locations;
  stats.measured_location_cm = location_cm;
  stats.camera_velocity_active = sample->has_velocity;
  last_received_tick_ms = sample->timestamp_ms;

  if (sample->has_velocity)
  {
    camera_velocity_cm_s =
      (float)sample->velocity_milli_cm_s * 0.001f;
    if (BallBalance_Abs(camera_velocity_cm_s) >
        BALANCE_MEASURED_SPEED_LIMIT_CM_S)
    {
      ++stats.estimator_resyncs;
      BallBalance_ResetEstimator(location_cm, 0.0f,
                                 sample->timestamp_ms);
      return;
    }
  }

  if (!estimator_valid || (state == BALANCE_STATE_LOST))
  {
    BallBalance_ResetEstimator(location_cm, camera_velocity_cm_s,
                               sample->timestamp_ms);
    return;
  }

  dt_ms = sample->timestamp_ms - last_sample_timestamp_ms;
  if ((dt_ms < BALANCE_SAMPLE_DT_MIN_MS) ||
      (dt_ms > BALANCE_SAMPLE_DT_MAX_MS))
  {
    ++stats.estimator_resyncs;
    BallBalance_ResetEstimator(location_cm, camera_velocity_cm_s,
                               sample->timestamp_ms);
    return;
  }

  dt_s = (float)dt_ms * 0.001f;
  raw_velocity_cm_s = (location_cm - last_measurement_cm) / dt_s;
  if (BallBalance_Abs(raw_velocity_cm_s) >
      BALANCE_MEASURED_SPEED_LIMIT_CM_S)
  {
    /* A target jump or impossible derivative must not become an angle kick. */
    ++stats.estimator_resyncs;
    BallBalance_ResetEstimator(location_cm, camera_velocity_cm_s,
                               sample->timestamp_ms);
    return;
  }

  if (sample->has_velocity)
  {
    /* The camera V is already in cm/s, but its frame-to-frame jitter must not
       become stepper direction chatter.  This first-order filter is applied
       before both prediction and the direct velocity damping term. */
    filtered_velocity_cm_s += config.velocity_filter_alpha *
      (camera_velocity_cm_s - filtered_velocity_cm_s);
  }

  predicted_location_cm = estimated_location_cm +
                          filtered_velocity_cm_s * dt_s;
  position_residual_cm = location_cm - predicted_location_cm;
  estimated_location_cm = predicted_location_cm +
                          config.observer_alpha * position_residual_cm;
  if (!sample->has_velocity)
  {
    /* Legacy position-only frames retain the alpha-beta fallback estimator. */
    filtered_velocity_cm_s += (config.observer_beta / dt_s) *
                              position_residual_cm;
  }
  BallBalance_UpdateControl(estimated_location_cm, dt_s);
  last_measurement_cm = location_cm;
  last_sample_timestamp_ms = sample->timestamp_ms;
  state = BALANCE_STATE_ACTIVE;
}

static void BallBalance_ServiceActuator(void)
{
  D36A_Event_t event;
  int32_t current_position;
  int32_t delta;
  uint32_t pulses;
  int8_t direction;

  if (actuator_move_active && !D36A_IsBusy())
  {
    event = D36A_TakeEvent();
    actuator_move_active = 0U;
    if (event != D36A_EVENT_MOTION_DONE)
    {
      BallBalance_EnterFault();
      return;
    }
  }

  if (!BallBalance_IsActiveState(state) || actuator_move_active ||
      D36A_IsBusy())
  {
    return;
  }

  current_position = D36A_GetCommandedPositionPulses();
  delta = target_motor_pulses - current_position;
  if (delta == 0)
  {
    if (!D36A_IsEnabled()) { D36A_Enable(1U); }
    return;
  }

  direction = (delta > 0) ? 1 : -1;
  pulses = (delta > 0) ? (uint32_t)delta : (uint32_t)(-delta);
  if (pulses > config.actuator_chunk_pulses)
  {
    pulses = config.actuator_chunk_pulses;
  }
  (void)D36A_TakeEvent();
  D36A_Enable(1U);
  if (!D36A_MovePulses(direction, pulses))
  {
    BallBalance_EnterFault();
    return;
  }
  actuator_move_active = 1U;
}

void BallBalance_Init(void)
{
  config.position_kp = BALL_BALANCE_DEFAULT_POSITION_KP;
  config.position_ki = BALL_BALANCE_DEFAULT_POSITION_KI;
  config.velocity_damping_gain =
    BALL_BALANCE_DEFAULT_VELOCITY_DAMPING_GAIN;
  config.velocity_filter_alpha =
    BALL_BALANCE_DEFAULT_VELOCITY_FILTER_ALPHA;
  config.observer_alpha = BALL_BALANCE_DEFAULT_OBSERVER_ALPHA;
  config.observer_beta = BALL_BALANCE_DEFAULT_OBSERVER_BETA;
  config.max_angle_deg = BALL_BALANCE_DEFAULT_MAX_ANGLE_DEG;
  config.positive_pulses_per_beam_degree =
    BALL_BALANCE_DEFAULT_POSITIVE_PULSES_PER_DEG;
  config.negative_pulses_per_beam_degree =
    BALL_BALANCE_DEFAULT_NEGATIVE_PULSES_PER_DEG;
  config.pulse_hz = BALL_BALANCE_DEFAULT_PULSE_HZ;
  config.sample_timeout_ms = BALL_BALANCE_DEFAULT_SAMPLE_TIMEOUT_MS;
  config.actuator_chunk_pulses =
    BALL_BALANCE_DEFAULT_ACTUATOR_CHUNK_PULSES;
  config.test_pulses = BALL_BALANCE_DEFAULT_TEST_PULSES;

  stats.received_locations = 0UL;
  stats.control_updates = 0UL;
  stats.estimator_resyncs = 0UL;
  stats.location_cm = 0.0f;
  stats.reference_motor_pulses = 0L;
  reference_motor_pulses = 0L;
  target_motor_pulses = 0L;
  stats.measured_location_cm = 0.0f;
  stats.camera_velocity_active = 0U;
  last_measurement_cm = 0.0f;
  estimated_location_cm = 0.0f;
  last_sample_timestamp_ms = 0UL;
  last_received_tick_ms = 0UL;
  estimator_valid = 0U;
  actuator_move_active = 0U;
  control_mode = BALANCE_CONTROL_POSITION_DAMPING;
  state = BALANCE_STATE_STOPPED;
  BallBalance_ResetController();
  (void)D36A_SetPulseFrequency(config.pulse_hz);
}

static uint8_t BallBalance_StartMode(BalanceControlMode_t requested_mode)
{
  if ((state == BALANCE_STATE_FAULT) || D36A_IsBusy())
  {
    return 0U;
  }
  D36A_Abort();
  (void)D36A_TakeEvent();
  actuator_move_active = 0U;
  if (!D36A_SetPulseFrequency(config.pulse_hz))
  {
    BallBalance_EnterFault();
    return 0U;
  }
  D36A_Enable(1U);
  control_mode = requested_mode;
  reference_motor_pulses = D36A_GetCommandedPositionPulses();
  stats.reference_motor_pulses = reference_motor_pulses;
  estimator_valid = 0U;
  BallBalance_ResetController();
  CameraLink_DiscardPending();
  if (CameraLink_StartStream() != HAL_OK)
  {
    BallBalance_EnterFault();
    return 0U;
  }
  last_received_tick_ms = HAL_GetTick();
  state = BALANCE_STATE_ACQUIRE;
  return 1U;
}

uint8_t BallBalance_Start(void)
{
  return BallBalance_StartMode(BALANCE_CONTROL_POSITION_DAMPING);
}

uint8_t BallBalance_StartVelocityZeroTest(void)
{
  return BallBalance_StartMode(BALANCE_CONTROL_VELOCITY_ZERO);
}

void BallBalance_Stop(void)
{
  D36A_Event_t event;

  if (state == BALANCE_STATE_FAULT)
  {
    (void)CameraLink_StopStream();
    CameraLink_DiscardPending();
    return;
  }

  /* Finish the current short block instead of aborting it.  D36A updates its
     absolute software position only after MOTION_DONE, so this keeps the
     calibration coordinate exact while bounding stop latency to 10 ms. */
  if (actuator_move_active)
  {
    while (D36A_IsBusy())
    {
      D36A_Task();
    }
    event = D36A_TakeEvent();
    actuator_move_active = 0U;
    if (event != D36A_EVENT_MOTION_DONE)
    {
      BallBalance_EnterFault();
      return;
    }
  }
  D36A_Abort();
  D36A_Enable(1U);
  (void)CameraLink_StopStream();
  CameraLink_DiscardPending();
  estimator_valid = 0U;
  state = BALANCE_STATE_STOPPED;
  target_motor_pulses = D36A_GetCommandedPositionPulses();
  stats.target_motor_pulses = target_motor_pulses;
  stats.position_output_deg = 0.0f;
  stats.velocity_damping_output_deg = 0.0f;
  stats.angle_command_deg = 0.0f;
}

void BallBalance_ClearFault(void)
{
  if (state == BALANCE_STATE_FAULT)
  {
    D36A_Abort();
    (void)D36A_TakeEvent();
    actuator_move_active = 0U;
    CameraLink_DiscardPending();
    estimator_valid = 0U;
    D36A_Enable(1U);
    state = BALANCE_STATE_STOPPED;
  }
}

void BallBalance_Task(void)
{
  CameraLocationSample_t sample;

  if (BallBalance_IsActiveState(state))
  {
    while (CameraLink_PopLocation(&sample))
    {
      BallBalance_ProcessSample(&sample);
      if (state == BALANCE_STATE_FAULT) { return; }
    }

    if ((state != BALANCE_STATE_LOST) &&
        ((uint32_t)(HAL_GetTick() - last_received_tick_ms) >
         config.sample_timeout_ms))
    {
      estimator_valid = 0U;
      BallBalance_ResetController();
      state = BALANCE_STATE_LOST;
    }
    BallBalance_ServiceActuator();
  }
}

uint8_t BallBalance_IsRunning(void)
{
  return BallBalance_IsActiveState(state);
}

BalanceState_t BallBalance_GetState(void) { return state; }
const BalanceConfig_t *BallBalance_GetConfig(void) { return &config; }
const BalanceStats_t *BallBalance_GetStats(void) { return &stats; }

uint8_t BallBalance_SetConfig(const BalanceConfig_t *new_config)
{
  if ((new_config == 0) || BallBalance_IsRunning() || D36A_IsBusy())
  {
    return 0U;
  }
  if (!((new_config->position_kp >= 0.0f) &&
        (new_config->position_kp <= BALANCE_POSITION_GAIN_MAX) &&
        (new_config->position_ki >= 0.0f) &&
        (new_config->position_ki <= BALANCE_POSITION_GAIN_MAX) &&
        (new_config->velocity_damping_gain >= 0.0f) &&
        (new_config->velocity_damping_gain <=
         BALANCE_VELOCITY_DAMPING_GAIN_MAX) &&
        (new_config->velocity_filter_alpha >=
         BALANCE_VELOCITY_FILTER_ALPHA_MIN) &&
        (new_config->velocity_filter_alpha <=
         BALANCE_VELOCITY_FILTER_ALPHA_MAX) &&
        (new_config->observer_alpha >= BALANCE_OBSERVER_ALPHA_MIN) &&
        (new_config->observer_alpha <= BALANCE_OBSERVER_ALPHA_MAX) &&
        (new_config->observer_beta >= BALANCE_OBSERVER_BETA_MIN) &&
        (new_config->observer_beta <= BALANCE_OBSERVER_BETA_MAX) &&
        (new_config->observer_beta <
         (2.0f * new_config->observer_alpha)) &&
        (new_config->max_angle_deg >= BALANCE_MAX_ANGLE_MIN) &&
        (new_config->max_angle_deg <= BALANCE_MAX_ANGLE_MAX) &&
        (new_config->positive_pulses_per_beam_degree >=
         BALANCE_PULSES_PER_DEGREE_MIN) &&
        (new_config->positive_pulses_per_beam_degree <=
          BALANCE_PULSES_PER_DEGREE_MAX) &&
        (new_config->negative_pulses_per_beam_degree >=
         BALANCE_PULSES_PER_DEGREE_MIN) &&
        (new_config->negative_pulses_per_beam_degree <=
          BALANCE_PULSES_PER_DEGREE_MAX) &&
        ((new_config->max_angle_deg *
          new_config->positive_pulses_per_beam_degree) <=
         BALANCE_MAX_RELATIVE_PULSES) &&
        ((new_config->max_angle_deg *
          new_config->negative_pulses_per_beam_degree) <=
         BALANCE_MAX_RELATIVE_PULSES)))
  {
    return 0U;
  }
  if ((new_config->pulse_hz < D36A_MIN_PULSE_HZ) ||
      (new_config->pulse_hz > D36A_MAX_PULSE_HZ) ||
      (new_config->sample_timeout_ms < BALANCE_SAMPLE_TIMEOUT_MIN_MS) ||
      (new_config->sample_timeout_ms > BALANCE_SAMPLE_TIMEOUT_MAX_MS) ||
      (new_config->actuator_chunk_pulses < BALANCE_ACTUATOR_CHUNK_MIN) ||
      (new_config->actuator_chunk_pulses > BALANCE_ACTUATOR_CHUNK_MAX) ||
      (((uint64_t)new_config->actuator_chunk_pulses * 1000000ULL) >
       ((uint64_t)new_config->pulse_hz *
        BALANCE_ACTUATOR_CHUNK_MAX_US)) ||
      (new_config->test_pulses < BALANCE_TEST_PULSES_MIN) ||
      (new_config->test_pulses > BALANCE_TEST_PULSES_MAX))
  {
    return 0U;
  }
  if ((new_config->pulse_hz != config.pulse_hz) &&
      !D36A_SetPulseFrequency(new_config->pulse_hz))
  {
    return 0U;
  }
  config = *new_config;
  return 1U;
}
