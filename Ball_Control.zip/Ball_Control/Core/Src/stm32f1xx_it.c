#include "main.h"
#include "stm32f1xx_it.h"
#include "usart.h"
#include "d36a.h"

static void EmergencyMotorStop(void)
{
  TIM2->DIER = 0U;
  TIM2->CR1 &= ~TIM_CR1_CEN;
  TIM2->CCER &= ~TIM_CCER_CC1E;
  /* D36A EN drives ATD5984 nSLEEP: low disables the output stage. */
  D36A_EN_GPIO_Port->BRR = D36A_EN_Pin;
}

void NMI_Handler(void) { }

void HardFault_Handler(void)
{
  EmergencyMotorStop();
  while (1) { }
}

void MemManage_Handler(void)
{
  EmergencyMotorStop();
  while (1) { }
}

void BusFault_Handler(void)
{
  EmergencyMotorStop();
  while (1) { }
}

void UsageFault_Handler(void)
{
  EmergencyMotorStop();
  while (1) { }
}

void SVC_Handler(void) { }
void DebugMon_Handler(void) { }
void PendSV_Handler(void) { }

void SysTick_Handler(void)
{
  HAL_IncTick();
}

void TIM2_IRQHandler(void)
{
  D36A_TimerIRQHandler();
}

void USART1_IRQHandler(void)
{
  HAL_UART_IRQHandler(&huart1);
}
