#include "d36a.h"
#include "tim.h"

typedef struct
{
  uint32_t pulses_per_revolution;
  uint32_t pulse_hz;
  volatile uint32_t remaining_pulses;
  uint32_t command_pulses;
  int8_t command_direction;
  volatile D36A_State_t state;
  volatile D36A_Event_t event;
  volatile uint8_t enabled;
  volatile int32_t commanded_position;
  volatile uint32_t command_deadline;
} D36A_Context_t;

typedef struct
{
  uint32_t pulses_per_revolution;
  D36A_DipSwitch_t dip;
} D36A_MicrostepEntry_t;

/*
 * D36A uses inverting DIP wiring: a switch toward ON drives the matching
 * ATD5984 MS input low.  The duplicate half-step and 1/16 settings are
 * represented by one canonical physical setting each.
 */
static const D36A_MicrostepEntry_t microstep_table[] =
{
  { 200UL, {1U, 1U, 1U}}, /* full step */
  { 400UL, {0U, 1U, 1U}}, /* half step, 100 percent */
  { 800UL, {0U, 1U, 0U}}, /* quarter step */
  {1600UL, {1U, 0U, 0U}}, /* 1/8 step */
  {3200UL, {0U, 0U, 0U}}, /* 1/16 step; all toward the fan */
  {6400UL, {1U, 0U, 1U}}  /* 1/32 step */
};

static D36A_Context_t motor;

static uint32_t D36A_Lock(void)
{
  uint32_t primask = __get_PRIMASK();
  __disable_irq();
  return primask;
}

static void D36A_Unlock(uint32_t primask)
{
  if (primask == 0U)
  {
    __enable_irq();
  }
}

static void D36A_SetDirectionPin(int8_t direction)
{
  HAL_GPIO_WritePin(D36A_DIR_GPIO_Port, D36A_DIR_Pin,
                    (direction >= 0) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static void D36A_TimerStop(void)
{
  TIM2->DIER &= ~(TIM_DIER_UIE | TIM_DIER_CC1IE);
  TIM2->CR1 &= ~TIM_CR1_CEN;
  TIM2->CCER &= ~TIM_CCER_CC1E;
  TIM2->SR = 0U;
}

static void D36A_TimerStartDirectionSetup(void)
{
  D36A_TimerStop();
  /* RM0008: the counter is blocked when ARR is zero.  Load ARR with the
     delay in ticks and start CNT at one, so the next overflow occurs after
     exactly D36A_DIR_SETUP_US ticks without ever using ARR=0. */
  TIM2->ARR = D36A_DIR_SETUP_US;
  TIM2->CCR1 = 0U;
  TIM2->EGR = TIM_EGR_UG;
  TIM2->SR = 0U;
  TIM2->CNT = 1U;
  TIM2->DIER = TIM_DIER_UIE;
  TIM2->CR1 |= TIM_CR1_CEN;
}

static uint32_t D36A_GetCommandTimeoutMs(uint32_t pulses, uint32_t legs)
{
  uint64_t pulse_time_ms;

  pulse_time_ms = ((uint64_t)pulses * (uint64_t)legs * 1000ULL +
                   (uint64_t)motor.pulse_hz - 1ULL) /
                  (uint64_t)motor.pulse_hz;
  pulse_time_ms += D36A_COMMAND_TIMEOUT_MARGIN_MS + 1ULL;
  if (pulse_time_ms > 0x7FFFFFFFULL)
  {
    pulse_time_ms = 0x7FFFFFFFULL;
  }
  return (uint32_t)pulse_time_ms;
}

static void D36A_TimerStartPulses(void)
{
  uint32_t period_ticks = D36A_TIMER_HZ / motor.pulse_hz;

  if (period_ticks < 10UL)
  {
    period_ticks = 10UL;
  }

  D36A_TimerStop();
  TIM2->ARR = period_ticks - 1UL;
  TIM2->CCR1 = period_ticks / 2UL;
  TIM2->CNT = 0U;
  TIM2->EGR = TIM_EGR_UG;
  TIM2->SR = 0U;
  TIM2->CCER |= TIM_CCER_CC1E;
  TIM2->DIER = TIM_DIER_CC1IE;
  TIM2->CR1 |= TIM_CR1_CEN;
}

void D36A_Init(void)
{
  D36A_TimerStop();
  motor.pulses_per_revolution = 3200UL;
  motor.pulse_hz = 1500UL;
  motor.remaining_pulses = 0UL;
  motor.command_pulses = 0UL;
  motor.command_direction = 1;
  motor.state = D36A_STATE_IDLE;
  motor.event = D36A_EVENT_NONE;
  motor.enabled = 0U;
  motor.commanded_position = 0;
  motor.command_deadline = 0UL;
  D36A_SetDirectionPin(1);
  /* Keep the shaft locked whenever the controller is powered and healthy. */
  D36A_Enable(1U);
}

void D36A_Task(void)
{
  uint32_t primask;

  if ((motor.command_deadline == 0UL) || !D36A_IsBusy() ||
      ((int32_t)(HAL_GetTick() - motor.command_deadline) < 0))
  {
    return;
  }

  primask = D36A_Lock();
  if ((motor.command_deadline != 0UL) && D36A_IsBusy() &&
      ((int32_t)(HAL_GetTick() - motor.command_deadline) >= 0))
  {
    D36A_TimerStop();
    motor.remaining_pulses = 0UL;
    motor.command_deadline = 0UL;
    motor.state = D36A_STATE_IDLE;
    motor.event = D36A_EVENT_ERROR;
    HAL_GPIO_WritePin(D36A_EN_GPIO_Port, D36A_EN_Pin, GPIO_PIN_RESET);
    motor.enabled = 0U;
  }
  D36A_Unlock(primask);
}

void D36A_Enable(uint8_t enable)
{
  uint8_t requested = enable ? 1U : 0U;

  if (requested == motor.enabled)
  {
    return;
  }

  /* D36A EN is wired to ATD5984 nSLEEP: high runs, low sleeps. */
  HAL_GPIO_WritePin(D36A_EN_GPIO_Port, D36A_EN_Pin,
                    requested ? GPIO_PIN_SET : GPIO_PIN_RESET);
  motor.enabled = requested;

  if (requested)
  {
    /* The ATD5984 charge pump requires 1 ms before the first STEP edge. */
    HAL_Delay(D36A_WAKE_DELAY_MS);
  }
}

uint8_t D36A_IsEnabled(void)
{
  return motor.enabled;
}

uint8_t D36A_SetDirection(int8_t direction)
{
  if (D36A_IsBusy())
  {
    return 0U;
  }
  motor.command_direction = (direction >= 0) ? 1 : -1;
  D36A_SetDirectionPin(motor.command_direction);
  return 1U;
}

uint8_t D36A_IsBusy(void)
{
  return (motor.state != D36A_STATE_IDLE) ? 1U : 0U;
}

D36A_State_t D36A_GetState(void)
{
  return motor.state;
}

uint8_t D36A_SetMicrostep(uint32_t pulses_per_revolution)
{
  uint32_t i;

  if (D36A_IsBusy())
  {
    return 0U;
  }
  for (i = 0U; i < (sizeof(microstep_table) / sizeof(microstep_table[0])); ++i)
  {
    if (microstep_table[i].pulses_per_revolution == pulses_per_revolution)
    {
      motor.pulses_per_revolution = pulses_per_revolution;
      return 1U;
    }
  }
  return 0U;
}

uint32_t D36A_GetMicrostep(void)
{
  return motor.pulses_per_revolution;
}

uint8_t D36A_GetDipSwitch(D36A_DipSwitch_t *setting)
{
  uint32_t i;

  if (setting == 0)
  {
    return 0U;
  }
  for (i = 0U; i < (sizeof(microstep_table) / sizeof(microstep_table[0])); ++i)
  {
    if (microstep_table[i].pulses_per_revolution == motor.pulses_per_revolution)
    {
      *setting = microstep_table[i].dip;
      return 1U;
    }
  }
  return 0U;
}

uint8_t D36A_SetPulseFrequency(uint32_t pulse_hz)
{
  if ((pulse_hz < D36A_MIN_PULSE_HZ) ||
      (pulse_hz > D36A_MAX_PULSE_HZ) || D36A_IsBusy())
  {
    return 0U;
  }
  motor.pulse_hz = pulse_hz;
  return 1U;
}

uint32_t D36A_GetPulseFrequency(void)
{
  return motor.pulse_hz;
}

uint8_t D36A_SetSpeedRpm(float rpm)
{
  float pulse_hz;
  float minimum_rpm;
  float maximum_rpm;

  minimum_rpm = ((float)D36A_MIN_PULSE_HZ * 60.0f) /
                (float)motor.pulses_per_revolution;
  maximum_rpm = ((float)D36A_MAX_PULSE_HZ * 60.0f) /
                (float)motor.pulses_per_revolution;
  /* The positive-range form also rejects NaN without pulling in libm. */
  if (!((rpm >= minimum_rpm) && (rpm <= maximum_rpm)))
  {
    return 0U;
  }

  pulse_hz = (rpm * (float)motor.pulses_per_revolution) / 60.0f;
  return D36A_SetPulseFrequency((uint32_t)(pulse_hz + 0.5f));
}

float D36A_GetSpeedRpm(void)
{
  return ((float)motor.pulse_hz * 60.0f) /
         (float)motor.pulses_per_revolution;
}

uint32_t D36A_AngleToPulses(float angle_degrees)
{
  float magnitude = angle_degrees;

  if (magnitude < 0.0f)
  {
    magnitude = -magnitude;
  }
  return (uint32_t)((magnitude * (float)motor.pulses_per_revolution / 360.0f) + 0.5f);
}

float D36A_PulsesToAngle(uint32_t pulses)
{
  return ((float)pulses * 360.0f) / (float)motor.pulses_per_revolution;
}

static uint8_t D36A_StartCommand(int8_t direction, uint32_t pulses,
                                 D36A_State_t setup_state)
{
  uint32_t primask;

  if ((pulses == 0UL) || !motor.enabled || D36A_IsBusy())
  {
    return 0U;
  }
  primask = D36A_Lock();
  motor.command_direction = (direction >= 0) ? 1 : -1;
  motor.command_pulses = pulses;
  motor.remaining_pulses = pulses;
  motor.command_deadline = HAL_GetTick() +
    D36A_GetCommandTimeoutMs(pulses,
      (setup_state == D36A_STATE_DIR_SETUP_OUTBOUND) ? 2UL : 1UL);
  motor.event = D36A_EVENT_NONE;
  D36A_SetDirectionPin(motor.command_direction);
  motor.state = setup_state;
  D36A_TimerStartDirectionSetup();
  D36A_Unlock(primask);
  return 1U;
}

uint8_t D36A_MovePulses(int8_t direction, uint32_t pulses)
{
  return D36A_StartCommand(direction, pulses, D36A_STATE_DIR_SETUP_MOVE);
}

uint8_t D36A_MoveAngle(float angle_degrees)
{
  int8_t direction = (angle_degrees >= 0.0f) ? 1 : -1;
  return D36A_MovePulses(direction, D36A_AngleToPulses(angle_degrees));
}

uint8_t D36A_StartImpulse(int8_t direction, uint32_t pulses)
{
  return D36A_StartCommand(direction, pulses, D36A_STATE_DIR_SETUP_OUTBOUND);
}

void D36A_Abort(void)
{
  uint32_t primask = D36A_Lock();
  uint8_t was_busy = D36A_IsBusy();

  D36A_TimerStop();
  motor.remaining_pulses = 0UL;
  motor.command_deadline = 0UL;
  motor.state = D36A_STATE_IDLE;
  if (was_busy)
  {
    motor.event = D36A_EVENT_ABORTED;
  }
  D36A_Unlock(primask);
}

D36A_Event_t D36A_TakeEvent(void)
{
  uint32_t primask = D36A_Lock();
  D36A_Event_t event = motor.event;
  motor.event = D36A_EVENT_NONE;
  D36A_Unlock(primask);
  return event;
}

int32_t D36A_GetCommandedPositionPulses(void)
{
  return motor.commanded_position;
}

uint8_t D36A_SetCurrentPositionAsZero(void)
{
  uint32_t primask = D36A_Lock();

  if (motor.state != D36A_STATE_IDLE)
  {
    D36A_Unlock(primask);
    return 0U;
  }
  motor.commanded_position = 0;
  D36A_Unlock(primask);
  return 1U;
}

void D36A_TimerIRQHandler(void)
{
  if (((TIM2->DIER & TIM_DIER_UIE) != 0U) &&
      ((TIM2->SR & TIM_SR_UIF) != 0U))
  {
    TIM2->SR &= ~TIM_SR_UIF;
    if (motor.state == D36A_STATE_DIR_SETUP_MOVE)
    {
      motor.state = D36A_STATE_MOVING;
      D36A_TimerStartPulses();
    }
    else if (motor.state == D36A_STATE_DIR_SETUP_OUTBOUND)
    {
      motor.state = D36A_STATE_OUTBOUND;
      D36A_TimerStartPulses();
    }
    else if (motor.state == D36A_STATE_DIR_SETUP_RETURN)
    {
      motor.state = D36A_STATE_RETURNING;
      D36A_TimerStartPulses();
    }
    else
    {
      D36A_TimerStop();
      motor.command_deadline = 0UL;
      motor.state = D36A_STATE_IDLE;
      motor.event = D36A_EVENT_ERROR;
    }
  }

  if (((TIM2->DIER & TIM_DIER_CC1IE) != 0U) &&
      ((TIM2->SR & TIM_SR_CC1IF) != 0U))
  {
    TIM2->SR &= ~TIM_SR_CC1IF;
    if (motor.remaining_pulses > 0UL)
    {
      --motor.remaining_pulses;
    }
    if (motor.remaining_pulses == 0UL)
    {
      D36A_TimerStop();
      if (motor.state == D36A_STATE_OUTBOUND)
      {
        D36A_SetDirectionPin((int8_t)-motor.command_direction);
        motor.remaining_pulses = motor.command_pulses;
        motor.state = D36A_STATE_DIR_SETUP_RETURN;
        D36A_TimerStartDirectionSetup();
      }
      else if (motor.state == D36A_STATE_RETURNING)
      {
        motor.command_deadline = 0UL;
        motor.state = D36A_STATE_IDLE;
        motor.event = D36A_EVENT_MOTION_DONE;
      }
      else if (motor.state == D36A_STATE_MOVING)
      {
        motor.commanded_position +=
          (int32_t)motor.command_direction * (int32_t)motor.command_pulses;
        motor.command_deadline = 0UL;
        motor.state = D36A_STATE_IDLE;
        motor.event = D36A_EVENT_MOTION_DONE;
      }
      else
      {
        motor.command_deadline = 0UL;
        motor.state = D36A_STATE_IDLE;
        motor.event = D36A_EVENT_ERROR;
      }
    }
  }
}
