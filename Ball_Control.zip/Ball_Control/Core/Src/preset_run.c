#include "preset_run.h"
#include "d36a.h"
#include "stm32f1xx_hal.h"

#define PRESET_RUN_DOWN_FIRST_DIRECTION  1
#define PRESET_RUN_PULSES_MIN           10UL
#define PRESET_RUN_PULSES_MAX         1600UL
#define PRESET_RUN_FREQUENCY_MIN        100UL
#define PRESET_RUN_FREQUENCY_MAX      10000UL
#define PRESET_RUN_INTERVAL_MIN         200UL
#define PRESET_RUN_INTERVAL_MAX        3000UL

static PresetRunConfig_t config;
static PresetRunState_t state;
static const int8_t step_direction[PRESET_RUN_STEP_COUNT] =
{
  PRESET_RUN_DOWN_FIRST_DIRECTION,
  -PRESET_RUN_DOWN_FIRST_DIRECTION,
  PRESET_RUN_DOWN_FIRST_DIRECTION,
  -PRESET_RUN_DOWN_FIRST_DIRECTION
};
static uint32_t interval_deadline;
static uint32_t saved_motor_pulse_hz;
static uint32_t run_start_tick;
static uint32_t run_elapsed_ms;
static uint8_t owns_motor_config;
static uint8_t current_step;

static uint8_t PresetRun_PulseGroupForStep(uint8_t step_index)
{
  return ((step_index == 0U) || (step_index == 3U)) ?
         PRESET_RUN_PULSE_GROUP_STEP1 : PRESET_RUN_PULSE_GROUP_STEP23;
}

static void PresetRun_RestoreMotorFrequency(void)
{
  if (owns_motor_config)
  {
    D36A_Abort();
    (void)D36A_TakeEvent();
    (void)D36A_SetPulseFrequency(saved_motor_pulse_hz);
    owns_motor_config = 0U;
  }
}

static void PresetRun_EnterFault(void)
{
  if (PresetRun_IsRunning())
  {
    run_elapsed_ms = HAL_GetTick() - run_start_tick;
  }
  PresetRun_RestoreMotorFrequency();
  D36A_Enable(0U);
  state = PRESET_RUN_STATE_FAULT;
}

static uint8_t PresetRun_StartCurrentStep(void)
{
  const PresetRunStepConfig_t *step;

  if (current_step >= PRESET_RUN_STEP_COUNT)
  {
    PresetRun_EnterFault();
    return 0U;
  }

  step = &config.step[current_step];
  if (!D36A_SetPulseFrequency(step->pulse_hz))
  {
    PresetRun_EnterFault();
    return 0U;
  }

  (void)D36A_TakeEvent();
  if (!D36A_MovePulses(step_direction[current_step],
                       PresetRun_GetStepPulses(current_step)))
  {
    PresetRun_EnterFault();
    return 0U;
  }
  state = PRESET_RUN_STATE_MOVING;
  return 1U;
}

void PresetRun_Init(void)
{
  uint8_t i;

  /* Deliberately independent from the camera balance configuration. */
  config.pulse_group[PRESET_RUN_PULSE_GROUP_STEP1] = 130UL;
  config.pulse_group[PRESET_RUN_PULSE_GROUP_STEP23] = 260UL;
  for (i = 0U; i < PRESET_RUN_STEP_COUNT; ++i)
  {
    config.step[i].pulse_hz = 1000UL;
  }
  config.step[0U].interval_ms = 250UL;
  config.step[1U].interval_ms = 650UL;
  config.step[2U].interval_ms = 200UL;
  config.step[3U].interval_ms = 1000UL;
  config.target_offset_pulses = 0;
  config.target_offset_valid = 0U;
  state = PRESET_RUN_STATE_IDLE;
  interval_deadline = 0UL;
  saved_motor_pulse_hz = 0UL;
  run_start_tick = 0UL;
  run_elapsed_ms = 0UL;
  owns_motor_config = 0U;
  current_step = 0U;
}

uint8_t PresetRun_Start(void)
{
  if (PresetRun_IsRunning() || D36A_IsBusy() ||
      !config.target_offset_valid ||
      (PresetRun_GetStepPulses(3U) == 0UL))
  {
    return 0U;
  }

  D36A_Abort();
  (void)D36A_TakeEvent();
  saved_motor_pulse_hz = D36A_GetPulseFrequency();
  owns_motor_config = 1U;
  current_step = 0U;
  D36A_Enable(1U);
  run_elapsed_ms = 0UL;
  run_start_tick = HAL_GetTick();
  if (!PresetRun_StartCurrentStep())
  {
    run_elapsed_ms = 0UL;
    return 0U;
  }
  return 1U;
}

void PresetRun_Stop(void)
{
  PresetRun_RestoreMotorFrequency();
  D36A_Enable(1U);
  current_step = 0U;
  run_elapsed_ms = 0UL;
  state = PRESET_RUN_STATE_IDLE;
}

void PresetRun_ClearFault(void)
{
  if (state == PRESET_RUN_STATE_FAULT)
  {
    D36A_Abort();
    (void)D36A_TakeEvent();
    D36A_Enable(1U);
    current_step = 0U;
    state = PRESET_RUN_STATE_IDLE;
  }
}

void PresetRun_Task(void)
{
  D36A_Event_t motor_event = D36A_EVENT_NONE;

  if (state == PRESET_RUN_STATE_MOVING)
  {
    motor_event = D36A_TakeEvent();
    if (motor_event == D36A_EVENT_MOTION_DONE)
    {
      /* This delay starts after the current move has physically completed. */
      interval_deadline = HAL_GetTick() +
                          config.step[current_step].interval_ms;
      state = PRESET_RUN_STATE_INTERVAL;
    }
    else if ((motor_event == D36A_EVENT_ERROR) ||
             (motor_event == D36A_EVENT_ABORTED))
    {
      PresetRun_EnterFault();
    }
  }

  if ((state == PRESET_RUN_STATE_INTERVAL) &&
      ((int32_t)(HAL_GetTick() - interval_deadline) >= 0))
  {
    if ((uint8_t)(current_step + 1U) < PRESET_RUN_STEP_COUNT)
    {
      ++current_step;
      (void)PresetRun_StartCurrentStep();
    }
    else
    {
      /* Step 4 interval ends here.  Preset remains at -5 cm with the shaft
         energized; camera streaming and balance control stay stopped. */
      PresetRun_RestoreMotorFrequency();
      D36A_Enable(1U);
      run_elapsed_ms = HAL_GetTick() - run_start_tick;
      state = PRESET_RUN_STATE_COMPLETE;
    }
  }

  if ((state == PRESET_RUN_STATE_INTERVAL) && !D36A_IsBusy() &&
      !D36A_IsEnabled())
  {
    D36A_Enable(1U);
  }
}

uint8_t PresetRun_IsRunning(void)
{
  return ((state != PRESET_RUN_STATE_IDLE) &&
          (state != PRESET_RUN_STATE_COMPLETE) &&
          (state != PRESET_RUN_STATE_FAULT)) ? 1U : 0U;
}

PresetRunState_t PresetRun_GetState(void) { return state; }
const PresetRunConfig_t *PresetRun_GetConfig(void) { return &config; }
uint8_t PresetRun_GetCurrentStep(void) { return current_step; }
uint32_t PresetRun_GetStepPulses(uint8_t step_index)
{
  int64_t computed_pulses;

  if (step_index >= PRESET_RUN_STEP_COUNT)
  {
    return 0UL;
  }
  if (step_index == 3U)
  {
    if (!config.target_offset_valid)
    {
      return 0UL;
    }
    computed_pulses =
      (int64_t)config.pulse_group[PRESET_RUN_PULSE_GROUP_STEP1] -
      (int64_t)config.target_offset_pulses;
    if ((computed_pulses < (int64_t)PRESET_RUN_PULSES_MIN) ||
        (computed_pulses > (int64_t)PRESET_RUN_PULSES_MAX))
    {
      return 0UL;
    }
    return (uint32_t)computed_pulses;
  }
  return config.pulse_group[PresetRun_PulseGroupForStep(step_index)];
}
uint32_t PresetRun_GetElapsedMs(void)
{
  if (PresetRun_IsRunning())
  {
    return HAL_GetTick() - run_start_tick;
  }
  return run_elapsed_ms;
}

uint8_t PresetRun_SetPulseGroup(uint8_t group_index, uint32_t pulses)
{
  if (PresetRun_IsRunning() ||
      (group_index >= PRESET_RUN_PULSE_GROUP_COUNT) ||
      (pulses < PRESET_RUN_PULSES_MIN) ||
      (pulses > PRESET_RUN_PULSES_MAX))
  {
    return 0U;
  }
  config.pulse_group[group_index] = pulses;
  return 1U;
}

uint8_t PresetRun_SetStepFrequency(uint8_t step_index, uint32_t pulse_hz)
{
  if (PresetRun_IsRunning() || (step_index >= PRESET_RUN_STEP_COUNT) ||
      (pulse_hz < PRESET_RUN_FREQUENCY_MIN) ||
      (pulse_hz > PRESET_RUN_FREQUENCY_MAX))
  {
    return 0U;
  }
  config.step[step_index].pulse_hz = pulse_hz;
  return 1U;
}

uint8_t PresetRun_SetStepInterval(uint8_t step_index, uint32_t interval_ms)
{
  if (PresetRun_IsRunning() || (step_index >= PRESET_RUN_STEP_COUNT) ||
      (interval_ms < PRESET_RUN_INTERVAL_MIN) ||
      (interval_ms > PRESET_RUN_INTERVAL_MAX))
  {
    return 0U;
  }
  config.step[step_index].interval_ms = interval_ms;
  return 1U;
}

uint8_t PresetRun_SetTargetOffsetPulses(int32_t offset_pulses,
                                        uint8_t valid)
{
  if (PresetRun_IsRunning())
  {
    return 0U;
  }
  config.target_offset_pulses = offset_pulses;
  config.target_offset_valid = valid ? 1U : 0U;
  return 1U;
}
