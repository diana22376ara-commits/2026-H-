#include "OLED.h"

#include <stdarg.h>

#define OLED_WIDTH_PX       128U
#define OLED_PAGE_COUNT       8U
#define OLED_I2C_ADDRESS    0x78U
#define OLED_TEXT_BUFFER_SIZE 64U

uint8_t OLED_DisplayBuf[OLED_PAGE_COUNT][OLED_WIDTH_PX];

static void OLED_WriteScl(uint8_t level)
{
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, (GPIO_PinState)level);
}

static void OLED_WriteSda(uint8_t level)
{
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, (GPIO_PinState)level);
}

static void OLED_BusStart(void)
{
  OLED_WriteSda(1U);
  OLED_WriteScl(1U);
  OLED_WriteSda(0U);
  OLED_WriteScl(0U);
}

static void OLED_BusStop(void)
{
  OLED_WriteSda(0U);
  OLED_WriteScl(1U);
  OLED_WriteSda(1U);
}

static void OLED_SendByte(uint8_t value)
{
  uint8_t bit;

  for (bit = 0U; bit < 8U; ++bit)
  {
    OLED_WriteSda((value & (uint8_t)(0x80U >> bit)) ? 1U : 0U);
    OLED_WriteScl(1U);
    OLED_WriteScl(0U);
  }
  /* The display is write-only in this design; the ACK bit is not sampled. */
  OLED_WriteScl(1U);
  OLED_WriteScl(0U);
}

static void OLED_WriteCommand(uint8_t command)
{
  OLED_BusStart();
  OLED_SendByte(OLED_I2C_ADDRESS);
  OLED_SendByte(0x00U);
  OLED_SendByte(command);
  OLED_BusStop();
}

static void OLED_WriteData(const uint8_t *data, uint8_t count)
{
  uint8_t index;

  OLED_BusStart();
  OLED_SendByte(OLED_I2C_ADDRESS);
  OLED_SendByte(0x40U);
  for (index = 0U; index < count; ++index)
  {
    OLED_SendByte(data[index]);
  }
  OLED_BusStop();
}

static void OLED_SetCursor(uint8_t page, uint8_t x)
{
  OLED_WriteCommand((uint8_t)(0xB0U | page));
  OLED_WriteCommand((uint8_t)(0x10U | ((x & 0xF0U) >> 4U)));
  OLED_WriteCommand((uint8_t)(x & 0x0FU));
}

static void OLED_ShowAsciiChar(int16_t x, int16_t y, char character)
{
  int16_t column;
  int16_t page;
  const uint8_t *glyph;

  if ((character < ' ') || (character > '~'))
  {
    character = '?';
  }
  if ((y < 0) || ((y & 7) != 0))
  {
    return;
  }

  page = y / 8;
  glyph = OLED_F8x16[(uint8_t)character - (uint8_t)' '];
  for (column = 0; column < 8; ++column)
  {
    int16_t screen_x = x + column;
    if ((screen_x < 0) || (screen_x >= (int16_t)OLED_WIDTH_PX))
    {
      continue;
    }
    if (page < (int16_t)OLED_PAGE_COUNT)
    {
      OLED_DisplayBuf[page][screen_x] = glyph[column];
    }
    if ((page + 1) < (int16_t)OLED_PAGE_COUNT)
    {
      OLED_DisplayBuf[page + 1][screen_x] = glyph[8 + column];
    }
  }
}

static void OLED_ShowAsciiString(int16_t x, int16_t y, const char *text)
{
  while ((*text != '\0') && (x < (int16_t)OLED_WIDTH_PX))
  {
    OLED_ShowAsciiChar(x, y, *text++);
    x += OLED_8X16;
  }
}

static void OLED_AppendChar(char **output, const char *end, char value)
{
  if (*output < end)
  {
    *(*output)++ = value;
  }
}

static void OLED_AppendString(char **output, const char *end,
                              const char *value)
{
  if (value == 0)
  {
    value = "(null)";
  }
  while (*value != '\0')
  {
    OLED_AppendChar(output, end, *value++);
  }
}

static void OLED_AppendUnsigned(char **output, const char *end,
                                uint32_t value, uint8_t width,
                                char padding)
{
  char digits[10];
  uint8_t count = 0U;

  do
  {
    digits[count++] = (char)('0' + (value % 10UL));
    value /= 10UL;
  } while ((value != 0UL) && (count < sizeof(digits)));

  while (width > count)
  {
    OLED_AppendChar(output, end, padding);
    --width;
  }
  while (count > 0U)
  {
    OLED_AppendChar(output, end, digits[--count]);
  }
}

static void OLED_AppendSigned(char **output, const char *end,
                              int32_t value, uint8_t width,
                              char padding)
{
  uint32_t magnitude;

  if (value < 0)
  {
    OLED_AppendChar(output, end, '-');
    if (width > 0U)
    {
      --width;
    }
    magnitude = (uint32_t)(-(value + 1L)) + 1UL;
  }
  else
  {
    magnitude = (uint32_t)value;
  }
  OLED_AppendUnsigned(output, end, magnitude, width, padding);
}

void OLED_Init(void)
{
  uint32_t outer;
  uint32_t inner;

  /* Preserve the original power-up settling delay before the first command. */
  for (outer = 0UL; outer < 1000UL; ++outer)
  {
    for (inner = 0UL; inner < 1000UL; ++inner)
    {
      __NOP();
    }
  }
  OLED_WriteScl(1U);
  OLED_WriteSda(1U);

  OLED_WriteCommand(0xAEU);
  OLED_WriteCommand(0xD5U); OLED_WriteCommand(0x80U);
  OLED_WriteCommand(0xA8U); OLED_WriteCommand(0x3FU);
  OLED_WriteCommand(0xD3U); OLED_WriteCommand(0x00U);
  OLED_WriteCommand(0x40U);
  OLED_WriteCommand(0xA1U);
  OLED_WriteCommand(0xC8U);
  OLED_WriteCommand(0xDAU); OLED_WriteCommand(0x12U);
  OLED_WriteCommand(0x81U); OLED_WriteCommand(0xCFU);
  OLED_WriteCommand(0xD9U); OLED_WriteCommand(0xF1U);
  OLED_WriteCommand(0xDBU); OLED_WriteCommand(0x30U);
  OLED_WriteCommand(0xA4U);
  OLED_WriteCommand(0xA6U);
  OLED_WriteCommand(0x8DU); OLED_WriteCommand(0x14U);
  OLED_WriteCommand(0xAFU);

  OLED_Clear();
  OLED_Update();
}

void OLED_Update(void)
{
  uint8_t page;

  for (page = 0U; page < OLED_PAGE_COUNT; ++page)
  {
    OLED_SetCursor(page, 0U);
    OLED_WriteData(OLED_DisplayBuf[page], OLED_WIDTH_PX);
  }
}

void OLED_Clear(void)
{
  uint8_t page;
  uint8_t column;

  for (page = 0U; page < OLED_PAGE_COUNT; ++page)
  {
    for (column = 0U; column < OLED_WIDTH_PX; ++column)
    {
      OLED_DisplayBuf[page][column] = 0U;
    }
  }
}

void OLED_Printf(int16_t x, int16_t y, uint8_t font_size,
                 const char *format, ...)
{
  char text[OLED_TEXT_BUFFER_SIZE];
  char *output = text;
  const char *end = &text[OLED_TEXT_BUFFER_SIZE - 1U];
  va_list arguments;

  if ((font_size != OLED_8X16) || (format == 0))
  {
    return;
  }

  va_start(arguments, format);
  while ((*format != '\0') && (output < end))
  {
    uint8_t width = 0U;
    char padding = ' ';
    uint8_t long_argument = 0U;
    char specifier;

    if (*format != '%')
    {
      OLED_AppendChar(&output, end, *format++);
      continue;
    }
    ++format;
    if (*format == '%')
    {
      OLED_AppendChar(&output, end, *format++);
      continue;
    }
    if (*format == '0')
    {
      padding = '0';
      ++format;
    }
    while ((*format >= '0') && (*format <= '9'))
    {
      width = (uint8_t)(width * 10U + (uint8_t)(*format++ - '0'));
    }
    if (*format == 'l')
    {
      long_argument = 1U;
      ++format;
    }
    specifier = *format;
    if (specifier != '\0')
    {
      ++format;
    }

    switch (specifier)
    {
      case 's':
        OLED_AppendString(&output, end, va_arg(arguments, const char *));
        break;
      case 'c':
        OLED_AppendChar(&output, end, (char)va_arg(arguments, int));
        break;
      case 'u':
        OLED_AppendUnsigned(&output, end,
                            long_argument ? (uint32_t)va_arg(arguments, unsigned long) :
                                            (uint32_t)va_arg(arguments, unsigned int),
                            width, padding);
        break;
      case 'd':
        OLED_AppendSigned(&output, end,
                          long_argument ? (int32_t)va_arg(arguments, long) :
                                          (int32_t)va_arg(arguments, int),
                          width, padding);
        break;
      default:
        OLED_AppendChar(&output, end, '%');
        if (specifier != '\0')
        {
          OLED_AppendChar(&output, end, specifier);
        }
        break;
    }
  }
  va_end(arguments);
  *output = '\0';
  OLED_ShowAsciiString(x, y, text);
}
