#ifndef OLED_H
#define OLED_H

#include "OLED_Data.h"
#include "main.h"

#include <stdint.h>

#define OLED_8X16 8U

void OLED_Init(void);
void OLED_Update(void);
void OLED_Clear(void);

/* Supported conversions: %s, %c, %u, %lu, %d and %ld. */
void OLED_Printf(int16_t x, int16_t y, uint8_t font_size,
                 const char *format, ...);

#endif
