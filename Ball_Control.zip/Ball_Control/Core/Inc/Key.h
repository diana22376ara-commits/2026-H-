#ifndef __KEY_H
#define __KEY_H

#include <stdint.h>

typedef enum
{
  KEY_NONE = 0,
  KEY_BACK = 1,       /* Key1, PB15 */
  KEY_CONFIRM = 2,    /* Key2, PB14 */
  KEY_NEXT = 3,       /* Key3, PB13 */
  KEY_PREVIOUS = 4    /* Key4, PA1 */
} KeyCode_t;

KeyCode_t Key_GetNum(void);
KeyCode_t Key_GetState(void);
void Key_Tick(void);

#endif
