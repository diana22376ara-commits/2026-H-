#ifndef __D36A_H
#define __D36A_H

#include "main.h"
#include <stdint.h>

#define D36A_TIMER_HZ                 1000000UL
#define D36A_MIN_PULSE_HZ             100UL
#define D36A_MAX_PULSE_HZ           20000UL
#define D36A_DIR_SETUP_US               1UL
#define D36A_WAKE_DELAY_MS              1UL
#define D36A_COMMAND_TIMEOUT_MARGIN_MS 100UL

typedef enum
{
  D36A_STATE_IDLE = 0,
  D36A_STATE_DIR_SETUP_MOVE,
  D36A_STATE_MOVING,
  D36A_STATE_DIR_SETUP_OUTBOUND,
  D36A_STATE_OUTBOUND,
  D36A_STATE_DIR_SETUP_RETURN,
  D36A_STATE_RETURNING
} D36A_State_t;

typedef enum
{
  D36A_EVENT_NONE = 0,
  D36A_EVENT_MOTION_DONE,
  D36A_EVENT_ABORTED,
  D36A_EVENT_ERROR
} D36A_Event_t;

/* Physical D36A DIP positions: 1 means the switch is toward the ON mark. */
typedef struct
{
  uint8_t sw1_on;
  uint8_t sw2_on;
  uint8_t sw3_on;
} D36A_DipSwitch_t;

void D36A_Init(void);
void D36A_Task(void);
void D36A_Enable(uint8_t enable);
uint8_t D36A_IsEnabled(void);
uint8_t D36A_SetDirection(int8_t direction);
uint8_t D36A_IsBusy(void);
D36A_State_t D36A_GetState(void);

uint8_t D36A_SetMicrostep(uint32_t pulses_per_revolution);
uint32_t D36A_GetMicrostep(void);
uint8_t D36A_GetDipSwitch(D36A_DipSwitch_t *setting);
uint8_t D36A_SetPulseFrequency(uint32_t pulse_hz);
uint32_t D36A_GetPulseFrequency(void);
uint8_t D36A_SetSpeedRpm(float rpm);
float D36A_GetSpeedRpm(void);

uint32_t D36A_AngleToPulses(float angle_degrees);
float D36A_PulsesToAngle(uint32_t pulses);

uint8_t D36A_MovePulses(int8_t direction, uint32_t pulses);
uint8_t D36A_MoveAngle(float angle_degrees);
uint8_t D36A_StartImpulse(int8_t direction, uint32_t pulses);
void D36A_Abort(void);
D36A_Event_t D36A_TakeEvent(void);
int32_t D36A_GetCommandedPositionPulses(void);
uint8_t D36A_SetCurrentPositionAsZero(void);

/* Called directly from TIM2_IRQHandler for deterministic pulse timing. */
void D36A_TimerIRQHandler(void);

#endif
