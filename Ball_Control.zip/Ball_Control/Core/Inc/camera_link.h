#ifndef __CAMERA_LINK_H
#define __CAMERA_LINK_H

#include "main.h"
#include <stdint.h>

typedef struct
{
  /* Camera coordinates are downward-positive for both position and velocity:
     below target / moving downward is positive, above / upward is negative. */
  int32_t location_milli_cm;
  int32_t velocity_milli_cm_s;
  uint32_t timestamp_ms;
  uint8_t has_velocity;
} CameraLocationSample_t;

typedef enum
{
  CAMERA_STREAM_STOPPED = 0,
  CAMERA_STREAM_POSITION,
  CAMERA_STREAM_PURE_INIT
} CameraStreamMode_t;

void CameraLink_Init(void);
HAL_StatusTypeDef CameraLink_StartStream(void);
HAL_StatusTypeDef CameraLink_SendPureInit(void);
HAL_StatusTypeDef CameraLink_StopStream(void);
uint8_t CameraLink_IsStreaming(void);
uint8_t CameraLink_PopLocation(CameraLocationSample_t *sample);
void CameraLink_DiscardPending(void);
uint32_t CameraLink_GetInvalidLineCount(void);
uint32_t CameraLink_GetDroppedEventCount(void);

#endif
