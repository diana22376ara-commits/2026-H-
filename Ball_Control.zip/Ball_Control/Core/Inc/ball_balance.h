#ifndef __BALL_BALANCE_H
#define __BALL_BALANCE_H

#include "camera_link.h"
#include <stdint.h>

#define BALL_BALANCE_DEFAULT_POSITION_KP             0.35f
#define BALL_BALANCE_DEFAULT_POSITION_KI             0.00f
#define BALL_BALANCE_DEFAULT_VELOCITY_DAMPING_GAIN   0.30f
#define BALL_BALANCE_DEFAULT_VELOCITY_FILTER_ALPHA   0.25f
#define BALL_BALANCE_DEFAULT_OBSERVER_ALPHA           0.20f
#define BALL_BALANCE_DEFAULT_OBSERVER_BETA            0.02f
#define BALL_BALANCE_DEFAULT_MAX_ANGLE_DEG            1.5f
#define BALL_BALANCE_DEFAULT_POSITIVE_PULSES_PER_DEG 40.18f
#define BALL_BALANCE_DEFAULT_NEGATIVE_PULSES_PER_DEG 40.93f
#define BALL_BALANCE_DEFAULT_PULSE_HZ              2000UL
#define BALL_BALANCE_DEFAULT_SAMPLE_TIMEOUT_MS      100UL
#define BALL_BALANCE_DEFAULT_ACTUATOR_CHUNK_PULSES   10UL
#define BALL_BALANCE_DEFAULT_TEST_PULSES             100UL
/* The measured linkage moves the beam in the opposite direction to the
   D36A logical pulse sign.  Keep this inversion local to closed-loop control
   so calibration, manual motion and Preset Run retain their established axes. */
#define BALL_BALANCE_CLOSED_LOOP_MOTOR_POLARITY      (-1.0f)

typedef enum
{
  BALANCE_STATE_STOPPED = 0,
  BALANCE_STATE_ACQUIRE,
  BALANCE_STATE_ACTIVE,
  BALANCE_STATE_LOST,
  BALANCE_STATE_FAULT
} BalanceState_t;

typedef enum
{
  BALANCE_CONTROL_POSITION_DAMPING = 0,
  BALANCE_CONTROL_VELOCITY_ZERO
} BalanceControlMode_t;

typedef struct
{
  float position_kp;
  float position_ki;
  float velocity_damping_gain;
  float velocity_filter_alpha;
  float observer_alpha;
  float observer_beta;
  float max_angle_deg;
  float positive_pulses_per_beam_degree;
  float negative_pulses_per_beam_degree;
  uint32_t pulse_hz;
  uint32_t sample_timeout_ms;
  uint32_t actuator_chunk_pulses;
  uint32_t test_pulses;
} BalanceConfig_t;

typedef struct
{
  uint32_t received_locations;
  uint32_t control_updates;
  uint32_t estimator_resyncs;
  float measured_location_cm;
  float location_cm;
  float velocity_cm_s;
  float position_output_deg;
  float velocity_damping_output_deg;
  float angle_command_deg;
  int32_t reference_motor_pulses;
  int32_t target_motor_pulses;
  uint8_t hold_active;
  uint8_t camera_velocity_active;
} BalanceStats_t;

void BallBalance_Init(void);
void BallBalance_Task(void);
uint8_t BallBalance_Start(void);
uint8_t BallBalance_StartVelocityZeroTest(void);
void BallBalance_Stop(void);
void BallBalance_ClearFault(void);
uint8_t BallBalance_IsRunning(void);
BalanceState_t BallBalance_GetState(void);
const BalanceConfig_t *BallBalance_GetConfig(void);
const BalanceStats_t *BallBalance_GetStats(void);
uint8_t BallBalance_SetConfig(const BalanceConfig_t *new_config);

#endif
