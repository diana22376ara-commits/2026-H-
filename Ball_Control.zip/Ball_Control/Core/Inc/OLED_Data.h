#ifndef OLED_DATA_H
#define OLED_DATA_H

#include <stdint.h>

/* Printable ASCII characters 0x20 through 0x7E, 8 x 16 pixels each. */
extern const uint8_t OLED_F8x16[95][16];

#endif
