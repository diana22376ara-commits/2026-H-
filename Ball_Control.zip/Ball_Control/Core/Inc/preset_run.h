#ifndef __PRESET_RUN_H
#define __PRESET_RUN_H

#include <stdint.h>

#define PRESET_RUN_STEP_COUNT 4U
#define PRESET_RUN_PULSE_GROUP_COUNT 2U
#define PRESET_RUN_PULSE_GROUP_STEP1 0U
#define PRESET_RUN_PULSE_GROUP_STEP23 1U

typedef enum
{
  PRESET_RUN_STATE_IDLE = 0,
  PRESET_RUN_STATE_MOVING,
  PRESET_RUN_STATE_INTERVAL,
  PRESET_RUN_STATE_COMPLETE,
  PRESET_RUN_STATE_FAULT
} PresetRunState_t;

typedef struct
{
  uint32_t pulse_hz;
  uint32_t interval_ms;
} PresetRunStepConfig_t;

typedef struct
{
  uint32_t pulse_group[PRESET_RUN_PULSE_GROUP_COUNT];
  PresetRunStepConfig_t step[PRESET_RUN_STEP_COUNT];
  int32_t target_offset_pulses;
  uint8_t target_offset_valid;
} PresetRunConfig_t;

void PresetRun_Init(void);
uint8_t PresetRun_Start(void);
void PresetRun_Stop(void);
void PresetRun_ClearFault(void);
void PresetRun_Task(void);

uint8_t PresetRun_IsRunning(void);
PresetRunState_t PresetRun_GetState(void);
const PresetRunConfig_t *PresetRun_GetConfig(void);
uint8_t PresetRun_GetCurrentStep(void);
uint32_t PresetRun_GetStepPulses(uint8_t step_index);
uint32_t PresetRun_GetElapsedMs(void);

uint8_t PresetRun_SetPulseGroup(uint8_t group_index, uint32_t pulses);
uint8_t PresetRun_SetStepFrequency(uint8_t step_index, uint32_t pulse_hz);
uint8_t PresetRun_SetStepInterval(uint8_t step_index, uint32_t interval_ms);
uint8_t PresetRun_SetTargetOffsetPulses(int32_t offset_pulses,
                                        uint8_t valid);

#endif
