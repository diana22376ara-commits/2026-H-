#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

void Error_Handler(void);

/* Board status LED (Blue Pill: active low). */
#define STATUS_LED_Pin              GPIO_PIN_13
#define STATUS_LED_GPIO_Port        GPIOC

/* D36A channel-1 direct logic interface (ST/DIR/EN). */
#define D36A_ST_Pin                 GPIO_PIN_15  /* TIM2_CH1, partial remap 1 */
#define D36A_ST_GPIO_Port           GPIOA
#define D36A_DIR_Pin                GPIO_PIN_10
#define D36A_DIR_GPIO_Port          GPIOB
#define D36A_EN_Pin                 GPIO_PIN_11
#define D36A_EN_GPIO_Port           GPIOB

/* Camera UART: USART1 default mapping. */
#define CAMERA_TX_Pin               GPIO_PIN_9
#define CAMERA_TX_GPIO_Port         GPIOA
#define CAMERA_RX_Pin               GPIO_PIN_10
#define CAMERA_RX_GPIO_Port         GPIOA

/* Existing 0.96-inch OLED software-I2C connection. */
#define OLED_SCL_Pin                GPIO_PIN_8
#define OLED_SCL_GPIO_Port          GPIOB
#define OLED_SDA_Pin                GPIO_PIN_9
#define OLED_SDA_GPIO_Port          GPIOB

/* Four menu keys, active low with internal pull-ups. */
#define KEY_BACK_Pin                GPIO_PIN_15
#define KEY_BACK_GPIO_Port          GPIOB
#define KEY_CONFIRM_Pin             GPIO_PIN_14
#define KEY_CONFIRM_GPIO_Port       GPIOB
#define KEY_NEXT_Pin                GPIO_PIN_13
#define KEY_NEXT_GPIO_Port          GPIOB
#define KEY_PREVIOUS_Pin            GPIO_PIN_1
#define KEY_PREVIOUS_GPIO_Port      GPIOA

#ifdef __cplusplus
}
#endif

#endif
