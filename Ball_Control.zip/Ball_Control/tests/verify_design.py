"""Offline invariants for the D36A/ball-balance source and project."""

from pathlib import Path
import math
import re
import xml.etree.ElementTree as ET

PULSES_PER_REV = 3200
TEST_PULSES = 100
PULSE_HZ = 2000
MOTOR_DEFAULT_PULSE_HZ = 1500
POSITION_KP = 0.35
POSITION_KI = 0.00
VELOCITY_DAMPING_GAIN = 0.30
VELOCITY_FILTER_ALPHA = 0.25
OBSERVER_ALPHA = 0.20
OBSERVER_BETA = 0.02
MAX_ANGLE_DEG = 1.5
MAX_ANGLE_SLEW_DEG_S = 15.0
CLOSED_LOOP_MOTOR_POLARITY = -1.0
POSITIVE_PULSES_PER_DEGREE = 40.18
NEGATIVE_PULSES_PER_DEGREE = 40.93
TRACK_PIVOT_DISTANCE_MM = 251.0
HORIZONTAL_HEIGHT_MM = 66.6
POSITIVE_100_HEIGHT_MM = 55.7
NEGATIVE_100_HEIGHT_MM = 77.3
SAMPLE_TIMEOUT_MS = 100
ACTUATOR_CHUNK_PULSES = 10
CALIBRATION_ZERO = -160
CALIBRATION_MINUS5 = -210
PRESET_TARGET_OFFSET = CALIBRATION_MINUS5 - CALIBRATION_ZERO
PRESET_STEP1_PULSES = 130
PRESET_STEP23_PULSES = 260
PRESET_STEP4_PULSES = PRESET_STEP1_PULSES - PRESET_TARGET_OFFSET
PRESET_PULSES = (PRESET_STEP1_PULSES, PRESET_STEP23_PULSES,
                 PRESET_STEP23_PULSES, PRESET_STEP4_PULSES)
PRESET_PULSE_HZ = (1000, 1000, 1000, 1000)
PRESET_INTERVAL_MS = (250, 650, 200, 1000)
PRESET_DIRECTIONS = (1, -1, 1, -1)
DIR_SETUP_US = 1
WAKE_DELAY_MS = 1
MAX_PULSE_HZ = 20_000
CAMERA_FPS = 100
CAMERA_LINE_SIZE = 64
CAMERA_QUEUE_SIZE = 32
CAMERA_BAUD = 115_200
CAMERA_MAX_LINE_BYTES = len(
    "V:-123.456cm/s,LOCATION:-123.456\r\n")

# Physical switch positions: 1 means toward the D36A DIP block's ON mark.
SUPPORTED_MICROSTEPS = {
    200: (1, 1, 1),
    400: (0, 1, 1),
    800: (0, 1, 0),
    1600: (1, 0, 0),
    3200: (0, 0, 0),
    6400: (1, 0, 1),
}

ROOT = Path(__file__).resolve().parents[1]


def verify_project_files() -> None:
    project_path = ROOT / "MDK-ARM" / "SmartCar.uvprojx"
    tree = ET.parse(project_path)
    target_names = [node.text for node in tree.findall(".//TargetName")]
    assert "BallBalance" in target_names

    source_names = []
    for node in tree.findall(".//FilePath"):
        file_path = (project_path.parent / node.text.replace("\\", "/")).resolve()
        assert file_path.exists(), f"project path missing: {file_path}"
        source_names.append(file_path.name.lower())

    for required in (
        "d36a.c", "camera_link.c", "ball_balance.c", "preset_run.c",
        "menu.c", "menu_data.c"
    ):
        assert required in source_names
    assert "dm430.c" not in source_names
    for removed in ("speed.c", "pid.c", "gps.c", "mpu6050.c", "myi2c.c"):
        assert removed not in source_names

    cmsis_root = ROOT / "Drivers" / "CMSIS"
    assert (cmsis_root / "Include" / "core_cm3.h").exists()
    assert (cmsis_root / "Device" / "ST" / "STM32F1xx" / "Include" /
            "stm32f103xb.h").exists()
    for unused_package in (
        "Core", "Core_A", "docs", "DSP", "Lib", "NN", "RTOS", "RTOS2"
    ):
        assert not (cmsis_root / unused_package).exists()


def verify_source_contracts() -> None:
    main_h = (ROOT / "Core" / "Inc" / "main.h").read_text(encoding="utf-8")
    expected_pin_lines = (
        "#define D36A_ST_Pin                 GPIO_PIN_15",
        "#define D36A_DIR_Pin                GPIO_PIN_10",
        "#define D36A_EN_Pin                 GPIO_PIN_11",
        "#define CAMERA_TX_Pin               GPIO_PIN_9",
        "#define CAMERA_RX_Pin               GPIO_PIN_10",
        "#define OLED_SCL_Pin                GPIO_PIN_8",
        "#define OLED_SDA_Pin                GPIO_PIN_9",
        "#define KEY_BACK_Pin                GPIO_PIN_15",
        "#define KEY_CONFIRM_Pin             GPIO_PIN_14",
        "#define KEY_NEXT_Pin                GPIO_PIN_13",
        "#define KEY_PREVIOUS_Pin            GPIO_PIN_1",
        "#define KEY_PREVIOUS_GPIO_Port      GPIOA",
    )
    for expected in expected_pin_lines:
        assert expected in main_h

    d36a_h = (ROOT / "Core" / "Inc" / "d36a.h").read_text(encoding="utf-8")
    d36a_c = (ROOT / "Core" / "Src" / "d36a.c").read_text(encoding="utf-8")
    gpio_c = (ROOT / "Core" / "Src" / "gpio.c").read_text(encoding="utf-8")
    irq_c = (ROOT / "Core" / "Src" / "stm32f1xx_it.c").read_text(encoding="utf-8")

    assert re.search(r"D36A_MAX_PULSE_HZ\s+20000UL", d36a_h)
    assert re.search(r"D36A_DIR_SETUP_US\s+1UL", d36a_h)
    assert re.search(r"D36A_WAKE_DELAY_MS\s+1UL", d36a_h)
    assert re.search(r"D36A_COMMAND_TIMEOUT_MARGIN_MS\s+100UL", d36a_h)
    assert "void D36A_Task(void);" in d36a_h
    assert "requested ? GPIO_PIN_SET : GPIO_PIN_RESET" in d36a_c
    assert "HAL_Delay(D36A_WAKE_DELAY_MS);" in d36a_c
    assert "TIM2->ARR = D36A_DIR_SETUP_US;" in d36a_c
    assert "D36A_DIR_SETUP_US - 1UL" not in d36a_c
    setup_timer = d36a_c[d36a_c.index("static void D36A_TimerStartDirectionSetup"):
                          d36a_c.index("static uint32_t D36A_GetCommandTimeoutMs")]
    assert setup_timer.index("TIM2->EGR = TIM_EGR_UG;") < \
           setup_timer.index("TIM2->CNT = 1U;")
    assert "void D36A_Task(void)" in d36a_c
    assert "motor.event = D36A_EVENT_ERROR;" in d36a_c
    assert "motor.command_deadline = HAL_GetTick()" in d36a_c
    init_body = d36a_c[d36a_c.index("void D36A_Init(void)"):
                        d36a_c.index("void D36A_Task(void)")]
    assert "motor.pulses_per_revolution = 3200UL;" in init_body
    assert "motor.pulse_hz = 1500UL;" in init_body
    assert "D36A_Enable(1U);" in init_body
    assert "motor.remaining_pulses = motor.command_pulses;" in d36a_c
    assert "uint8_t D36A_SetSpeedRpm(float rpm)" in d36a_c
    assert "float D36A_GetSpeedRpm(void)" in d36a_c
    assert "rpm * (float)motor.pulses_per_revolution" in d36a_c
    assert "uint8_t D36A_SetCurrentPositionAsZero(void)" in d36a_c
    assert "motor.commanded_position = 0;" in d36a_c
    assert "HAL_GPIO_WritePin(D36A_EN_GPIO_Port, D36A_EN_Pin, GPIO_PIN_RESET);" in gpio_c
    assert "gpio.Pin = KEY_PREVIOUS_Pin;" in gpio_c
    assert "HAL_GPIO_Init(KEY_PREVIOUS_GPIO_Port, &gpio);" in gpio_c
    assert "D36A_EN_GPIO_Port->BRR = D36A_EN_Pin;" in irq_c

    for ppr, dip in SUPPORTED_MICROSTEPS.items():
        values = ", ".join(f"{value}U" for value in dip)
        pattern = rf"\{{\s*{ppr}UL,\s*\{{{re.escape(values)}\}}\}}"
        assert re.search(pattern, d36a_c), f"missing D36A DIP entry for {ppr} ppr"

    camera_c = (ROOT / "Core" / "Src" / "camera_link.c").read_text(encoding="utf-8")
    for protocol_token in ('"Start\\r\\n"', '"Stop\\r\\n"', '"Init\\r\\n"',
                           '"Location"', '"LOCATION"'):
        assert protocol_token in camera_c
    for removed_token in ('"UP"', '"DOWN"', '"CENTER"'):
        assert removed_token not in camera_c
    assert "CameraLink_ParseFixedMilliCm" in camera_c
    assert "location_milli_cm" in camera_c
    assert "velocity_milli_cm_s" in camera_c
    assert "has_velocity" in camera_c
    assert '"cm/s,LOCATION:"' in camera_c
    assert "length >= 18U" in camera_c
    assert "timestamp_ms = HAL_GetTick();" in camera_c
    assert "0xEFU" in camera_c and "0xBCU" in camera_c and "0x9AU" in camera_c
    assert "void CameraLink_DiscardPending(void)" in camera_c
    assert "HAL_StatusTypeDef CameraLink_SendPureInit(void)" in camera_c
    assert "stream_mode != CAMERA_STREAM_POSITION" in camera_c
    assert "stream_mode = CAMERA_STREAM_PURE_INIT;" in camera_c
    assert re.search(r"CAMERA_LINE_SIZE\s+64U", camera_c)
    assert re.search(r"CAMERA_QUEUE_SIZE\s+32U", camera_c)

    balance_c = (ROOT / "Core" / "Src" / "ball_balance.c").read_text(encoding="utf-8")
    balance_h = (ROOT / "Core" / "Inc" / "ball_balance.h").read_text(encoding="utf-8")
    assert re.search(r"BALL_BALANCE_DEFAULT_POSITION_KP\s+0.35f", balance_h)
    assert re.search(
        r"BALL_BALANCE_DEFAULT_VELOCITY_DAMPING_GAIN\s+0.30f", balance_h)
    assert re.search(
        r"BALL_BALANCE_DEFAULT_VELOCITY_FILTER_ALPHA\s+0.25f", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_OBSERVER_ALPHA\s+0.20f", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_OBSERVER_BETA\s+0.02f", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_MAX_ANGLE_DEG\s+1.5f", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_POSITIVE_PULSES_PER_DEG\s+40.18f", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_NEGATIVE_PULSES_PER_DEG\s+40.93f", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_PULSE_HZ\s+2000UL", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_SAMPLE_TIMEOUT_MS\s+100UL", balance_h)
    assert re.search(r"BALL_BALANCE_DEFAULT_ACTUATOR_CHUNK_PULSES\s+10UL", balance_h)
    assert re.search(
        r"BALL_BALANCE_CLOSED_LOOP_MOTOR_POLARITY\s+\(-1.0f\)", balance_h)
    for active_state in ("BALANCE_STATE_ACQUIRE", "BALANCE_STATE_ACTIVE",
                         "BALANCE_STATE_LOST"):
        assert active_state in balance_h
    assert "CameraLink_PopLocation(&sample)" in balance_c
    assert "raw_velocity_cm_s = (location_cm - last_measurement_cm) / dt_s;" in balance_c
    assert "predicted_location_cm = estimated_location_cm" in balance_c
    assert "config.observer_alpha * position_residual_cm" in balance_c
    assert "config.observer_beta / dt_s" in balance_c
    assert "config.velocity_filter_alpha *" in balance_c
    assert "camera_velocity_cm_s - filtered_velocity_cm_s" in balance_c
    assert "sample->has_velocity" in balance_c
    assert "position_integral = 0.0f;" in balance_c
    assert "BALANCE_HOLD_ENTER_POSITION_CM" in balance_c
    assert "BALANCE_POSITION_PRIORITY_ZONE_CM" not in balance_c
    assert "position_guard_active" not in balance_c
    assert re.search(r"BALANCE_MAX_ANGLE_SLEW_DEG_S\s+15.00f", balance_c)
    assert "previous_angle_command_deg - maximum_angle_change" in balance_c
    assert "config.position_kp * position_error" in balance_c
    assert "config.position_ki * position_integral" in balance_c
    assert "config.velocity_damping_gain * filtered_velocity_cm_s" in balance_c
    assert "angle_unsaturated = position_output + velocity_damping_output;" in balance_c
    assert "BALANCE_CONTROL_VELOCITY_ZERO" in balance_c
    assert "BALANCE_CONTROL_POSITION_DAMPING" in balance_c
    assert "position_output = 0.0f;" in balance_c
    assert "BallBalance_StartVelocityZeroTest" in balance_c
    assert "target_motor_pulses = reference_motor_pulses + angle_offset_pulses;" in balance_c
    assert "BALL_BALANCE_CLOSED_LOOP_MOTOR_POLARITY * angle_command" in balance_c
    assert "config.positive_pulses_per_beam_degree" in balance_c
    assert "config.negative_pulses_per_beam_degree" in balance_c
    assert "pulses > config.actuator_chunk_pulses" in balance_c
    assert re.search(r"BALANCE_ACTUATOR_CHUNK_MAX_US\s+10000UL", balance_c)
    assert "while (D36A_IsBusy())" in balance_c
    assert "event != D36A_EVENT_MOTION_DONE" in balance_c
    assert "new_config->actuator_chunk_pulses * 1000000ULL" in balance_c
    assert "HAL_GetTick() - last_received_tick_ms" in balance_c
    assert "last_received_tick_ms = sample->timestamp_ms;" in balance_c
    assert "state = BALANCE_STATE_LOST;" in balance_c
    assert balance_c.count("CameraLink_StartStream()") == 1
    assert "config.pulse_hz = BALL_BALANCE_DEFAULT_PULSE_HZ;" in balance_c
    assert "config.actuator_chunk_pulses" in balance_c
    assert "BallBalance_Clamp" in balance_c
    assert "position_integral_limit" in balance_c
    assert re.search(r"BALANCE_MAX_RELATIVE_PULSES\s+5000.0f", balance_c)
    assert "new_config->max_angle_deg *" in balance_c
    clear_fault = balance_c[balance_c.index("void BallBalance_ClearFault(void)"):
                            balance_c.index("void BallBalance_Task(void)")]
    assert "D36A_Enable(1U);" in clear_fault
    balance_start = balance_c[balance_c.index("static uint8_t BallBalance_StartMode"):
                              balance_c.index("void BallBalance_Stop(void)")]
    assert "D36A_SetPulseFrequency(config.pulse_hz)" in balance_start
    balance_stop = balance_c[balance_c.index("void BallBalance_Stop(void)"):
                             balance_c.index("void BallBalance_ClearFault(void)")]
    assert "if (state == BALANCE_STATE_FAULT)" in balance_stop
    assert "D36A_Enable(1U);" in balance_stop
    assert "D36A_Enable(0U);" not in balance_stop

    preset_c = (ROOT / "Core" / "Src" / "preset_run.c").read_text(encoding="utf-8")
    main_c = (ROOT / "Core" / "Src" / "main.c").read_text(encoding="utf-8")
    assert re.search(r"PRESET_RUN_DOWN_FIRST_DIRECTION\s+1", preset_c)
    assert "config.pulse_group[PRESET_RUN_PULSE_GROUP_STEP1] = 130UL;" in preset_c
    assert "config.pulse_group[PRESET_RUN_PULSE_GROUP_STEP23] = 260UL;" in preset_c
    assert "config.step[i].pulse_hz = 1000UL;" in preset_c
    assert "config.step[0U].interval_ms = 250UL;" in preset_c
    assert "config.step[1U].interval_ms = 650UL;" in preset_c
    assert "config.step[2U].interval_ms = 200UL;" in preset_c
    assert "config.step[3U].interval_ms = 1000UL;" in preset_c
    assert "config.target_offset_valid = 0U;" in preset_c
    assert "PRESET_RUN_STATE_MOVING" in preset_c
    assert "PRESET_RUN_STATE_INTERVAL" in preset_c
    assert "PresetRun_GetStepPulses(current_step)" in preset_c
    assert "config.step[current_step].interval_ms" in preset_c
    assert "PresetRun_PulseGroupForStep(uint8_t step_index)" in preset_c
    assert "config.pulse_group[PresetRun_PulseGroupForStep(step_index)]" in preset_c
    assert "config.pulse_group[PRESET_RUN_PULSE_GROUP_STEP1]" in preset_c
    assert "(int64_t)config.target_offset_pulses" in preset_c
    assert "!config.target_offset_valid" in preset_c
    assert "PresetRun_SetTargetOffsetPulses" in preset_c
    assert "++current_step;" in preset_c
    assert "saved_motor_pulse_hz = D36A_GetPulseFrequency();" in preset_c
    assert "D36A_SetPulseFrequency(saved_motor_pulse_hz)" in preset_c
    assert "run_start_tick = HAL_GetTick();" in preset_c
    assert "run_elapsed_ms = HAL_GetTick() - run_start_tick;" in preset_c
    assert "uint32_t PresetRun_GetElapsedMs(void)" in preset_c
    assert "BallBalance" not in preset_c
    assert "CameraLink" not in preset_c
    assert "PresetRun_Init();" in main_c
    assert "Menu_Task();" in main_c
    preset_stop = preset_c[preset_c.index("void PresetRun_Stop(void)"):
                           preset_c.index("void PresetRun_ClearFault(void)")]
    assert "D36A_Enable(1U);" in preset_stop
    assert "D36A_Enable(0U);" not in preset_stop

    key_h = (ROOT / "Core" / "Inc" / "Key.h").read_text(encoding="utf-8")
    key_c = (ROOT / "Core" / "Src" / "Key.c").read_text(encoding="utf-8")
    menu_h = (ROOT / "menu" / "menu.h").read_text(encoding="utf-8")
    menu_c = (ROOT / "menu" / "menu.c").read_text(encoding="utf-8")
    menu_data_c = (ROOT / "menu" / "menu_data.c").read_text(encoding="utf-8")
    oled_c = (ROOT / "Core" / "Src" / "OLED.c").read_text(encoding="utf-8")
    oled_data_c = (ROOT / "Core" / "Src" / "OLED_Data.c").read_text(
        encoding="utf-8")

    # The display path must stay independent of the large stdio formatter.
    assert "#include <stdio.h>" not in oled_c
    assert "#include <stdio.h>" not in menu_data_c
    for forbidden in ("sprintf(", "snprintf(", "vsprintf(", "vsnprintf("):
        assert forbidden not in oled_c
        assert forbidden not in menu_data_c
    assert "OLED_TEXT_BUFFER_SIZE 64U" in oled_c
    assert "OLED_F8x16[95][16]" in (
        ROOT / "Core" / "Inc" / "OLED_Data.h").read_text(encoding="utf-8")
    for removed_asset in ("OLED_F6x8", "OLED_CF16x16", "Diode"):
        assert removed_asset not in oled_data_c

    supported_oled_conversions = {"s", "c", "u", "d", "%"}
    for source in (menu_c, menu_data_c):
        formats = re.findall(
            r'OLED_Printf\([^;]*?"((?:\\.|[^"\\])*)"', source, re.S)
        assert formats
        for format_text in formats:
            conversions = re.findall(r'%(?:0\d+)?l?([A-Za-z%])', format_text)
            assert set(conversions) <= supported_oled_conversions, format_text
    for key_contract in (
        "KEY_BACK = 1", "KEY_CONFIRM = 2", "KEY_NEXT = 3",
        "KEY_PREVIOUS = 4"
    ):
        assert key_contract in key_h
    for key_pin in (
        "KEY_BACK_GPIO_Port, KEY_BACK_Pin",
        "KEY_CONFIRM_GPIO_Port, KEY_CONFIRM_Pin",
        "KEY_NEXT_GPIO_Port, KEY_NEXT_Pin",
        "KEY_PREVIOUS_GPIO_Port, KEY_PREVIOUS_Pin",
    ):
        assert key_pin in key_c
    assert re.search(r"KEY_SCAN_PERIOD_MS\s+5U", key_c)
    assert re.search(r"KEY_DEBOUNCE_SAMPLES\s+4U", key_c)
    assert "key_number == KEY_NONE" in key_c
    # Menu framework matches the previous gimbal project's Option_Class model,
    # while keeping the four-key mapping and servicing background state machines.
    assert "struct Option_Class" in menu_h
    assert "void Menu_RunMenu(struct Option_Class *Option_List);" in menu_h
    assert "void Menu_RunMainMenu(void);" in menu_h
    assert re.search(r"MENU_VISIBLE_ROWS\s+4U", menu_c)
    assert "int8_t Menu_RollEvent(void)" in menu_c
    assert "return Menu_MatchEvent(KEY_NEXT);" in menu_c
    assert "int8_t Menu_PreviousEvent(void)" in menu_c
    assert "return Menu_MatchEvent(KEY_PREVIOUS);" in menu_c
    assert "selected - (MENU_VISIBLE_ROWS - 1U)" in menu_c
    assert "Menu_DrawOptions(Option_List, selected, first, last);" in menu_c
    assert "BallBalance_Task();" in menu_c
    assert "PresetRun_Task();" in menu_c
    assert menu_c.index("D36A_Task();") < menu_c.index("BallBalance_Task();")

    for main_option in (
        '{"Balance", Balance_Control}',
        '{"Balance Ref", Balance_Reference_Control}',
        '{"Preset Run", Preset_Menu}',
        '{"Tune", Tune_Menu}',
        '{"Motor", Motor_Menu}',
        '{"Pure Stream", Pure_Stream_Control}',
    ):
        assert main_option in menu_data_c
    for removed_page in (
        'Status_Control',
        'Motor_Enable_Control',
        'Motor_Microstep_Control',
    ):
        assert removed_page not in menu_data_c
        assert removed_page not in menu_h
    assert menu_data_c.count('{".."}') >= 9
    assert "Motor_StartCycle(1);" in menu_data_c
    assert "Motor_StartCycle(-1);" in menu_data_c
    assert "D36A_StartImpulse(first_direction" in menu_data_c
    assert "return PresetRun_Start();" in menu_data_c
    preset_start = menu_data_c.rindex(
        "static uint8_t Preset_StartFromZero(void)")
    preset_control = menu_data_c[
        preset_start:menu_data_c.index("static void Preset_Adjust(",
                                      preset_start)]
    assert "BallBalance_Start()" not in preset_control
    assert "BallBalance_" not in preset_control
    assert "CameraLink_" not in preset_control
    assert "handoff_attempted" not in preset_control
    assert '"+-+ ->-5 LOCK"' in preset_control
    assert '"Time:%lu.%01lus"' in preset_control
    assert "PresetRun_GetElapsedMs()" in preset_control
    for step_item in ('{"Step1 +", Preset_Step1_Menu}',
                      '{"Step2 -", Preset_Step2_Menu}',
                      '{"Step3 +", Preset_Step3_Menu}',
                      '{"Step4 -5cm", Preset_Step4_Menu}'):
        assert step_item in menu_data_c
    for parameter_item in ('{"Pulses", Preset_Pulses_Control}',
                           '{"Frequency", Preset_Frequency_Control}',
                           '{"Interval", Preset_Interval_Control}'):
        assert parameter_item in menu_data_c
    assert '{"Cal 0cm", Motor_Calibrate}' in menu_data_c
    assert '{"Cal -5cm", Motor_CalibrateMinus5}' in menu_data_c
    assert '{"Cal Camera", Motor_CalibrateCamera}' in menu_data_c
    assert "Balance_ControlAtPoint(&calibration_zero_pulses" in menu_data_c
    assert "Balance_ControlAtPoint(&calibration_camera_pulses" in menu_data_c
    assert '{"Velocity Test", Tune_VelocityZeroTest}' in menu_data_c
    assert "BallBalance_StartVelocityZeroTest();" in menu_data_c
    assert '"Vel Zero", 1U' in menu_data_c
    assert '"V:%s D:%s"' in menu_data_c
    assert "BallBalance_GetConfig()" in menu_data_c
    assert "BallBalance_GetConfig()->test_pulses" in menu_data_c
    for pid_menu in ('{"Position Ctrl", Tune_Position_Menu}',
                     '{"Speed Damping", Tune_Velocity_Menu}',
                     '{"Estimator", Tune_Estimator_Menu}',
                     '{"Actuator", Tune_Actuator_Menu}'):
        assert pid_menu in menu_data_c
    for gain_item in ('{"Position Kp", Tune_PositionKp_Control}',
                      '{"Position Ki", Tune_PositionKi_Control}',
                      '{"Damping Gain", Tune_VelocityDamping_Control}',
                      '{"Velocity LPF", Tune_VelocityFilter_Control}'):
        assert gain_item in menu_data_c
    assert re.search(r"MENU_CALIBRATION_JOG_PULSES\s+1UL", menu_data_c)
    assert re.search(r"MENU_CALIBRATION_DEFAULT_PULSES\s+\(-160L\)", menu_data_c)
    assert re.search(r"TUNE_POSITION_KP_STEP\s+0.05f", menu_data_c)
    assert re.search(r"TUNE_DAMPING_GAIN_STEP\s+0.05f", menu_data_c)
    assert re.search(r"TUNE_VELOCITY_FILTER_STEP\s+0.05f", menu_data_c)
    assert re.search(r"TUNE_OBSERVER_ALPHA_STEP\s+0.05f", menu_data_c)
    assert re.search(r"TUNE_OBSERVER_BETA_STEP\s+0.01f", menu_data_c)
    assert re.search(r"TUNE_FREQ_STEP\s+50UL", menu_data_c)
    assert re.search(r"TUNE_PULSES_PER_DEGREE_STEP\s+1.0f", menu_data_c)
    assert re.search(r"PRESET_KICK_STEP\s+10UL", menu_data_c)
    assert re.search(r"PRESET_FREQ_STEP\s+50UL", menu_data_c)
    assert re.search(r"PRESET_INTERVAL_STEP\s+50UL", menu_data_c)
    assert "Calibration_StartJog(1);" in menu_data_c
    assert "Calibration_StartJog(-1);" in menu_data_c
    assert "Motor_CalibratePoint(&calibration_zero_pulses" in menu_data_c
    assert "Motor_CalibratePoint(&calibration_minus5_pulses" in menu_data_c
    assert "Motor_CalibratePoint(&calibration_camera_pulses" in menu_data_c
    assert "calibration_minus5_pulses - calibration_zero_pulses" in menu_data_c
    assert "PresetRun_SetTargetOffsetPulses(offset, valid)" in menu_data_c
    assert 'Calibration_MoveToAndWait(calibration_zero_pulses' in menu_data_c
    assert '"Return to 0cm"' in menu_data_c
    assert "((key == KEY_CONFIRM) || (key == KEY_BACK))" in menu_data_c
    assert "CALIBRATION_MOVE_CANCEL" not in menu_data_c
    assert "calibration_entry_" not in menu_data_c
    assert '"K1/K2:Save"' in menu_data_c
    assert "D36A_SetCurrentPositionAsZero()" not in menu_data_c
    assert "D36A_Enable(0U);" not in menu_data_c
    assert menu_data_c.count("if (D36A_IsBusy()) { continue; }") >= 1
    assert menu_data_c.count("else if (D36A_IsBusy())") >= 3
    assert menu_data_c.count("if (PresetRun_IsRunning()) { continue; }") >= 2
    assert "D36A_Enable(D36A_IsEnabled() ? 0U : 1U);" not in menu_data_c
    assert "static void Tune_Adjust(TuneItem_t item, int8_t direction)" in menu_data_c
    assert "Tune_Adjust(tune_menu_item, 1);" in menu_data_c
    assert "Tune_Adjust(tune_menu_item, -1);" in menu_data_c
    assert "BallBalance_SetConfig(&next)" in menu_data_c
    assert "static void Preset_Adjust(uint8_t step_index, PresetItem_t item," in menu_data_c
    assert "Preset_Adjust(preset_menu_step, item, 1);" in menu_data_c
    assert "Preset_Adjust(preset_menu_step, item, -1);" in menu_data_c
    assert "PresetRun_SetPulseGroup(group_index, value)" in menu_data_c
    assert "PresetRun_SetStepFrequency(step_index, value)" in menu_data_c
    assert "PresetRun_SetStepInterval(step_index, value)" in menu_data_c
    assert '"P4=P1-D K1"' in menu_data_c
    assert '"P2=P3 K1:Back"' in menu_data_c
    assert '"P1 Base K1:Back"' in menu_data_c
    assert '"Independent K1"' in menu_data_c
    assert "PresetRun_GetConfig()" in menu_data_c
    assert "if (key == KEY_NEXT)" in menu_data_c
    assert "CameraLink_SendPureInit()" in menu_data_c
    assert "(void)CameraLink_StopStream();" in menu_data_c
    assert "void Menu_OnMainPageReturn(void)" in menu_data_c
    assert 'Calibration_MoveToAndWait(calibration_zero_pulses' in menu_data_c
    assert "if (this_depth == 1U)" in menu_c
    assert "Menu_OnMainPageReturn();" in menu_c
    assert "static uint8_t menu_depth;" in menu_c
    assert "D36A_Enable(1U);" in menu_data_c
    assert "state == PRESET_RUN_STATE_INTERVAL" in preset_c
    assert "!D36A_IsEnabled()" in preset_c

    msp_c = (ROOT / "Core" / "Src" / "stm32f1xx_hal_msp.c").read_text(encoding="utf-8")
    tim_c = (ROOT / "Core" / "Src" / "tim.c").read_text(encoding="utf-8")
    assert "__HAL_AFIO_REMAP_TIM2_PARTIAL_1();" in tim_c
    assert "__HAL_AFIO_REMAP_SWJ_NOJTAG();" in msp_c
    assert tim_c.index("__HAL_AFIO_REMAP_TIM2_PARTIAL_1();") < \
           tim_c.index("__HAL_AFIO_REMAP_SWJ_NOJTAG();")
    assert "__HAL_AFIO_REMAP_SWJ_DISABLE" not in msp_c
    assert "htim2.Init.Period = 666U - 1U;" in tim_c

    application_files = list((ROOT / "Core").rglob("*.c"))
    application_files += list((ROOT / "Core").rglob("*.h"))
    application_files += list((ROOT / "menu").rglob("*.c"))
    init_command_occurrences = 0
    for path in application_files:
        source = path.read_text(encoding="utf-8")
        assert "DM430" not in source, f"stale DM430 reference: {path}"
        init_command_occurrences += source.count('"Init\\r\\n"')
    assert init_command_occurrences == 1, "Init command must have one source owner"


def verify_impulse_state_machine() -> None:
    state = "DIR_SETUP_OUTBOUND"
    direction = 1
    emitted_directions = []

    state = "OUTBOUND"
    emitted_directions.extend([direction] * TEST_PULSES)
    state = "DIR_SETUP_RETURN"
    direction = -direction
    state = "RETURNING"
    emitted_directions.extend([direction] * TEST_PULSES)
    state = "IDLE"

    assert state == "IDLE"
    assert emitted_directions.count(1) == TEST_PULSES
    assert emitted_directions.count(-1) == TEST_PULSES
    assert sum(emitted_directions) == 0


def verify_control_polarity() -> None:
    # Camera position and velocity share a downward-positive axis.  A ball
    # below target must receive an upward (negative) velocity/tilt command.
    below_target_location = 5.0
    position_error = -below_target_location
    position_output = POSITION_KP * position_error
    angle_command = position_output
    assert position_error < 0
    assert position_output < 0
    assert angle_command < 0
    motor_angle_command = CLOSED_LOOP_MOTOR_POLARITY * angle_command
    assert motor_angle_command > 0

    # A ball above target must receive a downward (positive) command.
    above_target_location = -5.0
    position_error = -above_target_location
    position_output = POSITION_KP * position_error
    angle_command = position_output
    assert position_error > 0
    assert position_output > 0
    assert angle_command > 0
    motor_angle_command = CLOSED_LOOP_MOTOR_POLARITY * angle_command
    assert motor_angle_command < 0

    # In velocity-zero mode the camera V is not inverted.  Downward-positive
    # motion receives a negative tilt; upward-negative motion receives positive.
    for camera_velocity in (4.0, -4.0):
        braking_angle = -VELOCITY_DAMPING_GAIN * camera_velocity
        assert braking_angle * camera_velocity < 0.0
        motor_angle_command = CLOSED_LOOP_MOTOR_POLARITY * braking_angle
        assert motor_angle_command * camera_velocity > 0.0

    # When the ball moves toward the target too fast, direct speed damping must
    # overpower the position term and command opposite acceleration immediately.
    # It must not wait for an arbitrary centre-zone boundary.
    for location, inward_velocity in ((5.0, -10.0), (-5.0, 10.0)):
        position_output = -POSITION_KP * location
        damping_output = -VELOCITY_DAMPING_GAIN * inward_velocity
        requested_angle = position_output + damping_output
        assert requested_angle * location > 0.0
        assert requested_angle != 0.0


def verify_direction_setup_timer() -> None:
    # At 1 MHz, ARR=0 blocks this STM32 timer. ARR=1/CNT=1 reaches update
    # on the next tick and therefore preserves the required 1 us setup time.
    arr = DIR_SETUP_US
    counter = 1
    assert arr != 0
    counter += 1
    update_event = counter > arr
    assert update_event


def verify_camera_control_cycle() -> None:
    state = "ACQUIRE"
    stream_commands = ["Start"]
    samples = [(0, 5.0, -9.5), (10, 4.9, -9.8), (20, 4.8, -10.0)]
    estimated_location = samples[0][1]
    velocity = samples[0][2]
    previous_timestamp = samples[0][0]
    for timestamp, location, camera_velocity in samples[1:]:
        dt = (timestamp - previous_timestamp) * 0.001
        velocity += VELOCITY_FILTER_ALPHA * (camera_velocity - velocity)
        predicted_location = estimated_location + velocity * dt
        residual = location - predicted_location
        estimated_location = predicted_location + OBSERVER_ALPHA * residual
        previous_timestamp = timestamp
        state = "ACTIVE"

    assert stream_commands == ["Start"]
    assert state == "ACTIVE"
    assert velocity < 0

    # A sample timeout commands zero nominal beam angle and the saved reference.
    elapsed_ms = SAMPLE_TIMEOUT_MS + 1
    if elapsed_ms > SAMPLE_TIMEOUT_MS:
        state = "LOST"
        target_offset = 0
    assert state == "LOST"
    assert target_offset == 0


def verify_camera_buffer_capacity() -> None:
    longest_line_before_lf = len(
        "V:-123.456cm/s,LOCATION:-123.456\r")
    usable_queue_entries = CAMERA_QUEUE_SIZE - 1

    assert CAMERA_LINE_SIZE >= longest_line_before_lf + 1  # trailing NUL
    assert usable_queue_entries == 31
    assert usable_queue_entries >= CAMERA_FPS * 300 // 1000


def verify_location_protocol_examples() -> None:
    def parse_milli_cm(frame: str) -> int:
        line = frame.removesuffix("\r\n")
        if line.startswith("Location:"):
            value = line[len("Location:"):]
        elif line.startswith("LOCATION:"):
            value = line[len("LOCATION:"):]
        elif line.startswith("Location："):
            value = line[len("Location："):]
        else:
            raise ValueError(frame)
        return int(float(value) * 1000.0)

    assert parse_milli_cm("Location:1.250000\r\n") == 1250
    assert parse_milli_cm("LOCATION:0.170000\r\n") == 170
    assert parse_milli_cm("Location:-0.375000\r\n") == -375
    assert parse_milli_cm("Location：+2.000000\r\n") == 2000

    def parse_combined(frame: str) -> tuple[int, int]:
        line = frame.removesuffix("\r\n").removesuffix("%")
        velocity_field, location_field = line.split(",", 1)
        if not velocity_field.startswith("V:") or \
                not velocity_field.endswith("cm/s"):
            raise ValueError(frame)
        if not location_field.startswith("LOCATION:"):
            raise ValueError(frame)
        velocity = velocity_field[2:-4]
        location = location_field[len("LOCATION:"):]
        return (int(float(velocity) * 1000.0),
                int(float(location) * 1000.0))

    assert parse_combined(
        "V:-3.250cm/s,LOCATION:4.750\r\n") == (-3250, 4750)
    assert parse_combined(
        "V:0.125cm/s,LOCATION:-0.500%\r\n") == (125, -500)
    assert parse_combined("V:0cm/s,LOCATION:0\r\n") == (0, 0)


def verify_latest_target_chunk_tracking() -> None:
    current = 0
    target = 200
    commands = []
    while current != target:
        delta = target - current
        chunk = min(abs(delta), ACTUATOR_CHUNK_PULSES)
        current += chunk if delta > 0 else -chunk
        commands.append(chunk)
        if len(commands) == 5:
            # New camera data supersedes the old target before its long move
            # has been fully emitted.
            target = -30
    assert max(commands) <= ACTUATOR_CHUNK_PULSES
    assert current == -30


def verify_calibrated_reference_cycle() -> None:
    # The 0 cm page records the horizontal reference used by normal functions.
    calibration_zero = CALIBRATION_ZERO
    commanded_position = 0
    commanded_position += calibration_zero - commanded_position
    assert commanded_position == CALIBRATION_ZERO

    # Fine calibration uses one physical microstep per key event.
    commanded_position += 1  # Key3
    calibration_zero = commanded_position
    assert calibration_zero == -159

    # PID tilt is an offset around the selected reference; stopping returns it.
    commanded_position += round(MAX_ANGLE_DEG * POSITIVE_PULSES_PER_DEGREE)
    commanded_position = calibration_zero
    assert commanded_position == calibration_zero

    # The -5 cm page stores its own absolute pulse position, then returns to 0.
    calibration_minus5 = calibration_zero - 50
    commanded_position = calibration_minus5
    assert commanded_position == -209
    commanded_position = calibration_zero
    assert commanded_position == -159

    target_offset = calibration_minus5 - calibration_zero
    assert target_offset == -50

    # The third camera reference is independent in position only. Direct
    # Balance moves there, PID angle offsets stay relative to it, and main exit
    # restores the 0 cm position.
    calibration_camera = calibration_zero - 25
    commanded_position = calibration_camera
    commanded_position += round(0.5 * POSITIVE_PULSES_PER_DEGREE)
    commanded_position = calibration_camera
    assert commanded_position == calibration_camera
    commanded_position = calibration_zero
    assert commanded_position == calibration_zero


def verify_tune_bidirectional_adjustment() -> None:
    def adjust(value: float, direction: int, step: float,
               minimum: float, maximum: float) -> float:
        if direction > 0:
            return min(value + step, maximum)
        return max(value - step, minimum)

    assert abs(adjust(1.5, 1, 0.1, 0.0, 20.0) - 1.6) < 1e-9
    assert abs(adjust(1.5, -1, 0.1, 0.0, 20.0) - 1.4) < 1e-9
    assert adjust(20.0, 1, 0.1, 0.0, 20.0) == 20.0
    assert adjust(0.0, -1, 0.1, 0.0, 20.0) == 0.0


def verify_position_damping_simulation() -> None:
    """100 Hz position plus filtered-velocity damping simulation."""
    dt = 0.001
    control_dt = 0.01
    acceleration_per_degree = 12.23
    location = 8.0
    velocity = 0.0
    beam_angle = 0.0
    angle_command = 0.0
    estimated_location = location
    filtered_velocity = velocity
    next_control = 0.0
    delayed_locations = [location, location, location]
    delayed_velocities = [velocity, velocity]
    settling_started = None
    settling_time = None
    hold_active = False

    for sample in range(12_000):
        now = sample * dt
        if now + 1e-9 >= next_control:
            delayed_locations.append(location)
            measured_location = delayed_locations.pop(0)
            measured_location = round(measured_location / 0.09) * 0.09
            delayed_velocities.append(velocity)
            camera_velocity = delayed_velocities.pop(0)
            camera_velocity = round(camera_velocity / 0.1) * 0.1
            filtered_velocity += VELOCITY_FILTER_ALPHA * (
                camera_velocity - filtered_velocity)
            predicted_location = estimated_location + \
                                 filtered_velocity * control_dt
            residual = measured_location - predicted_location
            estimated_location = predicted_location + OBSERVER_ALPHA * residual
            if hold_active:
                if (abs(estimated_location) > 0.70 or
                        abs(filtered_velocity) > 0.70):
                    hold_active = False
            elif (abs(estimated_location) <= 0.40 and
                  abs(filtered_velocity) <= 0.30):
                hold_active = True

            if hold_active:
                position_output = 0.0
            else:
                position_error = -estimated_location
                position_output = POSITION_KP * position_error
            damping_output = -VELOCITY_DAMPING_GAIN * filtered_velocity
            unsaturated_angle = position_output + damping_output
            angle_limited = max(-MAX_ANGLE_DEG,
                                min(MAX_ANGLE_DEG, unsaturated_angle))
            maximum_angle_step = MAX_ANGLE_SLEW_DEG_S * control_dt
            angle_command = max(angle_command - maximum_angle_step,
                                min(angle_command + maximum_angle_step,
                                    angle_limited))
            next_control += control_dt

        pulses_per_degree = (POSITIVE_PULSES_PER_DEGREE +
                             NEGATIVE_PULSES_PER_DEGREE) / 2.0
        maximum_change = (PULSE_HZ / pulses_per_degree) * dt
        beam_angle += max(-maximum_change,
                          min(maximum_change, angle_command - beam_angle))
        drive = acceleration_per_degree * beam_angle - \
                0.15 * velocity
        if abs(velocity) < 0.02 and abs(drive) < 0.5:
            acceleration = 0.0
            velocity = 0.0
        else:
            friction_sign = 1.0 if velocity > 0.0 else -1.0
            if velocity == 0.0:
                friction_sign = 1.0 if drive > 0.0 else -1.0
            acceleration = drive - 0.5 * friction_sign
        velocity += acceleration * dt
        location += velocity * dt

        if abs(location) < 0.5 and abs(velocity) < 0.6:
            if settling_started is None:
                settling_started = now
            elif (settling_time is None) and ((now - settling_started) >= 0.5):
                settling_time = settling_started
        else:
            settling_started = None

    assert settling_time is not None and settling_time < 6.0, (
        settling_time, location, velocity, beam_angle, estimated_location,
        filtered_velocity)
    assert abs(location) < 0.50
    assert abs(velocity) < 0.60
    assert abs(beam_angle) <= MAX_ANGLE_DEG


def verify_wall_rebound_recovery_simulation() -> None:
    """A wall rebound must not be reinforced into a repeated collision."""
    dt = 0.001
    control_dt = 0.01
    location = 9.2
    velocity = 4.0
    beam_angle = 0.0
    angle_command = 0.0
    filtered_velocity = velocity
    next_control = 0.0
    collision_count = 0

    for sample in range(12_000):
        now = sample * dt
        if now + 1e-9 >= next_control:
            filtered_velocity += VELOCITY_FILTER_ALPHA * (
                velocity - filtered_velocity)
            position_output = -POSITION_KP * location
            damping_output = -VELOCITY_DAMPING_GAIN * filtered_velocity
            unsaturated_angle = position_output + damping_output
            angle_limited = max(-MAX_ANGLE_DEG,
                                min(MAX_ANGLE_DEG, unsaturated_angle))
            maximum_angle_step = MAX_ANGLE_SLEW_DEG_S * control_dt
            angle_command = max(angle_command - maximum_angle_step,
                                min(angle_command + maximum_angle_step,
                                    angle_limited))
            next_control += control_dt

        actuator_step = (PULSE_HZ /
                         ((POSITIVE_PULSES_PER_DEGREE +
                           NEGATIVE_PULSES_PER_DEGREE) / 2.0)) * dt
        beam_angle += max(-actuator_step,
                          min(actuator_step,
                              angle_command - beam_angle))
        drive = 12.23 * beam_angle - 0.15 * velocity
        friction_sign = 1.0 if velocity > 0.0 else -1.0
        if velocity == 0.0:
            friction_sign = 1.0 if drive > 0.0 else -1.0
        acceleration = drive - 0.5 * friction_sign
        velocity += acceleration * dt
        location += velocity * dt

        if location > 9.8:
            location = 9.8
            velocity = -abs(velocity) * 0.6
            collision_count += 1
        elif location < -9.8:
            location = -9.8
            velocity = abs(velocity) * 0.6
            collision_count += 1

    # The 1.5-degree / 2000 Hz closed-loop defaults brake before the wall.
    assert collision_count == 0
    assert abs(location) < 0.50
    assert abs(velocity) < 0.10
    assert abs(beam_angle) <= MAX_ANGLE_DEG


def verify_velocity_zero_test_simulation() -> None:
    """The tuning mode must brake velocity without using position error."""
    dt = 0.001
    control_dt = 0.01
    location = 0.0
    velocity = 4.0
    beam_angle = 0.0
    angle_command = 0.0
    filtered_velocity = velocity
    next_control = 0.0
    first_angle = None

    for sample in range(4_000):
        now = sample * dt
        if now + 1e-9 >= next_control:
            filtered_velocity += VELOCITY_FILTER_ALPHA * (
                velocity - filtered_velocity)
            unsaturated_angle = -VELOCITY_DAMPING_GAIN * filtered_velocity
            angle_limited = max(-MAX_ANGLE_DEG,
                                min(MAX_ANGLE_DEG, unsaturated_angle))
            maximum_angle_step = MAX_ANGLE_SLEW_DEG_S * control_dt
            angle_command = max(angle_command - maximum_angle_step,
                                min(angle_command + maximum_angle_step,
                                    angle_limited))
            if first_angle is None:
                first_angle = angle_command
            next_control += control_dt

        actuator_step = (PULSE_HZ /
                         ((POSITIVE_PULSES_PER_DEGREE +
                           NEGATIVE_PULSES_PER_DEGREE) / 2.0)) * dt
        beam_angle += max(-actuator_step,
                          min(actuator_step,
                              angle_command - beam_angle))
        drive = 12.23 * beam_angle - 0.15 * velocity
        if abs(velocity) < 0.02 and abs(drive) < 0.5:
            velocity = 0.0
        else:
            friction_sign = 1.0 if velocity > 0.0 else -1.0
            if velocity == 0.0:
                friction_sign = 1.0 if drive > 0.0 else -1.0
            velocity += (drive - 0.5 * friction_sign) * dt
        location += velocity * dt

    assert first_angle is not None and first_angle < 0.0
    assert abs(velocity) < 0.10
    assert abs(angle_command) < 0.05
    assert abs(location) > 0.10  # Position is observed but intentionally unused.


def verify_velocity_filter_noise_rejection() -> None:
    """The camera-speed LPF must attenuate frame-alternating jitter."""
    raw = [2.0 + (1.0 if index % 2 == 0 else -1.0)
           for index in range(80)]
    filtered = raw[0]
    filtered_values = []
    for sample in raw:
        filtered += VELOCITY_FILTER_ALPHA * (sample - filtered)
        filtered_values.append(filtered)

    raw_rms = math.sqrt(sum((sample - 2.0) ** 2 for sample in raw[20:]) /
                        len(raw[20:]))
    filtered_rms = math.sqrt(
        sum((sample - 2.0) ** 2 for sample in filtered_values[20:]) /
        len(filtered_values[20:]))
    assert filtered_rms < raw_rms * 0.25


def verify_default_control_model() -> None:
    """Default gains should be responsive, well damped and stepper-resolvable."""
    acceleration_per_degree = 12.23
    natural_frequency = math.sqrt(acceleration_per_degree * POSITION_KP)
    damping_ratio = (acceleration_per_degree * VELOCITY_DAMPING_GAIN) / (
        2.0 * natural_frequency)
    filter_cutoff_hz = -math.log(1.0 - VELOCITY_FILTER_ALPHA) / (
        2.0 * math.pi * 0.01)
    one_cm_position_pulses = POSITION_KP * (
        (POSITIVE_PULSES_PER_DEGREE + NEGATIVE_PULSES_PER_DEGREE) / 2.0)

    assert 1.8 < natural_frequency < 2.3
    assert 0.80 < damping_ratio < 1.00
    assert 4.0 < filter_cutoff_hz < 6.0
    assert one_cm_position_pulses > ACTUATOR_CHUNK_PULSES


def verify_measured_linkage_calibration() -> None:
    positive_angle = math.degrees(math.asin(
        (POSITIVE_100_HEIGHT_MM - HORIZONTAL_HEIGHT_MM) /
        TRACK_PIVOT_DISTANCE_MM))
    negative_angle = math.degrees(math.asin(
        (NEGATIVE_100_HEIGHT_MM - HORIZONTAL_HEIGHT_MM) /
        TRACK_PIVOT_DISTANCE_MM))
    positive_scale = 100.0 / abs(positive_angle)
    negative_scale = 100.0 / abs(negative_angle)

    assert positive_angle < 0.0 < negative_angle
    assert abs(positive_scale - POSITIVE_PULSES_PER_DEGREE) < 0.01
    assert abs(negative_scale - NEGATIVE_PULSES_PER_DEGREE) < 0.01


def verify_preset_run_sequence() -> None:
    actions = ["STEP1+", "STEP2-", "STEP3+", "STEP4-"]
    waits = list(PRESET_INTERVAL_MS)
    arm_position = 0
    positions = []

    for direction, pulses in zip(PRESET_DIRECTIONS, PRESET_PULSES):
        arm_position += direction * pulses
        positions.append(arm_position)

    assert actions == ["STEP1+", "STEP2-", "STEP3+", "STEP4-"]
    assert len(waits) == len(actions)
    assert waits == [250, 650, 200, 1000]
    assert positions == [130, -130, 130, PRESET_TARGET_OFFSET]
    assert arm_position == PRESET_TARGET_OFFSET

    # P2=P3. P4 is derived from P1 and the signed -5 cm calibration offset.
    assert PRESET_PULSES[1] == PRESET_PULSES[2]
    assert PRESET_PULSES[3] == PRESET_PULSES[0] - PRESET_TARGET_OFFSET
    configs = [{"hz": hz, "interval": wait}
               for hz, wait in zip(PRESET_PULSE_HZ, PRESET_INTERVAL_MS)]
    untouched = [entry.copy() for entry in configs]
    configs[2]["hz"] += 50
    configs[2]["interval"] += 50
    assert configs[0] == untouched[0]
    assert configs[1] == untouched[1]
    assert configs[3] == untouched[3]
    assert configs[2] != untouched[2]

    adjusted_step1 = PRESET_STEP1_PULSES + 10
    adjusted_step4 = adjusted_step1 - PRESET_TARGET_OFFSET
    assert adjusted_step4 == PRESET_STEP4_PULSES + 10
    assert adjusted_step1 - adjusted_step4 == PRESET_TARGET_OFFSET

    # Preset sends no camera command, ends at -5 cm, then returns to 0 on exit.
    camera_stream_commands = []
    assert camera_stream_commands == []
    commanded_position = CALIBRATION_ZERO + arm_position
    assert commanded_position == CALIBRATION_MINUS5
    commanded_position = CALIBRATION_ZERO
    assert commanded_position == CALIBRATION_ZERO


def verify_pure_stream_manual_trigger() -> None:
    commands = []

    # Entering the page is passive. Each Key3 event emits exactly one Init.
    assert commands == []
    commands.append("Init")
    commands.append("Init")
    assert commands == ["Init", "Init"]

    # Key1 exits through Stop and no position-control command is mixed in.
    commands.append("Stop")
    assert commands[-1] == "Stop"
    assert "Start" not in commands


def verify_four_row_menu_scroll() -> None:
    selected = 1
    first = 1
    last = 7
    rows = 4

    def visible() -> list[int]:
        return list(range(first, min(first + rows, last + 1)))

    assert visible() == [1, 2, 3, 4]
    for expected in (2, 3, 4, 5, 6):
        selected = 1 if selected >= last else selected + 1
        if selected == 1:
            first = 1
        elif selected >= first + rows:
            first = selected - (rows - 1)
        assert selected == expected
    assert visible() == [3, 4, 5, 6]

    selected += 1
    first = selected - (rows - 1)
    assert visible() == [4, 5, 6, 7]

    selected = 1
    first = 1
    assert visible() == [1, 2, 3, 4]

    selected = last
    first = last - (rows - 1)
    assert visible() == [4, 5, 6, 7]


def verify_key4_debounce() -> None:
    candidate = "NONE"
    stable = "NONE"
    candidate_count = 0
    events = []
    samples = (["NONE"] * 4 +
               ["PREVIOUS", "NONE", "PREVIOUS", "PREVIOUS", "PREVIOUS", "PREVIOUS"] +
               ["NONE", "PREVIOUS", "NONE", "NONE", "NONE", "NONE"])

    for raw in samples:
        if raw != candidate:
            candidate = raw
            candidate_count = 1
            continue
        candidate_count = min(candidate_count + 1, 4)
        if candidate_count < 4 or candidate == stable:
            continue
        previous_stable = stable
        stable = candidate
        if stable == "NONE" and previous_stable != "NONE":
            events.append(previous_stable)

    assert events == ["PREVIOUS"]

def main() -> None:
    verify_project_files()
    verify_source_contracts()
    verify_impulse_state_machine()
    verify_control_polarity()
    verify_direction_setup_timer()
    verify_camera_control_cycle()
    verify_camera_buffer_capacity()
    verify_location_protocol_examples()
    verify_latest_target_chunk_tracking()
    verify_calibrated_reference_cycle()
    verify_tune_bidirectional_adjustment()
    verify_position_damping_simulation()
    verify_wall_rebound_recovery_simulation()
    verify_velocity_zero_test_simulation()
    verify_velocity_filter_noise_rejection()
    verify_default_control_model()
    verify_measured_linkage_calibration()
    verify_preset_run_sequence()
    verify_pure_stream_manual_trigger()
    verify_four_row_menu_scroll()
    verify_key4_debounce()
    assert len(SUPPORTED_MICROSTEPS) == 6
    assert SUPPORTED_MICROSTEPS[3200] == (0, 0, 0)

    angle_deg = TEST_PULSES * 360.0 / PULSES_PER_REV
    speed_rpm = PULSE_HZ * 60.0 / PULSES_PER_REV
    one_way_ms = 1000.0 * TEST_PULSES / MOTOR_DEFAULT_PULSE_HZ
    round_trip_ms = 2.0 * one_way_ms + 2.0 * DIR_SETUP_US / 1000.0
    uart_utilization = (CAMERA_MAX_LINE_BYTES * 10.0 * CAMERA_FPS /
                        CAMERA_BAUD)
    actuator_chunk_ms = 1000.0 * ACTUATOR_CHUNK_PULSES / PULSE_HZ
    positive_actuator_slew_deg_s = PULSE_HZ / POSITIVE_PULSES_PER_DEGREE
    negative_actuator_slew_deg_s = PULSE_HZ / NEGATIVE_PULSES_PER_DEGREE
    min_half_width_us = 1_000_000.0 / MAX_PULSE_HZ / 2.0

    assert angle_deg == 11.25
    assert speed_rpm == 37.5
    assert abs(one_way_ms - 66.6666666667) < 1e-9
    assert abs(round_trip_ms - 133.3353333333) < 1e-9
    assert actuator_chunk_ms < 10.0
    assert positive_actuator_slew_deg_s > 37.0
    assert negative_actuator_slew_deg_s > 36.0
    assert uart_utilization < 0.40

    preset_motion_ms = sum(1000.0 * pulses / pulse_hz
                           for pulses, pulse_hz in
                           zip(PRESET_PULSES, PRESET_PULSE_HZ))
    preset_motion_ms += len(PRESET_PULSES) * DIR_SETUP_US / 1000.0
    preset_total_ms = preset_motion_ms + sum(PRESET_INTERVAL_MS)
    assert abs(preset_motion_ms - 830.004) < 1e-9
    assert abs(preset_total_ms - 2930.004) < 1e-9
    assert DIR_SETUP_US * 1000 >= 200  # ATD5984 DIR setup minimum is 200 ns.
    assert WAKE_DELAY_MS >= 1
    assert min_half_width_us >= 25.0
    assert min_half_width_us >= 1.0  # ATD5984 STEP high/low minimum.

    print("design verification passed")
    print(f"manual test angle: {angle_deg:.3f} deg")
    print(f"PID motor speed: {speed_rpm:.3f} RPM")
    print(f"manual test round trip: {round_trip_ms:.3f} ms")
    print(f"100 Hz UART utilization: {uart_utilization * 100.0:.3f}%")
    print(f"actuator chunk: {actuator_chunk_ms:.3f} ms")
    print(f"positive actuator capacity: {positive_actuator_slew_deg_s:.3f} deg/s")
    print(f"negative actuator capacity: {negative_actuator_slew_deg_s:.3f} deg/s")
    print(f"software angle slew limit: {MAX_ANGLE_SLEW_DEG_S:.3f} deg/s")
    natural_frequency = math.sqrt(12.23 * POSITION_KP)
    damping_ratio = (12.23 * VELOCITY_DAMPING_GAIN) / (
        2.0 * natural_frequency)
    filter_cutoff_hz = -math.log(1.0 - VELOCITY_FILTER_ALPHA) / (
        2.0 * math.pi * 0.01)
    print(f"position+damping natural frequency: {natural_frequency:.3f} rad/s")
    print(f"position+damping ratio: {damping_ratio:.3f}")
    print(f"velocity LPF cutoff at 100 Hz: {filter_cutoff_hz:.3f} Hz")
    print(f"sample calibrated preset total: {preset_total_ms:.3f} ms")
    print(f"20 kHz high/low width: {min_half_width_us:.3f} us")


if __name__ == "__main__":
    main()
