# 水管钢球平衡控制器（STM32F103C8T6 + D36A）

本工程已经从原双轴云台控制重构为单轴水管钢球平衡控制器。旧的 GPS、MPU6050、编码器、双轴 PID 和云台电机代码已移除。工程使用 Keil MDK-ARM，可直接打开 `MDK-ARM/SmartCar.uvprojx`，选择 `BallBalance` 目标编译和下载。

## 功能概览

- D36A 使用与参考云台 Pitch 相同的控制引脚：PA15/TIM2_CH1=ST、PB10=DIR、PB11=EN；关闭 JTAG 但保留 PA13/PA14 的 SWD。
- TIM2_CH1 硬件 PWM 产生 D36A ST 脉冲，下降沿中断精确计数。
- 支持使能、正反转、脉冲数运动、角度运动、脉冲频率和细分换算。
- Cycle Test仍保留严格等幅的“正向 N 脉冲→DIR建立1 us→反向 N 脉冲”；摄像头平衡改为短脉冲块追踪绝对倾角目标。
- USART1以115200-8-N-1与摄像头通信：位置控制发送`Start\r\n`/`Stop\r\n`，以100 Hz接收`V:<速度>cm/s,LOCATION:<位置>\r\n`。位置单位cm，正数表示目标点下方，负数表示上方；速度单位cm/s，向下为正、向上为负，与Location坐标一致。仍兼容旧`Location/LOCATION`单字段帧。
- 接收端按字节中断组帧，在中断中将位置和速度转换为0.001单位的定点值，使用64字节行缓冲和32项带时间戳事件队列（有效容量31帧），不在中断中执行浮点运算。
- 平衡逻辑为位置P/I输出叠加滤波速度阻尼；组合帧的摄像头速度先经独立一阶低通，再同时用于位置预测和反向制动。位置与速度作用强度可分别调节，旧单字段帧才由α-β观测器估速。
- Preset Run按 `正转→反转→正转→到−5 cm` 执行；Step2/3共用脉冲值，Step4由Step1和两个校准点的差值计算，四段频率和间隔分别独立，全部完成后停在−5 cm并保持电机锁轴，全程不启动摄像头。
- OLED 顶层菜单包含 Balance、Balance Ref、Preset Run、Tune、Motor、Pure Stream 六项；四个按键统一为返回、确认、下一项、上一项。

## 位置控制与速度阻尼逻辑

摄像头返回当前位置相对目标点的有符号距离`x`，位置和速度统一采用“向下为正”的坐标：`x>0`表示钢球在目标下方，`x<0`表示在目标上方；`V>0`表示向下运动，`V<0`表示向上运动。控制器使用`e=-x`，位置输出把小球推向目标；速度阻尼项始终与滤波后的速度反向，用于在到达目标前提前减速。根据实测摆臂机构，轨道倾角符号与D36A逻辑脉冲方向相反，因此公共闭环执行层使用`motor_angle=-beam_angle`；该反转不影响校准、手动电机测试和Preset四段动作。

组合帧中的摄像头速度不再对量化位置二次求导，而是先经`v_f=v_f+alpha_v*(V-v_f)`低通。位置用`x_pred=x+v_f*dt`和`x=x_pred+alpha_x*(x_measured-x_pred)`做预测平滑。只有收到旧单字段Location帧时，才使用`beta/dt`从位置残差估算速度。最终倾角由位置输出与速度阻尼直接相加：

```text
position_angle = Kp*(-x) + Ki*Ip
damping_angle  = -Kv*v_f
beam_angle     = sat(position_angle + damping_angle, ±AngleMax)
```

位置积分采用条件积分和限幅，输出饱和时不继续向错误方向累积。进入`|x|<=0.40 cm且|v|<=0.30 cm/s`的稳定带后位置输出和积分清零，但速度阻尼继续工作；超过`0.70 cm或0.70 cm/s`才退出，减少中心附近抖动。当小球朝目标运动过快时，反向速度阻尼可直接压过位置输出形成提前制动，不再受第二级PID增益或目标速度限幅耦合。倾角变化率限制为15°/s，再按双向实测`Pulses/Deg`追踪绝对位置。

若超过默认100 ms没有收到有效Location帧，状态进入LOST，清空PID积分并把目标倾角设为0°，电机分段返回当前Balance基准点并继续锁轴；新数据恢复后先重新建立速度估计，再恢复ACTIVE控制。一次运行只发送一次Start，动作过程中不重复Stop/Start。

Preset Run的四段动作和独立参数完全保留：`正转Step1→反转Step2→正转Step3→反转Step4到−5 cm→锁轴`。Preset完成后保持`COMPLETE`且D36A继续使能，不发送`Start\r\n`、不接收位置帧，也不启动任何BallBalance控制；退出仍回到0 cm。

## 默认动作参数

D36A 默认软件细分设为 3200 pulse/rev，对应 16 细分：SW1、SW2、SW3 全部拨向散热风扇（全 OFF）。42 步进电机按 1.8° 整步计算：

- 1 脉冲 = 360 / 3200 = 0.1125°
- 实测支点中心距251 mm；水平高度66.6 mm，+100脉冲高度55.7 mm，−100脉冲高度77.3 mm
- 由`theta=asin(delta_h/251)`得到：正向100脉冲对应−2.4889°，负向100脉冲对应+2.4432°
- 正向标定为40.18 pulse/轨道度，负向标定为40.93 pulse/轨道度；不再使用丝杆导程或滑台位移模型
- 摄像头闭环默认电机频率2000 Hz，对应37.5 RPM；每个10脉冲执行块约5 ms，实测比例下名义倾角追踪速率约48.9～49.8°/s
- 摄像头闭环默认值：位置`Kp=0.35 deg/cm、Ki=0`，速度阻尼`Kv=0.30 deg/(cm/s)`，摄像头速度低通`alpha_v=0.25`，位置观测`alpha_x=0.20`、旧帧估速`beta=0.02`，最大倾角1.5°、最大倾角变化率15°/s。Preset仍使用自己的四段独立参数。
- Cycle Test默认仍使用100脉冲，但它对应约2.45°轨道倾角，必须在无球或有挡板条件下测试
- Preset的Step1默认130脉冲、Step2/3默认260脉冲；Step4按 `P4=P1−(Cal−5−Cal0)` 实时计算。四步频率均默认1000 Hz，运动后间隔依次为250、650、200和1000 ms；未保存0 cm和−5 cm两个校准点时拒绝运行

钢球位移仍受PPR半圆槽内壁、接缝、污染、装配偏心和滚动摩擦影响；正负标定值只保证水平工作点附近的倾角换算，不代表整个四杆机构行程都严格线性。

## 菜单操作

- Key1 / KEY_BACK（PB15）：返回；在Balance页面先发送Stop，再由主菜单回调移动到0 cm；执行器短脉冲块尚未完成时暂时忽略按键。
- Key2 / KEY_CONFIRM（PB14）：进入菜单或执行当前功能。
- Key3 / KEY_NEXT（PB13）：下一项。
- Key4 / KEY_PREVIOUS（PA1）：上一项。
- 四个按键均采用每5 ms采样、连续4次一致才确认的按下/释放双边消抖；一次完整按压只产生一个事件，避免Key4触点抖动连续触发OLED整屏刷新。
- Balance：进入页面先移动到0 cm校准点，KEY_CONFIRM启停摄像头平衡；FAULT时KEY_CONFIRM先清故障。
- Balance Ref：与Balance使用完全相同的位置控制、速度滤波/阻尼和执行器参数，唯一差别是进入页面先移动到`Cal Camera`保存的第三方基准点。
- 主菜单和各级子菜单均使用原云台工程的 `Option_Class + Menu_RunMenu()` 四行滚动结构。OLED 一次显示四项；Key3 移动到第五项时画面自动向下滚动，Key4 可反向滚动，选中项末尾显示 `<-`。
- Preset Run：进入子菜单后可选择Run、Step1、Step2、Step3、Step4；每个Step内均可查看和调节Pulses、Frequency、Interval。Step2=Step3；Step1和Step4共用同一个基础幅值调节，但Step4显示加入校准差值后的计算结果。四个Frequency和四个Interval各自独立。四段运行及段间等待期间忽略Key1/Key2。Pulses以10、Frequency以50 Hz、Interval以50 ms增减。
- Tune：分为Position Ctrl、Speed Damping、Estimator、Actuator四个子菜单；所有页面均由Key3增加、Key4减少、Key1返回，到达边界后保持而不循环。
- Position Ctrl：位置Kp步进0.05、Ki步进0.01；Speed Damping：阻尼增益步进0.05、Velocity LPF系数步进0.05，并保留Velocity Test。
- Speed Damping → Velocity Test：先移动到0 cm校准点，Key2启停。该模式以100 Hz接收摄像头位置和速度，位置输出及积分强制为0，只执行`angle=-Kv*v_f`。页面中`V`为滤波速度、`D`为速度阻尼倾角、`A`为总倾角命令；手动轻推小球后，D和A应与V反向并使V平滑趋近0。
- Estimator：Observer Alpha步进0.05，用于位置平滑；Observer Beta步进0.01，仅在兼容旧Location单字段帧时参与速度估计；数据超时步进10 ms。
- Actuator：分别调节最大倾角、正向Pulses/Deg、负向Pulses/Deg、控制脉冲频率、单次Move Chunk和Cycle Test脉冲。这些参数只供Balance、Balance Ref和Velocity Test使用；Preset四段动作拥有完全独立的脉冲、频率和间隔参数。
- PID参数校验保证`Move Chunk / Pulse Freq <= 10 ms`且`Max Angle * Pulses/Deg <= 5000脉冲`；停止时先完成当前短块再停机，避免截断运动后软件绝对位置与机构实际位置不一致。
- Motor：进入子菜单后选择动作周期测试、0 cm校准、−5 cm校准和Camera基准点校准。细分仍固定为原来的3200 pulse/rev（1/16），菜单不再提供单独的使能和细分状态页面。
- Motor → Cycle Test：Key3执行“正转N脉冲后立即反转N脉冲”，Key4执行“反转N脉冲后立即正转N脉冲”；N使用`Tune→Actuator→Test Pulses`。动作忙时所有新按键均被忽略，完整回到校准点后Key1才返回Motor页。
- Motor → Cal 0cm：现有水平校准，首次进入会自动移动到预置值−160脉冲，再由Key3/Key4每次微调1脉冲；Key1和Key2都会保存。
- Motor → Cal −5cm：从0 cm附近开始，用Key3/Key4单脉冲微调到钢球能稳定停在−5 cm的位置；保存该绝对脉冲位置后，电机自动返回0 cm校准点再退出。
- Motor → Cal Camera：从0 cm附近开始，用Key3/Key4单脉冲微调到任意摄像头目标位置；Key1或Key2保存该绝对位置，保存后自动返回0 cm。该点只供Balance Ref使用。
- Pure Stream：主菜单最末项。进入页面不会自动推流；每完整按下并释放一次 Key3，仅发送一次 `Init\r\n`，Key2/Key4 无动作。Key1 发送 `Stop\r\n`、清空接收数据并退出。

注意：本版本固定沿用 3200 pulse/rev，D36A 的 SW1、SW2、SW3 保持全 OFF。软件不会在菜单中切换细分，也不会为了退出功能页而让驱动器休眠。

## 0 cm、−5 cm与Camera三点校准

`Motor -> Cal 0cm`保存普通平衡、Cycle Test和Preset起点共同使用的0 cm水平位置。默认建议值为−160脉冲；Key3/Key4每次只移动1脉冲（0.1125°），Key1或Key2保存当前绝对有符号脉冲位置。

`Motor -> Cal -5cm`独立保存轨道−5 cm处真正需要的电机绝对位置。首次进入时从0 cm位置开始微调；保存后程序先记录−5 cm位置，再自动移动回已保存的0 cm位置，保证退出后其他功能仍以0 cm为水平标准。

`Motor -> Cal Camera`保存任意第三方摄像头目标点的电机绝对位置。它不修改0 cm或−5 cm值，也不建立独立动作参数；`Balance Ref`只把该位置作为闭环控制的0°倾角基准，位置/速度阻尼及执行器参数与`Balance`完全共用。保存后同样自动返回0 cm。

两点都保存后，程序计算有符号差值 `D=Cal−5−Cal0`。Preset第四段使用 `P4=P1−D`，所以最终位置为 `Cal0+P1−P4=Cal−5`。Step2与Step3脉冲相等并相互抵消。若P4计算结果超出10–1600脉冲，Run页面显示 `STEP4 RANGE ERR` 并拒绝运行。

电机在初始化完成后立即使能；Balance/Preset/Cycle/Calibrate/Pure Stream 的正常停止、段间等待以及所有菜单页面都保持 PB11 为高，使步进电机持续锁轴。任何顶层功能退出并回到主菜单前，程序都会先停止相关状态机并把机构移动到已保存的0 cm位置。只有运动超时、状态机故障、HardFault 或 Error_Handler 才会关闭 EN。持续保持会使电机和D36A发热，应按电机额定相电流设置SW4-SW6并检查温升。

系统没有原点开关或编码器；重新上电、下载程序、手动转轴或发生失步后，必须重新完成0 cm和−5 cm校准；需要使用Balance Ref时还要重新完成Cal Camera。

## Preset Run 独立运行

Preset Run保存Step1基础脉冲、Step2/3共享脉冲、四个独立Frequency和四个独立Interval；Step4脉冲不独立保存，而是实时计算。默认配置为：

1. Step1：DIR+，130脉冲，1000 Hz，完成后等待250 ms。
2. Step2：DIR−，260脉冲，1000 Hz，完成后等待650 ms。
3. Step3：DIR+，260脉冲，1000 Hz，完成后等待200 ms。
4. Step4：DIR−，`P1−(Cal−5−Cal0)`脉冲，1000 Hz，完成后等待1000 ms并进入COMPLETE。
5. Step4间隔结束后进入COMPLETE，恢复原电机脉冲频率并保持D36A使能锁轴；不启动BallBalance，不向摄像头发送任何Start命令。

Step1或Step4的Pulses页面都调节同一个P1基础值，因此P4会保持与P1相同的调节增量，但始终保留校准差值；Step2/3继续共享。Frequency和Interval带独立 `step_index`。Interval严格表示当前Step收到MOTION_DONE之后，到下一Step开始之前的等待时间；Step4的Interval表示第四段结束到进入COMPLETE并锁轴之间的等待时间。Preset开始前先回0 cm，完成后保持在−5 cm，停止或退出Preset页面时自动回0 cm。Run页面从第一段动作启动时开始计时，四段运动及全部间隔期间以秒实时显示，第四段停稳间隔结束后冻结最终时间。Balance只读取0 cm，Balance Ref只读取Camera基准点，Cycle Test不读取−5 cm校准值。

## Pure Stream 隔离模式

Pure Stream 页面只负责人工发送摄像头命令。进入时先停止 Balance、Preset Run 和已有摄像头推流，但不发送 `Init`；Key3 每产生一个按键释放事件，唯一的 `CameraLink_SendPureInit()` 就发送一次且仅一次 `Init\r\n`。屏幕 `Sent` 统计成功发送次数并显示最近一次发送结果。

该模式不会解析摄像头返回的Location帧，不会写入控制队列，也不会触发电机或修改任何控制参数。离开页面的唯一有效按键是Key1，它发送`Stop\r\n`后清空串口行缓存和位置队列。应用代码中`Init\r\n`命令常量只有这一处所有者，Balance和Preset Run均不能调用它。

## 状态机

```text
STOPPED --Start/发送Start--> ACQUIRE
ACQUIRE --第1帧建立位置/速度基准，第2帧完成滤波更新--> ACTIVE
ACTIVE --每个Location帧--> 速度低通/位置预测→稳定带→位置输出+速度阻尼→更新目标角
ACTIVE --超过Sample Timeout无有效帧--> LOST
LOST --分段回当前校准基准并锁轴--> LOST
LOST --重新收到有效帧--> ACQUIRE
任一启动、定时器或执行器错误 --> FAULT
任一运行态 --Stop/发送Stop--> STOPPED
```

```text
Preset: IDLE --Start--> MOVING --运动完成--> INTERVAL
INTERVAL --等待本步时间--> 下一步MOVING/COMPLETE
COMPLETE --保持D36A使能并锁定−5 cm--> COMPLETE
任一动作错误 --> FAULT
任一运行态 --Stop/恢复PID脉冲频率--> IDLE
```

D36A 驱动内部还有独立状态机：`DIR_SETUP -> OUTBOUND -> DIR_SETUP_RETURN -> RETURNING -> IDLE`。方向建立阶段 ST 强制为低，保持 1 us，随后才出现第一个上升沿。TIM2 在该阶段使用 `ARR=1、CNT=1`，避免 STM32F1 在 `ARR=0` 时停止计数。D36A 从休眠切换到使能时，底层还会按 ATD5984 要求等待 1 ms。每条运动命令另有按脉冲数和频率计算的超时保护；若定时器或中断异常，软件会退出 BUSY、报告错误并关闭驱动使能。

## 调参流程

1. 先安装机械限位和接球挡板，空载确认闭环执行极性：Location为正（球在目标下方）时PID产生负轨道倾角命令，经摆臂反向映射后形成正D36A电机偏移，并使钢球向上方目标加速；Location为负时方向完全相反。若钢球实际运动仍相反，只修改`BALL_BALANCE_CLOSED_LOOP_MOTOR_POLARITY`，不要改摄像头V或Location符号。
2. 完成Cal 0cm和Cal −5cm；若使用Balance Ref，再完成Cal Camera。先保持默认最大倾角0.6°，确认无撞壁循环后才以0.1°为步进小幅提高。
3. 当前正、负方向分别采用实测40.18和40.93 pulse/度；更换连杆孔位、支架高度或轨道长度后必须重新用±100脉冲测量更新。
4. 进入Velocity Test，保持默认Velocity LPF=0.25，轻推小球并只调Damping Gain，直到速度能快速降为0且不明显反向。测试时必须在两端放挡板，因为此模式故意不负责回到位置目标。
5. 速度抖动使摆臂频繁换向时降低Velocity LPF；制动明显滞后时再提高。随后调Position Kp：过小回正弱，过大会压过速度制动；Position Ki通常保持0，只在轨道存在稳定的单向偏置时少量增加。
6. Observer Alpha主要决定位置测量跟随程度；Observer Beta只影响旧Location单字段兼容模式。每次只改变一个参数并记录8 cm、5 cm、1 cm三种初始偏差的收敛曲线。
7. 若出现尖叫、失步或回零不一致，降低Pulse Freq、Max Angle或Move Chunk；开环步进失步后软件无法知道真实零位。

理想无滑动实心球在斜面上的加速度约为`a=5/7*g*sin(theta)`，小角度下约为每1°产生12.23 cm/s²加速度。使用`Kx=0.35`、`Kv=0.30`线性化后，`x''+12.23*Kv*x'+12.23*Kx*x=0`，得到自然频率约2.07 rad/s、阻尼比约0.89。当前模型使用251 mm支点距和双向实测倾角比例；PPR半圆槽的真实滚阻与静态偏差仍需实机微调位置Ki。

## 工程结构

- `Core/Src/d36a.c`：D36A 硬实时脉冲、使能和运动驱动。
- `Core/Src/camera_link.c`：摄像头串口协议和接收事件队列。
- `Core/Src/ball_balance.c`：钢球平衡状态机和调参接口。
- `Core/Src/preset_run.c`：四段独立Preset动作、回正校验、专用参数和D36A频率恢复。
- `menu/menu.c`：与原云台工程一致的通用 `Option_Class` 四行滚动菜单框架。
- `menu/menu_data.c`：0 cm/Camera双入口钢球平衡、Preset、Tune、Motor校准和 Pure Stream 的菜单树与内部功能页面。
- `docs/WIRING.md`：完整引脚、电源、D36A 直连和拨码接线表。
- `docs/DESIGN_NOTES.md`：官方资料依据、时钟和时序复核。
- `tests/verify_design.py`：关键常量和默认动作的自动校验。

## 代码体积与依赖裁剪

- OLED仅保留本项目实际使用的8×16 ASCII显示、全屏刷新和轻量格式化；格式符限定为`%s/%c/%u/%lu/%d/%ld`，不再链接`printf/sprintf`运行库。
- 删除工程未引用的CMSIS模板、DSP、NN、RTOS和预编译算法库；保留`Drivers/CMSIS/Include`、STM32F1设备头文件、启动文件与HAL源码。
- 离线验证会检查Keil工程的每个源文件、OLED格式符范围、必需CMSIS头文件和已裁剪目录，防止后续误删或重新引入大型格式化库。

## 编译

```powershell
C:\Keil_v5\UV4\UV4.exe -b MDK-ARM\SmartCar.uvprojx -t BallBalance -j0
```

本次验证使用 ARMCC 5.06 update 5，结果为 0 errors / 0 warnings。生成的 `SmartCar.hex` 位于 `MDK-ARM/SmartCar/`（目录名沿用旧工程输出设置）。

## 官方资料

- [STM32F103x8/xB 数据手册 DS5319 Rev 20（ST，2025-07）](https://www.st.com/resource/en/datasheet/stm32f103c8.pdf)
- [STM32F1 参考手册 RM0008 Rev 21（ST）](https://www.st.com/resource/en/reference_manual/cd00171190-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-arm-based-32Bit-mcus-stmicroelectronics.pdf)
- [STM32F103x8/xB 芯片勘误 ES096（ST）](https://www.st.com/resource/en/errata_sheet/es096-stm32f101x8b-stm32f102x8b-and-stm32f103x8b-mediumdensity-device-limitations-stmicroelectronics.pdf)
- 本地 WHEELTEC D36A 教程：`D:\BaiduNetdiskDownload\WHEELTEC 步进电机原理与驱动教程视频\【WHEELTEC】 步进电机原理与驱动教程视频_V1.0_2025.01.18\3.步进电机驱动\步进电机驱动.pdf`
- [ATD5984 数据手册 V1.3](https://makerselectronics.com/wp-content/uploads/2025/07/2012311902_ZHONGKEWEI-ATD5984_C1323230.pdf)

## 控制结构参考

- 本地《2026全国大学生电子设计竞赛H题浅析-逐飞科技.docx》：采用平滑后的钢球速度趋势直接叠加到位置控制输出，作为本版速度阻尼结构的主要参考。
- [Optimized PID Position Control of a Nonlinear System Based on Correlating the Velocity with Position Error](https://onlinelibrary.wiley.com/doi/10.1155/2015/796057)：用于对照位置与速度关联控制。
